from asyncore import read
import matplotlib.pyplot as plt
import pandas as p

c =p.read_csv("C:/Users/cdeke/OneDrive/Bureau/B.U.T/stat/Tp4/Tp4partie1.csv",delimiter = ';')
print(c.loc)

labels = c['nom complet']
sizes = c['promo 2018']
colors = ['yellowgreen', 'gold', 'lightskyblue', 'lightcoral','red']

plt.pie(sizes, labels=labels, colors=colors, 
        autopct='%1.1f%%', shadow=True, startangle=90)

plt.axis('equal')

plt.savefig('PieChart01.png')
plt.show()
#-----------------------------------------
sizes = c['promo 2019']
colors = ['yellowgreen', 'gold', 'lightskyblue', 'lightcoral','red']

plt.pie(sizes, labels=labels, colors=colors, 
        autopct='%1.1f%%', shadow=True, startangle=90)

plt.axis('equal')

plt.savefig('PieChart01.png')
plt.show()
#-----------------------------------------
plt.subplot(211)

barWidth = 0.4
y1 =  c['promo 2018']
y2 =  c['promo 2019']
r1 = range(len(y1))
r2 = [x + barWidth for x in r1]

plt.bar(r1, y1, width = barWidth, color = ['yellow' for i in y1],
           edgecolor = ['blue' for i in y1], linewidth = 2)
plt.bar(r2, y2, width = barWidth, color = ['pink' for i in y1],
           edgecolor = ['green' for i in y1], linewidth = 4)
plt.xticks([r + barWidth / 2 for r in range(len(y1))], c['abregé'])

plt.show()

#------------------------------------------------
xls = p.ExcelFile('./Tp4partie2.xlsx')
print(xls.sheet_names)
df1 = p.read_excel(xls, 'taille_ent',)
df2 = p.read_excel(xls, 'nuage',)
print(df1)
y=df1['bac+5']
x=df1['taille entreprise']
plt.bar(x,y)
plt.show()