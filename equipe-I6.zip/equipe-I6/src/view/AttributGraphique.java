package view;

import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import model.IColumn;

public class AttributGraphique {
    
    protected VBox vBox;
    public ComboBox<String> x;
    public ComboBox<String> y;
    public Button valide;

    public AttributGraphique(){
        vBox=new VBox();

        //ordonnée
        HBox ordBox = new HBox();
        x = new ComboBox<String>();
        Label ord = new Label("ordonnée ");
        ordBox.getChildren().add(ord);
        ordBox.getChildren().add(x);

        //abscisse
        HBox absBox = new HBox();
        y = new ComboBox<>();
        Label abs = new Label("         abscisse ");
        ordBox.getChildren().add(abs);
        ordBox.getChildren().add(y);

        vBox.getChildren().add(ordBox);
        vBox.getChildren().add(absBox);

        //validation
        valide = new Button("valider");
        vBox.getChildren().add(valide);

        //positionnement / style
        String cssLayout = "-fx-border-color: lightgrey;\n" +
                   "-fx-border-insets: 5;\n" +
                   "-fx-border-width: 1;\n" 
                   ;
        vBox.setStyle(cssLayout );
        vBox.setMargin(ordBox, new Insets(10,10,5,10));
        vBox.setMargin(absBox, new Insets(5,10,10,10));
        vBox.setMargin(valide, new Insets(0,0,5,0));
        vBox.setAlignment(Pos.CENTER);
    }

    public void setAttribut(List<IColumn> listCol){
        ObservableList<String> nom = FXCollections.observableArrayList();
        for (IColumn iColumn : listCol) {
            nom.add(iColumn.getName());
        }
        x.setItems(nom);
        y.setItems(nom);
        x.getSelectionModel().selectFirst();
        y.getSelectionModel().selectFirst();
    }

    public VBox getVbox() {
    	return this.vBox;
    }

}
