package view;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.ScatterChart;
import javafx.scene.chart.XYChart;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class Test extends Application {
  public static void main(String[] args) {
    launch(args);
  }

  @Override
  public void start(Stage stage) {
    // create the x and y axes
    NumberAxis xAxis = new NumberAxis();
    xAxis.setLabel("X");
    NumberAxis yAxis = new NumberAxis();
    yAxis.setLabel("Y");

    // create the scatter chart
    ScatterChart<Number, Number> chart = new ScatterChart<>(xAxis, yAxis);
    chart.setTitle("Scatter Chart Example");

    // create the data series
    XYChart.Series<Number, Number> series = new XYChart.Series<>();
    series.setName("Data");

    // add some data points to the series
    series.getData().add(new XYChart.Data<>(1, 2));
    series.getData().add(new XYChart.Data<>(3, 4));
    series.getData().add(new XYChart.Data<>(5, 6));
    series.getData().add(new XYChart.Data<>(7, 8));

    // add the series to the chart
    chart.getData().add(series);

    // handle clicks on the chart
    chart.setOnMouseClicked((MouseEvent e) -> {
    	XYChart.Data<Number, Number> dataPoint = null;
    	double minDistance = Double.MAX_VALUE;
    	for (XYChart.Series<Number, Number> serie : chart.getData()) {
    	  for (XYChart.Data<Number, Number> data : serie.getData()) {
    	    double x = chart.getXAxis().getDisplayPosition(data.getXValue());
    	    double y = chart.getYAxis().getDisplayPosition(data.getYValue());
    	    double distance = Math.sqrt(Math.pow(x - x, 2) + Math.pow(y - y, 2));
    	    if (distance < minDistance) {
    	      dataPoint = data;
    	      minDistance = distance;
    	      System.out.println(""+distance);
    	    }
    	  }
    	}
    });

    // create a scene and add the chart to it
    Scene scene = new Scene(chart, 800, 600);

    // show the chart
    stage.setScene(scene);
    stage.show();
  }
}
