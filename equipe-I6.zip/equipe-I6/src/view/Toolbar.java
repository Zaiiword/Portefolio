package view;

import javax.tools.Tool;

import javafx.scene.control.*;
import model.IPoint;
import model.MethodeKnn;

public class Toolbar {

    public Button importer;
    public Button ajoutPoint;
    protected Button robustesse;
    public Button classification;
    public TextArea tx;
    public Button ok;
    ToolBar toolBar;

    
    public Toolbar() {

        this.toolBar = new ToolBar();

        this.importer = new Button("Importer");
        toolBar.getItems().add(importer);

        this.ajoutPoint = new Button("Ajout point");
        toolBar.getItems().add(ajoutPoint);
        this.ajoutPoint.setDisable(true);

        this.classification = new Button("Classification");
        toolBar.getItems().add(classification);
        this.classification.setDisable(true);
        
        tx = new TextArea("k=?");
        tx.setPrefHeight(25);
        tx.setPrefWidth(200);
        ok = new Button("ok");
        
        
    }
    
    public void classText() {
    	toolBar.getItems().add(tx);
    	toolBar.getItems().add(ok);
    }
    
    public void remove(MethodeKnn methodeKnn, int k,IPoint point) {
    	toolBar.getItems().remove(toolBar.getItems().size()-1);
    	toolBar.getItems().remove(toolBar.getItems().size()-1);
    	tx.setText("Robustesse: "+methodeKnn.calculRobustesse(k) +" type:"+ methodeKnn.datas.getValue(point, methodeKnn.datas.getClassified()));
    	toolBar.getItems().add(tx);
    }

    public ToolBar getToolBar() {
    	return this.toolBar;
    }

}

