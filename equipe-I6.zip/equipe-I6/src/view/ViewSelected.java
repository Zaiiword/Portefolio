package view;


import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class ViewSelected {

    protected VBox vbox;
    protected HBox compteur;
    public Button next;
    public Button previous;
    protected Label lab;


    public ViewSelected(){
        HBox hBox = new HBox();
        compteur = new HBox();
        vbox = new VBox();
        previous = new Button("    <<    ");
        next = new Button("    >>    ");
        lab = new Label("0/0");

        hBox.getChildren().add(previous);
        hBox.getChildren().add(next);
        vbox.getChildren().add(hBox);
        compteur.getChildren().add(lab);
        vbox.getChildren().add(compteur);
 
        //positionnement / style
        HBox.setMargin(next, new Insets(0,5,0,5));
        HBox.setMargin(previous, new Insets(0,5,0,5));
        hBox.setAlignment(Pos.CENTER);
        compteur.setAlignment(Pos.CENTER);
        String cssLayout = "-fx-border-color: lightgrey;\n" +
                   "-fx-border-insets: 5;\n" +
                   "-fx-border-width: 1;\n";
        vbox.setStyle(cssLayout );
    }


    public void update(int current,int lenght){
        lab.setText(current+"/"+lenght);
    }
    
    public VBox getVBox() {
    	return this.vbox;
    }
    

    
}
