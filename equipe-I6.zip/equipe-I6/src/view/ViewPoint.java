package view;

import java.util.ArrayList;
import java.util.List;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import model.Column;
import model.IColumn;

public class  ViewPoint{

	protected ScrollPane sb = new ScrollPane();
    public VBox vBox=new VBox();
    public List<IColumn> cols;
    public Button add;
    
    public ViewPoint(){
    	sb.setContent(vBox);
    	sb.setPrefHeight(300);
    	//vBox.setAlignment(Pos.CENTER_RIGHT);
        List<Label> listLab = getLabel(50);
        List<TextArea> listText = getText(50);
        add = new Button("valider");
        for (int i = 0; i < listLab.size(); i++) {
            HBox hbox = new HBox();
            hbox.getChildren().add(listLab.get(i));
            hbox.getChildren().add(listText.get(i));
            hbox.setAlignment(Pos.CENTER);
            String cssLayout = "-fx-border-color: lightgrey;\n" +
                   "-fx-border-insets: 5;\n" +
                   "-fx-border-width: 1;\n" ;
            vBox.setStyle(cssLayout );
            vBox.getChildren().add(hbox);
        }
    }

    public void fill(int point,List<IColumn> cols ){
        this.cols = cols;
        vBox.getChildren().clear();

        List<Label> listLab = getLabel(cols.size());
        List<TextArea> listText = getText(cols.size());
        for (int i = 0; i < cols.size(); i++) {
            HBox hbox = new HBox();
            hbox.getChildren().add(listLab.get(i));
            hbox.getChildren().add(listText.get(i));
            hbox.setAlignment(Pos.TOP_RIGHT);
            String cssLayout = "-fx-border-color: lightgrey;\n" +
                   "-fx-border-insets: 5;\n" +
                   "-fx-border-width: 1;\n" ;
            vBox.setStyle(cssLayout );
            vBox.getChildren().add(hbox);
        }
        setText(point);   
    }


    public List<TextArea> getText(int nbCol){
        ArrayList<TextArea> listText = new ArrayList<>();
        for(int i=0;i<nbCol;i++){
            TextArea x = new TextArea();
            x.setMaxSize(100, 5);
            x.setEditable(false);
            listText.add(x);
        }
       return listText;
    }

    public List<Label> getLabel(int nbCol){
        ArrayList<Label> listLab = new ArrayList<>();
        for(int i=0;i<nbCol;i++){
            Label l = new Label(i+"     ");
            listLab.add(l);
        }
        return listLab;
    }

    public void setText(int point){
        HBox hbox;
        Label lab;
        TextArea txt;
        for (int i = 0; i < cols.size(); i++) {
            hbox = (HBox) vBox.getChildren().get(i);
            lab = (Label) hbox.getChildren().get(0);
            txt = (TextArea) hbox.getChildren().get(1);
            lab.setText(cols.get(i).getName());
            Column c =(Column) cols.get(i);            
            txt.setText((String) c.getValues().get(point));
        }
    }
    
    public void addPoint() {
    	HBox hbox;
    	TextArea txt;
    	for (int i = 0; i < cols.size(); i++) {
    		hbox = (HBox) vBox.getChildren().get(i);
            txt = (TextArea) hbox.getChildren().get(1);
            txt.setEditable(true);
            txt.setText("");
		}
    	vBox.getChildren().add(add);
    }
    
    
    public void normal() {
    	HBox hbox;
    	TextArea txt;
    	for (int i = 0; i < cols.size(); i++) {
    		hbox = (HBox) vBox.getChildren().get(i);
            txt = (TextArea) hbox.getChildren().get(1);
            txt.setEditable(false);
            this.setText(1);
		}
    	vBox.getChildren().remove(vBox.getChildren().size()-1);
    }
    
    public ScrollPane getScroll() {
    	return this .sb;
    }
}