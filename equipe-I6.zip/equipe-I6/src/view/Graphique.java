package view;


import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.Axis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.ScatterChart;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.Column;
import model.Dataset;
import model.FabriqueDataset;
import model.IColumn;
import model.IPoint;
import javafx.scene.chart.XYChart.Data;


public class Graphique {
	
	private XYChart.Series series1 = new XYChart.Series(); 
	private XYChart.Series series2 = new XYChart.Series(); 
	private XYChart.Series series3 = new XYChart.Series();
	private XYChart.Series selected = new XYChart.Series();
	protected ScatterChart<String, Number> scatterChart;
	protected Dataset ds;
	private List<IPoint> listePoint = new ArrayList<IPoint>();
	private IColumn x;
	private IColumn y;
	private NumberAxis xAxis;
	private NumberAxis yAxis;

    public Graphique(){
      //Defining the axes  
     
      this.xAxis = new NumberAxis(0 , 10,1); 
	  this.yAxis = new NumberAxis(0 , 10,1);

	  
	 
      //Creating the Scatter chart 
      scatterChart =  new ScatterChart(xAxis, yAxis);   

    }
    
    public Graphique(IColumn x, IColumn y) {
    	this.x=x;
		this.y=y;
		
		xAxis = new NumberAxis(); 
		xAxis.setLabel(x.getName());          
		series1.setName("Data1");
		series2.setName("Data2");
		series3.setName("Data3");
		selected.setName("Selected point");
		yAxis = new NumberAxis(); 
		//NumberAxis yAxis = new NumberAxis(y.normalizer.min, y.normalizer.max); 
		yAxis.setLabel(y.getName()); 
		
		scatterChart =  new ScatterChart(xAxis, yAxis);

    }

	public void setCols(IColumn x, IColumn y){
		this.x=x;
		this.y=y;
		
		xAxis = new NumberAxis(); 
		xAxis.setLabel(x.getName());          
			
		yAxis = new NumberAxis(); 
		//NumberAxis yAxis = new NumberAxis(y.normalizer.min, y.normalizer.max); 
		yAxis.setLabel(y.getName()); 
		scatterChart =  new ScatterChart(xAxis, yAxis);
	}
    
    
    @SuppressWarnings("unchecked")
	public void addPoint() {
    	int abs = ds.getColumns().indexOf(x);
		int ord = ds.getColumns().indexOf(y);
    	double valX = ds.getColumn(abs).getNormalizedValue(ds.getColumn(abs).getValues().get(ds.getPoints().size()-1));
		double valY  =ds.getColumn(ord).getNormalizedValue(ds.getColumn(ord).getValues().get(ds.getPoints().size()-1));
    	series1.getData().add(new XYChart.Data(valX, valY));
    	this.selected(ds.getPoints().size());
    }
    
    public void addAllPoints(Dataset ds) {
    	this.ds = ds;
    	double valX;
    	double valY;
    	
    	
    	Column special = ds.getClassified();
    	int nb =0;
    	List<Object> dejaVu = new ArrayList<Object>();
    	for (int i = 0; i <special.getValues().size(); i++) {
    		if (! dejaVu.contains(special.getValues().get(i))) {
    			dejaVu.add(special.getValues().get(i));
    			nb++;
    		}
    		
		}
    	System.out.println(nb);
    	int abs = ds.getColumns().indexOf(x);
		int ord = ds.getColumns().indexOf(y);
		
		if(nb == 2) {
			for(int i=0; i<ds.getNbLines();i++) {
				if( dejaVu.indexOf(special.getValues().get(i)) ==0 ) {
					series1.setName((String) special.getValues().get(i) );
					valX  =ds.getColumn(abs).getNormalizedValue(ds.getColumn(abs).getValues().get(i));
		    		valY  =ds.getColumn(ord).getNormalizedValue(ds.getColumn(ord).getValues().get(i));
		    		series1.getData().add(new XYChart.Data(valX, valY));
				}
				else {
					series2.setName((String) special.getValues().get(i) );
					valX  =ds.getColumn(abs).getNormalizedValue(ds.getColumn(abs).getValues().get(i));
		    		valY  =ds.getColumn(ord).getNormalizedValue(ds.getColumn(ord).getValues().get(i));
		    		series2.getData().add(new XYChart.Data(valX, valY));
				}
			}
		}
		
		else {
			for(int i=0; i<ds.getNbLines();i++) {
				
				if( dejaVu.indexOf(special.getValues().get(i)) ==0 ) {
					series1.setName((String) special.getValues().get(i) );
					//System.out.println("1");
					valX  =ds.getColumn(abs).getNormalizedValue(ds.getColumn(abs).getValues().get(i));
		    		valY  =ds.getColumn(ord).getNormalizedValue(ds.getColumn(ord).getValues().get(i));
		    		series1.getData().add(new XYChart.Data(valX, valY));
				}
				else if (dejaVu.indexOf(special.getValues().get(i)) ==1) {
					//System.out.println("2");
					valX  =ds.getColumn(abs).getNormalizedValue(ds.getColumn(abs).getValues().get(i));
		    		valY  =ds.getColumn(ord).getNormalizedValue(ds.getColumn(ord).getValues().get(i));
		    		series2.getData().add(new XYChart.Data(valX, valY));
		    		series2.setName((String) special.getValues().get(i) );
				}
				else {
					//System.out.println("3");
					valX  =ds.getColumn(abs).getNormalizedValue(ds.getColumn(abs).getValues().get(i));
		    		valY  =ds.getColumn(ord).getNormalizedValue(ds.getColumn(ord).getValues().get(i));
		    		series3.getData().add(new XYChart.Data(valX, valY));
		    		series3.setName((String) special.getValues().get(i) );
				}
				
			}
			
		}
		
    	scatterChart.getData().addAll(series1);
    	scatterChart.getData().addAll(series2);
    	scatterChart.getData().addAll(series3);
    	scatterChart.getData().addAll(selected);
    }
    
    
    public ScatterChart<String, Number> getScatterChart(){
    	return this.scatterChart;
    }

	public void selected(int num){
		selected.getData().clear();
		int abs = ds.getColumns().indexOf(x);
		int ord = ds.getColumns().indexOf(y);
		double valX  =ds.getColumn(abs).getNormalizedValue(ds.getColumn(abs).getValues().get(num-1));
		double valY  =ds.getColumn(ord).getNormalizedValue(ds.getColumn(ord).getValues().get(num-1));
		selected.getData().add(new XYChart.Data(valX, valY));
		//scatterChart.getData().add(selected);
	}
}