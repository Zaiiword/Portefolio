package controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.opencsv.exceptions.CsvValidationException;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.TextArea;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.Column;
import model.Dataset;
import model.DistanceEuclidienne;
import model.FabriqueDataset;
import model.IColumn;
import model.Iris;
import model.MethodeKnn;
import model.Pokemon;
import model.Titanic;
import view.AttributGraphique;
import view.Graphique;
import view.Toolbar;
import view.ViewPoint;
import view.ViewSelected;

public class Update {

	protected Dataset ds;
	protected Graphique graph;
	protected ViewPoint vp;
	protected ViewSelected vs;
	protected Toolbar toolbar;
	protected Stage primaryStage;
	protected AttributGraphique ag;
	protected Pane paneGraph;
	protected Column col1;
	protected Column col2;
	
	private int current;
	private int lenght;
	
	public Update(Graphique graph,ViewPoint vp,ViewSelected vs,Toolbar toolbar,Stage primaryStage,AttributGraphique ag,Pane paneGraph ) {
		this.graph=graph;
		this.vp=vp;
		this.vs=vs;
		this.toolbar=toolbar;
		this.ag =ag;
		this.paneGraph = paneGraph;
		
		
		current=0;
		lenght=0;
		
		importer();
		update();
	}
	
	public void update(){
        EventHandler<ActionEvent> eventPrevious = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e){previous();}
		};
        vs.previous.setOnAction(eventPrevious);

        EventHandler<ActionEvent> eventNext = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e){next();}
		};
        vs.next.setOnAction(eventNext);
        EventHandler<ActionEvent> loadFile = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e){next();}
		};
        vs.next.setOnAction(loadFile);
        EventHandler<ActionEvent> addPoint = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e){vp.addPoint();}
		};
        toolbar.ajoutPoint.setOnAction(addPoint);
        EventHandler<ActionEvent> del = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e){getNewPoint();}
		};
        vp.add.setOnAction(del);
        EventHandler<ActionEvent> actualiser = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e){updateAll();}
		};
        ag.valide.setOnAction(actualiser);
        EventHandler<ActionEvent> classe = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e){toolbar.classText();}
		};
        toolbar.classification.setOnAction(classe);
        EventHandler<ActionEvent> valide = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e){try {
				classification();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}}
		};
        toolbar.ok.setOnAction(valide);
    }
	
	public void importer(){
        EventHandler<ActionEvent> load = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e){
                FileChooser fileChooser = new FileChooser();
                FileChooser.ExtensionFilter extFilter = 
                        new FileChooser.ExtensionFilter("CSV files (*.csv)", "*.csv");
                fileChooser.getExtensionFilters().add(extFilter);
                File file = fileChooser.showOpenDialog(primaryStage);
                if (file != null) {
                    System.out.println(file);
                    try {
						ds = new FabriqueDataset(file.toString()).getDataset();
					} catch (CsvValidationException e1) {
						e1.printStackTrace();
					} catch (IOException e1) {
						e1.printStackTrace();
					} 
                    //setNormalizer();
                    ag.setAttribut(ds.getColumns());
                    updateAll();   
                    lenght=ds.getPoints().size();
                    current++;
                    updatePoint();
                    vs.update(current, lenght);
                    toolbar.ajoutPoint.setDisable(false);
                    toolbar.classification.setDisable(false);
                }   
            }
        };
        toolbar.importer.setOnAction(load);
    }
	
	public void updatePoint() {
		vp.fill(current-1,ds.getColumns());
	}
	
	public void updateAll() {
		col1 = null;
		col2 = null;
		for (IColumn col :  ds.getColumns()) {
			if (col.getName().equals(ag.x.getValue())){
				col1 = (Column) col;
			}
			if (col.getName().equals(ag.y.getValue())){
				col2 = (Column) col;
			}
		}
		paneGraph.getChildren().clear();
		this.graph =new Graphique(col1,col2);
		paneGraph.getChildren().add(graph.getScatterChart());
		//graph.setCols(col1, col2);
		graph.addAllPoints(ds);
		
	}
	
	
	public void next(){
		if(lenght !=0){
			current ++;
			if (current>lenght) {
				current=1;
			}
			vs.update(current,lenght);
			graph.selected(current);
			vp.setText(current-1);
		}
    }
    
    public void previous(){
		if(lenght !=0){
			current -- ;
			if (current<=0){
				current= lenght;
			}
			vs.update(current,lenght);
			graph.selected(current);
			vp.setText(current-1);
		}
    } 
    
    public void addPoint() {
    	graph.addPoint();
    	this.lenght=ds.getNbLines();
    	vs.update(lenght, lenght);
    }
    
    
    public void classification() throws IOException {
    	List<Column> col = new ArrayList<Column>();
    	col.add(col1);
    	col.add(col2);
    	MethodeKnn methodeKnn = new MethodeKnn(ds, col, new DistanceEuclidienne());
    	methodeKnn.classificationPoint(Integer.parseInt(toolbar.tx.getText()),ds.getPoint(current));
    	toolbar.remove(methodeKnn,Integer.parseInt(toolbar.tx.getText()),ds.getPoint(current));
    }
    
    public void getNewPoint() {
    	List<String> newPoint = new ArrayList<String>();
    	HBox hbox;
    	TextArea txt;
    	for (int i = 0; i < vp.cols.size(); i++) {
    		hbox = (HBox) vp.vBox.getChildren().get(i);
            txt = (TextArea) hbox.getChildren().get(1);
            newPoint.add(txt.getText());
            
		}
    	if(ds.getTitle() == "Titanic") {
    		Titanic i = new Titanic( Integer.parseInt(newPoint.get(0)) ,Boolean.parseBoolean(newPoint.get(1)),Integer.parseInt(newPoint.get(2)),newPoint.get(3),newPoint.get(4),Double.parseDouble(newPoint.get(5)),Integer.parseInt(newPoint.get(6)),Integer.parseInt(newPoint.get(7)),newPoint.get(8),Double.parseDouble(newPoint.get(9)),newPoint.get(10),newPoint.get(11).charAt(0));
    		ds.addLine(i);
    		
    	}
    	else if(ds.getTitle() == "Iris") {
    		Iris i = new Iris( Double.parseDouble(newPoint.get(0)) ,Double.parseDouble(newPoint.get(1)),Double.parseDouble(newPoint.get(2)),Double.parseDouble(newPoint.get(3)),newPoint.get(4));
    		
    		ds.addLine(i);
    	}
    	else {
    		Pokemon i = new Pokemon( newPoint.get(0) ,Double.parseDouble(newPoint.get(1)),Double.parseDouble(newPoint.get(2)),Double.parseDouble(newPoint.get(3)),Double.parseDouble(newPoint.get(4)),Double.parseDouble(newPoint.get(5)),Double.parseDouble(newPoint.get(6)),Double.parseDouble(newPoint.get(7)),Double.parseDouble(newPoint.get(8)),newPoint.get(9),newPoint.get(10),Double.parseDouble(newPoint.get(11)),Boolean.parseBoolean(newPoint.get(12)));
    		ds.addLine(i);
    	}
    	addPoint();
    	vp.normal();
    }
}
