package controller;

// import R_302.Column;
// import interfaces.IColumn;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import view.AttributGraphique;
import view.Graphique;
import view.Toolbar;
import view.ViewPoint;
import view.ViewSelected;

public class MainView extends Application{
	
	protected Graphique graph;
	protected ViewPoint vp;
	protected ViewSelected vs;
	protected Toolbar toolbar;
	private AttributGraphique ag;
	protected Pane paneGraph;
	

	@Override
    public void start(Stage primaryStage) throws InterruptedException {
	    //crée une fenêtre
	    Pane hBox=new VBox();
	    Scene scene = new Scene(hBox);
	    primaryStage.setScene(scene);

		//initialisation
		Pane bas = new HBox();
		Pane droite = new VBox();
		

	    //nom App
	    primaryStage.setTitle("KNN");
	    primaryStage.setResizable(false);
		//primaryStage.setFullScreen(true);
	    
		//ajout de la toolbar
		this.toolbar = new Toolbar();
		hBox.getChildren().add(toolbar.getToolBar());   
	    
	    //ajout graphique
	    this.graph = new Graphique();
	    paneGraph = new Pane();
	    
	    paneGraph.getChildren().add(graph.getScatterChart());
		bas.getChildren().add(paneGraph);

		//ajout attribut graphique
		ag = new AttributGraphique();
		droite.getChildren().add(ag.getVbox());
		
		droite.setPrefWidth(250);
	    droite.setMaxWidth(250);

		//ajout viewPoint
		vp = new ViewPoint();
		droite.getChildren().add(vp.getScroll());

		//ajout viewSelect
	    vs = new ViewSelected();
	    droite.getChildren().add(vs.getVBox());	
		
		hBox.getChildren().add(bas);
		bas.getChildren().add(droite);

		Update update= new Update(graph,vp,vs,toolbar,primaryStage, ag,paneGraph);

	    //affiche
	    primaryStage.show();
	}
	

	
	public static void main(String[] args) {
		launch(args);
	}
}
