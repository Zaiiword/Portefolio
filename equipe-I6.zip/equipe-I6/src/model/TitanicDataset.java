package model;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.exceptions.CsvValidationException;

public class TitanicDataset extends Dataset{

	public TitanicDataset(String path) {
		this.path = path;
		try {
			this.nbColumn = this.setNbColumn();
		} catch (CsvValidationException | IOException e) {
			e.printStackTrace();
		}
		this.columns = new ArrayList<IColumn>();
		try {
			this.points = this.chargerIPoint(path);
		} catch (CsvValidationException | IOException e) {
			e.printStackTrace();
		}
		this.classified = (Column) this.columns.get(1);
	}
	


	@Override
	public String getTitle() {
		return "Titanic";
	}
	

	@Override
	public List<IPoint> chargerIPoint(Reader reader) throws IOException, CsvValidationException {
		//cree la colonne et l'ajoute à la liste de colonne
		for(int i = 0; i < this.nbColumn; i++) {
			Column colonneToAdd = new Column(i, path);
			//set le normalizer pour chaque colonne
			if(i==1) {
				colonneToAdd.setNormalizer(new BooleanNormalizer(colonneToAdd));
			}else if(i==(this.nbColumn-3)) {
				colonneToAdd.setNormalizer(new NumberNormalizer(colonneToAdd));
			}else {
				PokemonTypeNormalizer enumNorm = new PokemonTypeNormalizer(colonneToAdd);
				enumNorm.normalizeEnum();
				colonneToAdd.setNormalizer(enumNorm);
			}
			this.columns.add(colonneToAdd);
		}
		return new CsvToBeanBuilder<IPoint>(reader)
				.withSeparator(',')
				.withType(Titanic.class).build().parse();
	}
	
	public static void main(String[] args) throws CsvValidationException, IOException {
		TitanicDataset tds = new TitanicDataset("//home/iutinfo/eclipse-workspace/equipe-I6/src/exemple/titanic/titanic.csv");
		System.out.println(tds.getPoints().get(0));
		System.out.println(tds.getColumns().get(tds.nbColumn-3));
		System.out.println(tds.classified.getNormalizer());
		
	}



}
