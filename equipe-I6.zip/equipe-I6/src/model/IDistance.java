package model;

import java.util.List;


public interface IDistance {

	double distance(Dataset dataset, List<Column> colonnes, IPoint p1, IPoint p2);
}
