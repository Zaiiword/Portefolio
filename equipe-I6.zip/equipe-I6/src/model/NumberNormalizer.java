package model;

import java.util.HashMap;
import java.util.Map;

public class NumberNormalizer implements IValueNormalizer{
	private double max;
	private double min;
	private Column col;
	private double amplitude;
	private Map<Object, Double> values;
	
	public NumberNormalizer(Column col) {
		this.values = new HashMap<Object, Double>();
		this.col = col;
		setAll();
	}
	public void setAll(){
		setMax();
		setMin();
		this.amplitude = max-min;
	}
	public void setMax(){
		double res = -1.0;
		String val = "";
		for(int i=0 ; i<this.col.getValues().size() ; i++) {
			val = (String) this.col.getValues().get(i);
			if( Double.parseDouble(val) > res) {
				res = Double.parseDouble(val);	
			}
		}
		this.max = res;
	}
	public void setMin(){
		double res = max;
		String val = "";
		for(int i=0 ; i<this.col.getValues().size() ; i++) {
			val = (String) this.col.getValues().get(i);
			if(Double.parseDouble(val)<res) {
				res = Double.parseDouble(val);	
			}
		}
		this.min = res;
	}
	@Override
	public double normalize(Object value) {
		String res =""+value;
		return (Double.parseDouble(res)-min)/amplitude;
	}
	public void normalizeAll() {
		for(int i=0 ; i<this.col.getValues().size() ; i++) {
			this.values.put(this.col.getValues().get(i), normalize(this.col.getValues().get(i)));
		}
	}

	@Override
	public Object denormalize(double value) {
		Object res = null;
		for(Map.Entry<Object, Double> mEntry : values.entrySet()) {
			if(mEntry.getValue() == value) {
				res = mEntry.getKey();
			}
		}
		return res;
	}
	public double getMax() {
		return max;
	}
	public void setMax(double max) {
		this.max = max;
	}
	public double getMin() {
		return min;
	}
	public void setMin(double min) {
		this.min = min;
	}
	public Column getCol() {
		return col;
	}
	public void setCol(Column col) {
		this.col = col;
	}
	public double getAmplitude() {
		return amplitude;
	}
	public void setAmplitude(double amplitude) {
		this.amplitude = amplitude;
	}
	public Map<Object, Double> getValues() {
		return values;
	}
	public void setValues(Map<Object, Double> values) {
		this.values = values;
	}
	
}
