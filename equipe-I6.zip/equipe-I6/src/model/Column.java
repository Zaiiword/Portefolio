package model;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

public class Column implements IColumn {

	protected String name;
	protected List<Object> values;
	protected String path;
	protected int numCol;
	protected IValueNormalizer normalizer;

	public Column(int col, String path) {
		this.numCol = col;
		this.path = path;
		this.values = new ArrayList<Object>();
		try {
			setColonne();
		} catch (CsvValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			setName();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.normalizer = this.attributeNormalizer();


	}
	public void setColonne() throws IOException, CsvValidationException{
		CSVReader reader = new CSVReader(new FileReader(path));
		String[]nextLine;
		reader.skip(1);
		while ((nextLine = reader.readNext()) != null){
			this.values.add(nextLine[numCol]);
		}
	}
	

	@Override
	public void setNormalizer(IValueNormalizer valueNormalizer) {
		this.normalizer = valueNormalizer;
	}

	public List<Object> getValues() {
		return values;
	}
	

	public void setColonne(List<Object> colonne) {
		this.values = colonne;
	}
	public void setName() throws IOException {
		CSVReader reader = new CSVReader(new FileReader(path));
		this.name = reader.peek()[numCol];
	}
	@Override
	public String getName() {
		return name;
	}
	@Override
	public boolean isNormalizable() {
		return this.normalizer!=null;
	}
	@Override
	public double getNormalizedValue(Object value) {
		return this.normalizer.normalize(value);
	}
	@Override
	public Object getDenormalizedValue(double value) {
		return this.normalizer.denormalize(value);
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public int getNumCol() {
		return numCol;
	}
	public void setNumCol(int numCol) {
		this.numCol = numCol;
	}
	public IValueNormalizer getNormalizer() {
		return normalizer;
	}
	public void setValues(List<Object> values) {
		this.values = values;
	}

	@Override
	public String toString() {
		String string = ""+this.name + " : ";
		for(Object o : this.values) {
			string += " "+ o + " ";
		}
		return string;
	}
	@Override
	public IValueNormalizer attributeNormalizer() {
		// TODO Auto-generated method stub
		return null;
	}
}
