package model;

import java.util.ArrayList;
import java.util.List;

import com.opencsv.bean.CsvBindByName;

public class Iris implements IPoint{

	@CsvBindByName(column = "sepal.length")
	protected double sepal_length;
	@CsvBindByName(column = "sepal.width")
	protected double sepal_width;
	@CsvBindByName(column = "petal_length")
	protected double petal_length;
	@CsvBindByName(column = "petal_width")
	protected double petal_width;
	@CsvBindByName(column = "variety")
	protected String variety;

	public Iris(double sepal_length, double sepal_width, double petal_length, double petal_width, String variety) {
		super();
		this.sepal_length = sepal_length;
		this.sepal_width = sepal_width;
		this.petal_length = petal_length;
		this.petal_width = petal_width;
		this.variety = variety;
	}
	
	public Iris() {
		
	}
	
	@Override
	public String toString() {
		return "Iris [sepal_length=" + sepal_length + ", sepal_width=" + sepal_width + ", petal_length=" + petal_length
				+ ", petal_width=" + petal_width + ", variety=" + variety + "]";
	}

	@Override
	public List<Object> getValue(IColumn col) {
		List<Object> liste = new ArrayList<Object>();
		liste.add(sepal_length);
		liste.add(sepal_width);
		liste.add(petal_length);
		liste.add(petal_width);
		liste.add(variety);
		return liste;
	}

	@Override
	public double getNormalizedValue(IColumn xcol) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return null;
	}

}
