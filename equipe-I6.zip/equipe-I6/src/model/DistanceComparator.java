package model;

import java.util.Comparator;
import java.util.List;

public class DistanceComparator implements Comparator<IPoint> {

	private IPoint origine;
	private IDistance distance;
	private List<Column> colonnes;
	private Dataset dataset;

	DistanceComparator(Dataset dataset, List<Column> colonnes, IPoint origine, IDistance distance){
		this.dataset = dataset;
		this.origine = origine;
		this.distance = distance;
		this.colonnes = colonnes;
	}

	@Override
	public int compare(IPoint p1, IPoint p2) {
		if(distance.distance(dataset, colonnes, p1,origine)-distance.distance(dataset, colonnes, p2, origine)<.0000001) {
			return 0;
		}
		if(distance.distance(dataset, colonnes, p1,origine)>distance.distance(dataset, colonnes, p2, origine)) {
			return -1;
		}else if(distance.distance(dataset, colonnes, p1,origine)<distance.distance(dataset, colonnes, p2, origine)) {
			return 1;
		}
		return 0;

	}



}
