package model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opencsv.exceptions.CsvValidationException;

public class PokemonTypeNormalizer implements IValueNormalizer{

	private List<Object> differents;
	private Map<Object, Double> values;
	private Column colonne;

	public PokemonTypeNormalizer(Column column) {
		this.differents = new ArrayList<Object>();
		this.values = new HashMap<Object, Double>();
		this.colonne = column;
	}

	public void setDifferents() throws IOException {
		for(int i=0 ; i<this.colonne.getValues().size() ; i++) {
			if(!this.differents.contains(this.colonne.getValues().get(i))) {
				this.differents.add(this.colonne.getValues().get(i));
			}
		}
	}

	public void normalizeEnum() throws IOException, CsvValidationException {
		setDifferents();
		double value = 1./(this.differents.size());
		for(int i=0 ; i<this.differents.size() ; i++) {
			this.values.put(this.differents.get(i),(i+1)*value);
		}
	}

	@Override
	public Object denormalize(double value) {
		Object res = null;
		for(Map.Entry<Object, Double> mEntry : values.entrySet()) {
			if(mEntry.getValue() == value) {
				res = mEntry.getKey();
			}
		}
		return res;
	}
	@Override
	public double normalize(Object obj) {
		double res = -1;
		for(Map.Entry<Object, Double> mEntry : values.entrySet()) {
			if(mEntry.getKey().equals(obj)) {
				res = mEntry.getValue();
			}
		}
		return res;

	}
	public List<Object> getDifferents() {
		return differents;
	}

	public void setDifferents(List<Object> differents) {
		this.differents = differents;
	}

	public Map<Object, Double> getValues() {
		return values;
	}

	public void setValues(Map<Object, Double> values) {
		this.values = values;
	}

	public Column getColonne() {
		return colonne;
	}

	public void setColonne(Column colonne) {
		this.colonne = colonne;
	}

	public static void main(String[] args) throws CsvValidationException, IOException {
		FabriqueDataset fb = new FabriqueDataset("./src/exemple/iris/iris.csv");
		Dataset ds = fb.getDataset();
		for(int i=0; i<ds.getNbLines();i++) {
			System.out.println(ds.classified.getNormalizedValue(ds.classified.getValues().get(i)));
		}
	}
}
