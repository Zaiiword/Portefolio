package model;

public class BooleanNormalizer implements IValueNormalizer{
	private Object toCompare;
	private Object compared;
	
	public BooleanNormalizer(Object toCompare) {
		this.toCompare = toCompare;
	}

	@Override
	public double normalize(Object value) {
		this.compared = value;
		double res =1.0;
		if(this.toCompare.equals(value)) {
			res = 0.0;
		}
		return res;
	}

	@Override
	public Object denormalize(double value) {
		return compared;
	}
}
