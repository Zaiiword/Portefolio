package model;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.exceptions.CsvValidationException;

public class IrisDataset extends Dataset{

	public IrisDataset(String path){
		this.path = path;
		try {
			this.nbColumn = this.setNbColumn();
		} catch (CsvValidationException | IOException e) {
			e.printStackTrace();
		}
		this.columns = new ArrayList<IColumn>();
		try {
			this.points = this.chargerIPoint(path);
		} catch (CsvValidationException | IOException e) {
			e.printStackTrace();
		}
		this.classified = (Column) this.columns.get(4);
	}
	


	@Override
	public String getTitle() {
		return "Iris";
	}
	

	
	@Override
	public List<IPoint> chargerIPoint(Reader reader) throws IOException, CsvValidationException {
		//cree la colonne et l'ajoute à la liste de colonne
		for(int i = 0; i < this.nbColumn; i++) {
			Column colonneToAdd = new Column(i, path);
			//set le normalizer pour chaque colonne
			if(i==(this.nbColumn-1)) {
				PokemonTypeNormalizer enumNorm = new PokemonTypeNormalizer(colonneToAdd);
				enumNorm.normalizeEnum();
				colonneToAdd.setNormalizer(enumNorm);
			}else {
				colonneToAdd.setNormalizer(new NumberNormalizer(colonneToAdd));
			}
			this.columns.add(colonneToAdd);
		}
		return new CsvToBeanBuilder<IPoint>(reader)
				.withSeparator(',')
				.withType(Iris.class).build().parse();
	}
	
	public static void main(String[] args) throws CsvValidationException, IOException {
		IrisDataset ids = new IrisDataset("./src/exemple/iris/iris.csv");
		System.out.println(ids.getPoint(0));
		System.out.println(ids.classified.getNormalizer());
		System.out.println(ids.classified);

	}



}
