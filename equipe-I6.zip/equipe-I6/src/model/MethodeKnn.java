package model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opencsv.exceptions.CsvValidationException;

public class MethodeKnn {

	public  Dataset datas;
	protected  List<Column> colonnesClassifieurs;
	protected  IDistance distance;

	public MethodeKnn( Dataset data, List<Column> cols, IDistance distance) throws IOException {
		this.datas = data;
		this.colonnesClassifieurs = cols;
		this.distance = distance;

	}


	public MethodeKnn(String string, List<Column> cols, IDistance distance) throws CsvValidationException, IOException {
		this(new FabriqueDataset(string).dataset,cols,distance);

	}


	public  List<IPoint> plusProchesVoisins(int k, IPoint point){
		List<IPoint> datasSorted = datas.getPoints() ;
		datasSorted.sort(new DistanceComparator(this.datas, colonnesClassifieurs, point, this.distance));
		return datasSorted.subList(1, k+1);
	}


	/*
	 * La classification se fait sur une colonne à partir du nombre d'occurence de cette dernière chez les k voisins
	 */
	public void classificationPoint(int k, IPoint point) {
		List<IPoint> kVoisins = this.plusProchesVoisins(k, point);
		Map<Object, Integer> valColonne = new HashMap<Object, Integer>();

		for(IPoint pt : kVoisins) {
			valColonne.putIfAbsent(datas.getValue(pt, this.datas.classified), 0);
			valColonne.computeIfPresent(datas.getValue(pt, this.datas.classified), (valeur, nbOccurrences) -> nbOccurrences + 1);		
			//System.out.println(valColonne);
		}

		//obtient la valeur la plus possedee par les k voisins
		Object value = valColonne.keySet().stream().max(Comparator.comparing(valColonne::get)).orElse(null);
		datas.setClassifiedDenormalizedValue(value, point);


	}

	public double calculRobustesse(int k) {
		Dataset modified = this.datas;
		double bienclassifie = 0;
		for(int i = 0; i < modified.getNbLines(); i++) {
			classificationPoint(k, modified.getPoint(i));
			if(modified.getValue(modified.getPoint(i),modified.classified).equals(datas.getValue(datas.getPoint(i),datas.classified))) {
				bienclassifie++;
			}

		}
		return (bienclassifie / modified.getNbLines()) * 100.0;
	}

	public static void main(String[] args) throws CsvValidationException, IOException {
		FabriqueDataset fabrique = new FabriqueDataset("./src/model/pokemon_train.csv");
		Dataset dataset = fabrique.dataset;
		
		
//		System.out.println(dataset.getValue(dataset.getPoint(12), dataset.getColumn(0)));
		
		List<Column> col = new ArrayList<Column>();
		col.add((Column) dataset.getColumns().get(1));
		col.add((Column) dataset.getColumns().get(4));
//		System.out.println(dataset.getColumns().get(1).getName());
//		System.out.println(dataset.getColumns().get(2).getName());
		DistanceEuclidienne d = new DistanceEuclidienne();
		MethodeKnn knn = new MethodeKnn(dataset, col, d);
		
		System.out.println(knn.datas.getPoint(12));
		System.out.println(knn.plusProchesVoisins(1, knn.datas.getPoint(12)));
		for(IPoint point : knn.plusProchesVoisins(10, knn.datas.getPoint(12))) {
			System.out.println(d.distance(knn.datas, col, knn.datas.getPoint(12), point));
		}
//		knn.classificationPoint(5, knn.datas.getPoints().get(58), knn.datas.classified);
//		System.out.println(knn.calculRobustesse(5,knn.datas.classified));

	}

}
