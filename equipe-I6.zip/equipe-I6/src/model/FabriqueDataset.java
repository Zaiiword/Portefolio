package model;

import java.io.IOException;

import com.opencsv.exceptions.CsvValidationException;

public class FabriqueDataset {
	
	protected Dataset dataset;
	
	public FabriqueDataset(String path) throws CsvValidationException, IOException {
		if(path.contains("iris")){
			this.dataset = new IrisDataset(path);
		}else if(path.contains("pokemon")) {
			this.dataset = new PokemonDataset(path);
		}else if(path.contains("titanic")) {
			this.dataset = new TitanicDataset(path);
		}

	}
	
	public static void main(String[] args) throws CsvValidationException, IOException {
		Dataset dt = new PokemonDataset("/home/iutinfo/eclipse-workspace/equipe-I6/src/exemple/pokemon/pokemon_train.csv");
		System.out.println(dt.getColumns().get(0));
	}

	public Dataset getDataset() {
		return dataset;
	}
}
