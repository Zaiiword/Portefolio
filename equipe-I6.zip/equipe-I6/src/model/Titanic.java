package model;

import java.util.ArrayList;
import java.util.List;

import com.opencsv.bean.CsvBindByName;

public class Titanic extends DistanceManhattan implements IPoint{
	
	@CsvBindByName(column = "PassengerId")
	protected int passengerId;
	@CsvBindByName(column = "Survived")
	protected boolean survivor;
	@CsvBindByName(column = "Pclass")
	protected int pClass;
	@CsvBindByName(column = "Name")
	protected String name;
	@CsvBindByName(column = "Sex")
	protected String sex;
	@CsvBindByName(column = "Age")
	protected double age;
	@CsvBindByName(column = "SibSp")
	protected int sibSp;
	@CsvBindByName(column = "Parch")
	protected int parch;
	@CsvBindByName(column = "Ticket")
	protected String ticket;
	@CsvBindByName(column = "Fare")
	protected double fare;
	@CsvBindByName(column = "Cabin")
	protected String cabin;
	@CsvBindByName(column = "Embarked")
	protected char embarked;
	
	public Titanic(int passengerId, boolean survivor, int pClass, String name, String sex,double age, int sibSp, int parch, String ticket, double fare, String cabin, char embarked) {
		this.passengerId = passengerId;
		this.survivor = survivor;
		this.pClass = pClass;
		this.name = name;
		this.sex = sex;
		this.age = age;
		this.sibSp = sibSp;
		this.parch = parch;
		this.ticket = ticket;
		this.fare = fare;
		this.cabin = cabin;
		this.embarked = embarked;
	}
	
	public Titanic() {
		
	}

	public void calculAmpl(List<IPoint> listPoint) {
		// TODO Auto-generated method stub
	}

	@Override
	public String toString() {
		return "Titanic [passengerId=" + passengerId + ", survivor=" + survivor + ", pClass=" + pClass + ", name="
				+ name + ", sex=" + sex + ", age=" + age + ", sibSp=" + sibSp + ", parch=" + parch + ", ticket="
				+ ticket + ", fare=" + fare + ", cabin=" + cabin + ", embarked=" + embarked + "]";
	}

	@Override
	public List<Object> getValue(IColumn col) {
		List<Object> liste = new ArrayList<Object>();
		liste.add(passengerId);
		liste.add(survivor);
		liste.add(pClass);
		liste.add(name);
		liste.add(sex);
		liste.add(age);
		liste.add(sibSp);
		liste.add(parch);
		liste.add(ticket);
		liste.add(fare);
		liste.add(cabin);
		liste.add(embarked);
		return liste;
	}

	@Override
	public double getNormalizedValue(IColumn xcol) {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
