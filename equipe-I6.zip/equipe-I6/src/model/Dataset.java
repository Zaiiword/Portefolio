package model;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

public abstract class Dataset implements IDataset {
	protected List<IColumn> columns;
	protected List<IPoint> points;
	protected Column classified;
	protected String path;
	protected int nbColumn;


	//TODO mettre csvreader attribut et utilis
	public int setNbColumn() throws IOException, CsvValidationException {
		CSVReader reader = new CSVReader(new FileReader(path));
		String[] tab = reader.readNext();
		return tab.length;
	}
	@Override
	public Iterator<IPoint> iterator() {
		return points.iterator();
	}

	public  List<IPoint> chargerIPoint(String fileName) throws IOException, CsvValidationException{
		try {
			return chargerIPoint(Files.newBufferedReader(Paths.get(fileName)));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public abstract List<IPoint> chargerIPoint(Reader reader) throws IOException, CsvValidationException;

	@Override
	public abstract String getTitle();

	@Override
	public int getNbLines() {
		return points.size();
	}

	public IColumn getColumn(int nbCol) {
		return this.columns.get(nbCol);
	}

	public IPoint getPoint(int nbPt) {
		return this.points.get(nbPt);
	}

	public Object getValue(IPoint point, IColumn colonne) {
		int iC = columns.indexOf(colonne);
		int iP = points.indexOf(point);
		if(iC<0) {iC++;}
		if(iP<0) {iP++;}
		//System.out.println(this.columns.get(iC).getValues().get(iP));
		return this.columns.get(iC).getValues().get(iP);			

	}

	@Override
	public void setLines(List<IPoint> lines) {
		points.clear();
		points.addAll(lines);
	}


	public List<IColumn> getColumns() {
		return columns;
	}
	@Override
	public void addLine(IPoint element) {
		this.points.add(element);
		for(int i=0 ; i<this.columns.size() ; i++) {
			this.getColumns().get(i).getValues().add(element.getValue(this.getColumn(3)).get(i));
		}
	}
	@Override
	public void addAllLine(List<IPoint> element) {
		for(IPoint pt : element) { addLine(pt); }
	}
	@Override
	public List<IPoint> getPoints() {
		return this.points;
	}

	public void setClassifiedDenormalizedValue(Object value, IPoint point) {
		classified.values.set(this.getPoints().indexOf(point),value);
	}
	
	public Column getClassified() {
		return this.classified;
	}

}
