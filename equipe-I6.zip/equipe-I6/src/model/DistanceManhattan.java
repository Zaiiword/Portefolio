package model;

import java.util.List;

public class DistanceManhattan implements IDistance {

	@Override
	public double distance(Dataset dataset, List<Column> colonnes, IPoint p1, IPoint p2) {
		double distances=0;
		for(IColumn col :  colonnes) {
			distances += Math.abs((col.getNormalizedValue(dataset.getValue(p1, col)) - col.getNormalizedValue(dataset.getValue(p2, col))));
		}
		return distances ;
	}
	
	
}
