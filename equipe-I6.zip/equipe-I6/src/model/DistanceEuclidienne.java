package model;

import java.util.List;

public class DistanceEuclidienne implements IDistance{
	

	public double distance(Dataset dataset, List<Column> colonnes, IPoint p1, IPoint p2) {
		double distances=0;
		for(Column col :  colonnes) {
			distances += Math.pow((col.getNormalizedValue(dataset.getValue(p1, col)) - col.getNormalizedValue(dataset.getValue(p2, col))),2);
		}
		return Math.sqrt(distances) ;
	}

}
