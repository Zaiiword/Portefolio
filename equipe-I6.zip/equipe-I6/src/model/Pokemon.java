package model;

import java.util.ArrayList;
import java.util.List;

import com.opencsv.bean.CsvBindByName;

public class Pokemon implements IPoint{
	@CsvBindByName(column = "name")
	public String name;
	@CsvBindByName(column = "attack")
	public double attack;
	@CsvBindByName(column = "base_egg_steps")
	public double base_egg_steps;
	@CsvBindByName(column = "capture_rate")
	public double capture_rate;
	@CsvBindByName(column = "defense")
	public double defense;
	@CsvBindByName(column = "experience_growth")
	public double experience_growth;
	@CsvBindByName(column = "hp")
	public double hp;
	@CsvBindByName(column = "sp_attack")
	public double sp_attack;
	@CsvBindByName(column = "sp_defense")
	public double sp_defense;
	@CsvBindByName(column = "type1")
	public String type1;
	@CsvBindByName(column = "type2")
	public String type2;
	@CsvBindByName(column = "speed")
	public double speed;
	@CsvBindByName(column = "is_legendary")
	public boolean is_legendary;

	public Pokemon(String name, double attack, double base_egg_steps, double capture_rate, double defense, double experience_growth, double hp, double sp_attack, double sp_defense, String type1, String type2, double speed, boolean is_legendary) {
		this.name = name;
		this.attack = attack;
		this.base_egg_steps = base_egg_steps;
		this.capture_rate = capture_rate;
		this.defense = defense;
		this.experience_growth = experience_growth;
		this.hp = hp;
		this.sp_attack = sp_attack;
		this.sp_defense = sp_defense;
		this.type1 = type1;
		this.type2 = type2;
		this.speed = speed;
		this.is_legendary = is_legendary;
	}
	
	public Pokemon() {
		
	}

	@Override
	public String toString() {
		return "Pokemon{" +
				"name='" + name + '\'' +
				", attack=" + attack +
				", base_egg_steps=" + base_egg_steps +
				", capture_rate=" + capture_rate +
				", defense=" + defense +
				", experience_growth=" + experience_growth +
				", hp=" + hp +
				", sp_attack=" + sp_attack +
				", sp_defense=" + sp_defense +
				", type1='" + type1 + '\'' +
				", type2='" + type2 + '\'' +
				", speed=" + speed +
				", is_legendary=" + is_legendary +
				"}";
	}





	@Override
	public List<Object> getValue(IColumn col) {
		List<Object> liste = new ArrayList<Object>();
		liste.add(name);
		liste.add(attack);
		liste.add(base_egg_steps);
		liste.add(capture_rate);
		liste.add(defense);
		liste.add(experience_growth);
		liste.add(hp);
		liste.add(sp_attack);
		liste.add(sp_defense);
		liste.add(type1);
		liste.add(type2);
		liste.add(speed);
		liste.add(is_legendary);
		return liste;
	}

	@Override
	public double getNormalizedValue(IColumn xcol) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return null;
	}







}