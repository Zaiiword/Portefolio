package normalize;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Map;

import org.junit.jupiter.api.Test;

import model.Column;
import model.NumberNormalizer;

public class NumberNormalizerTest{

	public Column col = new Column(2, "./src/model/pokemon_train.csv");
	public NumberNormalizer test = new NumberNormalizer(col);
	
	@Test
	public void normalizeAllTest() {
		test.normalizeAll();
		double max = -1;
		for(Map.Entry<Object, Double> mEntry : test.getValues().entrySet()) {
			if(mEntry.getValue()>max) {
				max = mEntry.getValue();
			}
		}
		double min = max;
		for(Map.Entry<Object, Double> mEntry : test.getValues().entrySet()) {
			if(mEntry.getValue()<min) {
				min = mEntry.getValue();
			}
		}
		boolean res = false;
		for(Map.Entry<Object, Double> mEntry : test.getValues().entrySet()) {
			if(mEntry.getValue()<=max && mEntry.getValue()>=min) {
				res = true;
			}
		}
		assertTrue(res);
	}
	@Test
	public void normalizeTest() {
		test.normalizeAll();
		double save = -1;
		for(Map.Entry<Object, Double> mEntry : test.getValues().entrySet()) {
			if(mEntry.getKey() == col.getValues().get(0)) {
				save = mEntry.getValue();
			}
		}
		assertEquals(test.normalize(col.getValues().get(0)), save);
		assertNotEquals(test.normalize(col.getValues().get(12)), save);
	}
	@Test
	public void denormalizeTest() {
		test.normalizeAll();
		double save = -1;
		for(Map.Entry<Object, Double> mEntry : test.getValues().entrySet()) {
			if(mEntry.getKey() == col.getValues().get(0)) {
				save = mEntry.getValue();
			}
		}
		assertEquals(test.denormalize(save), col.getValues().get(0) );
		
	}
}
