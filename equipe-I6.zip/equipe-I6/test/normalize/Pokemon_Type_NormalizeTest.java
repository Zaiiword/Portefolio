package normalize;

import static org.junit.jupiter.api.Assertions.*;
import java.io.IOException;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.opencsv.exceptions.CsvValidationException;

import model.Column;
import model.PokemonTypeNormalizer;

class Pokemon_Type_NormalizeTest {

	Column colonne = new Column(9, "./src/model/pokemon_train.csv");
	PokemonTypeNormalizer test = new PokemonTypeNormalizer(colonne);

	@Test
	public void testSetDifferents() throws IOException {
		test.setDifferents();
		boolean estDiff = true;
		Object save = null;
		for(int i=0 ; i<test.getDifferents().size() ; i++) {
			save = test.getDifferents().get(i);
			for (int j = i+1; j < test.getDifferents().size(); j++) {
				if(test.getDifferents().get(j)==save) {
					estDiff = false;
				}
			}
		}
		assertTrue(estDiff);
	}
	@Test
	public void testNormalizeEnum() throws IOException, CsvValidationException {
		test.setDifferents();
		test.normalizeEnum();
		double max = -1;
		for(Map.Entry<Object, Double> mEntry : test.getValues().entrySet()) {
			if(mEntry.getValue()>max) {
				max = mEntry.getValue();
			}
		}
		double min = max;
		for(Map.Entry<Object, Double> mEntry : test.getValues().entrySet()) {
			if(mEntry.getValue()<min) {
				min = mEntry.getValue();
			}
		}
		boolean res = false;
		for(Map.Entry<Object, Double> mEntry : test.getValues().entrySet()) {
			if(mEntry.getValue()<=max && mEntry.getValue()>=min) {
				res = true;
			}
		}
		assertTrue(res);
	}
	@Test
	public void testNormalize() throws IOException, CsvValidationException {
		test.setDifferents();
		test.normalizeEnum();
		assertEquals(test.normalize(colonne.getValues().get(0)), (1.0/(test.getDifferents().size()))*((test.getDifferents().indexOf(colonne.getValues().get(0)))+1));
		assertNotEquals(test.normalize(colonne.getValues().get(0)), (1.0/(test.getDifferents().size()))*((test.getDifferents().indexOf(colonne.getValues().get(1)))+1));
	}
	@Test
	public void testDenormalize() throws IOException, CsvValidationException {
		test.setDifferents();
		test.normalizeEnum();
		double save = 0.0;
		double save2 = 0.0;
		for(Map.Entry<Object, Double> mEntry : test.getValues().entrySet()) {
			if(mEntry.getKey() == colonne.getValues().get(0)) {
				save = mEntry.getValue();
			}
			if(mEntry.getKey() == colonne.getValues().get(1)) {
				save2 = mEntry.getValue();
			}
		}
		assertEquals(test.getDifferents().get(0), test.denormalize(save));
		assertNotEquals(test.getDifferents().get(1), test.denormalize(save));
		assertEquals(test.getDifferents().get(1), test.denormalize(save2));
	}
}