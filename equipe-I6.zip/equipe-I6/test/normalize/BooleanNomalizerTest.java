package normalize;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

import model.BooleanNormalizer;
import model.Column;

public class BooleanNomalizerTest {
	
	public Column colonne = new Column(12, "./src/model/pokemon_train.csv");
	public BooleanNormalizer bn = new BooleanNormalizer(colonne.getValues().get(0));

	@Test
	void normalize() {
		assertEquals(0.0, bn.normalize(colonne.getValues().get(1)));
		assertEquals(1.0, bn.normalize(colonne.getValues().get(12)));
		assertNotEquals(0.0, bn.normalize(colonne.getValues().get(12)));
	}
}
