package distance;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.opencsv.exceptions.CsvValidationException;

import model.Column;
import model.Dataset;
import model.DistanceEuclidienne;
import model.FabriqueDataset;
import model.IColumn;

class Distance_Euclidienne_Test {
	

	@Test
	void distance() throws CsvValidationException, IOException{
		   Dataset ds = new FabriqueDataset("./src/model/pokemon_train.csv").getDataset();
		   List<Column> test = new ArrayList<Column>();
		   for (IColumn col : ds.getColumns()) {
			test.add((Column)col);
		   }
		   DistanceEuclidienne de = new DistanceEuclidienne();
	        assertEquals(00.3645459476315347, de.distance(ds, test, ds.getPoint(1), ds.getPoint(2)));
	        assertNotEquals(2.0, de.distance(ds, test, ds.getPoint(1), ds.getPoint(2)));
	        assertNotEquals(null, de.distance(ds, test, ds.getPoint(1), ds.getPoint(2)));
	        assertEquals(0.4223784740112931, de.distance(ds, test, ds.getPoint(3), ds.getPoint(4)));
	        assertNotEquals(2.0, de.distance(ds, test, ds.getPoint(3), ds.getPoint(4)));
	        assertNotEquals(null, de.distance(ds, test, ds.getPoint(3), ds.getPoint(4)));
		
	}

}
