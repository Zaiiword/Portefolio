package distance;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.opencsv.exceptions.CsvValidationException;

import model.Column;
import model.Dataset;
import model.DistanceManhattan;
import model.FabriqueDataset;
import model.IColumn;

class distance_Manhattan_Test {

	@Test
	void distance() throws CsvValidationException, IOException {
		   Dataset ds = new FabriqueDataset("./src/model/pokemon_train.csv").getDataset();
		   List<Column> test = new ArrayList<Column>();
		   for (IColumn col : ds.getColumns()) {
			test.add((Column)col);
		   }
	        DistanceManhattan dm = new DistanceManhattan();

	        assertEquals(0.9171717368764923, dm.distance(ds, test, ds.getPoint(1), ds.getPoint(2)));
	        assertNotEquals(2.0, dm.distance(ds, test, ds.getPoint(1), ds.getPoint(2)));
	        assertNotEquals(null, dm.distance(ds, test, ds.getPoint(1), ds.getPoint(2)));
	        assertEquals(1.0236241550750225, dm.distance(ds, test, ds.getPoint(3), ds.getPoint(4)));
	        assertNotEquals(2.0, dm.distance(ds, test, ds.getPoint(3), ds.getPoint(4)));
	        assertNotEquals(null, dm.distance(ds, test, ds.getPoint(3), ds.getPoint(4)));
	        
	}

}
