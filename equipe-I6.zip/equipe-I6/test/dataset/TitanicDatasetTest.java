package dataset;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import model.TitanicDataset;

public class TitanicDatasetTest {
	
	public TitanicDataset test = new TitanicDataset("./src/model/titanic.csv");
	
	//on vérifie que tout est bien chargé par le DataSet en vérifiant avec les valeurs trouvées dans le csv
	// protected List<IPoint> points; et protected int nbColumn;
	@Test
	public void DatasetTest() {
		assertEquals(test.getColumns().size(),12);
		assertEquals(test.getNbLines(), 891);
	}
}
