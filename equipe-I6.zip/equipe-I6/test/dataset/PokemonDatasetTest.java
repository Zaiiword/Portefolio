package dataset;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

public class PokemonDatasetTest {
	
	public model.PokemonDataset test = new model.PokemonDataset("./src/model/pokemon_train.csv");
	
	//on vérifie que tout est bien chargé par le DataSet en vérifiant avec les valeurs trouvées dans le csv
	// protected List<IPoint> points; et protected int nbColumn;
	@Test
	public void DatasetTest() {
		assertEquals(test.getColumns().size(),13);
		assertEquals(test.getNbLines(), 507);
	}
}
