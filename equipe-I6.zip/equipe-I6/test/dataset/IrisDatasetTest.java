package dataset;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;

import model.IrisDataset;
import model.IPoint;

public class IrisDatasetTest {
	
	public IrisDataset test = new IrisDataset("./src/model/iris.csv");
	
	//on vérifie que tout est bien chargé par le DataSet en vérifiant avec les valeurs trouvées dans le csv
	// protected List<IPoint> points; et protected int nbColumn;
	@Test
	public void DatasetTest() {
		assertEquals(test.getColumns().size(),5);
		assertEquals(test.getNbLines(), 150);
	}
}
