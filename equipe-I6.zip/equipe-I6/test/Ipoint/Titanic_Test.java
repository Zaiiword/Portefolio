package Ipoint;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import model.Column;
import model.Titanic;

class Titanic_Test {

	@Test
	void Titanic_test() {
		Titanic t = new Titanic(10, true, 52, "toto", "male", 10.0, 10, 11, "ticket", 45.0, "Alama", 'B');
		Column c =new Column(1, "./src/model/titanic.csv");
		
		assertEquals("Titanic [passengerId=10, survivor=true, pClass=52, name=toto, sex=male, age=10.0, sibSp=10, parch=11, ticket=ticket, fare=45.0, cabin=Alama, embarked=B]", t.toString());
		assertEquals(12,t.getValue(c).size());
	}

}
