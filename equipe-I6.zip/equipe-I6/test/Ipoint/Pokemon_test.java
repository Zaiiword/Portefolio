package Ipoint;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import model.Column;
import model.Pokemon;

class Pokemon_test {

	@Test
	void Pokemontest() {
		Pokemon p =new Pokemon("toto", 100.0, 200.0, 1200.0, 8000.0, 400000.0, 15000.0, 200.0, 8000.0, "plante", "eau", 500.0, true);
				
		Column c =new Column(1, "./src/model/pokemon_train.csv");
		assertEquals("Pokemon{name='toto', attack=100.0, base_egg_steps=200.0, capture_rate=1200.0, defense=8000.0, experience_growth=400000.0, hp=15000.0, sp_attack=200.0, sp_defense=8000.0, type1='plante', type2='eau', speed=500.0, is_legendary=true}",p.toString());
		assertNotEquals("Pokemon{name='toto', attack=100.0, base_egg_steps=200.0, capture_rate=1200.0, defense=8000.0, experience_growth=400000.0, hp=15000.0, sp_attack=200.0, sp_defense=8000.0, type1='plante', type2='terre', speed=500.0, is_legendary=true}",p.toString());
		assertEquals(13,p.getValue(c).size());
		 
	}

}
