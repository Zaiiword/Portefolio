package Ipoint;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import model.Column;
import model.Iris;

class Iris_Test {

	@Test
	void Iris_test() {
		Iris i = new Iris(5.9, 7.8, 4.3, 3.5, "toto");
		Column c =new Column(1, "./src/model/iris.csv");
		
		assertEquals("Iris [sepal_length=5.9, sepal_width=7.8, petal_length=4.3, petal_width=3.5, variety=toto]", i.toString());
		assertEquals(5,i.getValue(c).size());
		
	}

}
