package methodeknn;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.opencsv.exceptions.CsvValidationException;

import model.Column;
import model.Dataset;
import model.DistanceEuclidienne;
import model.FabriqueDataset;
import model.MethodeKnn;


public class MethodeKnnTest {
	
	public FabriqueDataset fb;
	public Dataset dataset;
	public List<Column> colonnes = new ArrayList<Column>();
	public MethodeKnn knn;
	
	public MethodeKnnTest() throws CsvValidationException, IOException {
		this.fb = new FabriqueDataset("./src/model/iris.csv");
		this.dataset = fb.getDataset();
		this.colonnes.add((Column) dataset.getColumn(0));
		this.colonnes.add((Column) dataset.getColumn(0));
		this.knn = new MethodeKnn(dataset, colonnes, new DistanceEuclidienne());
		
	}
	
	@Test
	public void classificationTest() {
		knn.classificationPoint(5, knn.datas.getPoint(0));
		assertEquals(knn.datas.getValue(knn.datas.getPoint(0), knn.datas.getClassified()),"Setosa");
		assertTrue(knn.datas.getPoint(1).equals(dataset.getPoint(1)));
		
	}
}
