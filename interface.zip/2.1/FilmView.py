# --- import 
from PyQt6.QtWidgets import QWidget, QFrame
from PyQt6.QtWidgets import QVBoxLayout, QHBoxLayout
from PyQt6.QtWidgets import QLabel, QLineEdit, QDateEdit, QTextEdit, QPushButton
from PyQt6.QtCore import Qt, QDate, pyqtSignal
from vueLicence import VueLicence
import film
from LabelledWidget import LabelledWidget
from MultiLineEdit import MultiLineEdit
from WImage import WImage

# ----------------------------------------------------------------------
# --- class FilmVue
# ----------------------------------------------------------------------
class FilmView (QWidget):
    # +---------------------------------------------------------------------+
    # | title                                                               | 
    # +-------------------+--------------------------+----------------------+
    # |  Distributor      |      Release Date        | license              |
    # +-------------------+--------------------------+----------------------+
    # |      genre        |         run time         |                      |
    # +-------------------+--------------------------+----------------------+
    # |   revenu Domestic |   revenu international   | revenu worlds sales  |
    # +-------------------+--------------------------+----------------------+
    # |              descriptif                      |        image         |    
    # +-------------------+--------------------------+----------------------+
    # | previous | -------------------- message -------------------- | next |
    # +-------------------+--------------------------+----------------------+
    
    # signaux
    next : pyqtSignal = pyqtSignal()
    previous : pyqtSignal = pyqtSignal()

    # constructor
    def __init__(self , record : dict) -> None:
        super().__init__()
        self.__record : dict = record
        
        # drawGUI
        self.toplayout : QHBoxLayout = QHBoxLayout() ;self.setLayout(self.toplayout)
        self.vueLicense = VueLicence(); self.toplayout.addWidget(self.vueLicense)
        self.total : QWidget = QWidget()
        self.topLayouyt : QVBoxLayout = QVBoxLayout() ; self.total.setLayout(self.topLayouyt)
        self.toplayout.addWidget(self.total)

        #set the size of the filter 
        self.vueLicense.setFixedSize(450,700)

        # info1 Widget
        self.info1Widget : QFrame = QFrame() ; self.info1Layout : QHBoxLayout = QHBoxLayout() ; self.info1Widget.setLayout(self.info1Layout)   
        self.info1Widget.setFrameStyle(QFrame.Shape.StyledPanel) 

        # info2 Widget
        self.info2Widget : QFrame = QFrame() ; self.info2Layout : QHBoxLayout = QHBoxLayout() ; self.info2Widget.setLayout(self.info2Layout)   
        self.info2Widget.setFrameStyle(QFrame.Shape.StyledPanel) 

        # revenu Widget
        self.revenuWidget : QFrame = QFrame() ; self.revenuLayout : QVBoxLayout = QVBoxLayout() ; self.revenuWidget.setLayout(self.revenuLayout)
        self.revenuWidget.setFrameStyle(QFrame.Shape.StyledPanel) 
        self.revenuWidget.setFixedHeight(110)
        
        # dataWidget
        self.dataWidget : QFrame = QFrame() ; self.dataLayout : QHBoxLayout = QHBoxLayout() ; self.dataWidget.setLayout(self.dataLayout)
        self.revenuWidget.setFrameStyle(QFrame.Shape.StyledPanel) 

        # navMsgWidget
        self.navMsgWidget : QFrame = QFrame() ; self.navMsgLayout : QHBoxLayout = QHBoxLayout() ; self.navMsgWidget.setLayout(self.navMsgLayout)
        self.navMsgWidget.setFrameStyle(QFrame.Shape.StyledPanel) 

        # row 1: titre
        self.title = QLabel("Title") ; self.topLayouyt.addWidget(self.title)

        # row 2: Distributor, Date, license
        self.distributorLE = QLineEdit() 
        self.distributor = LabelledWidget("Distributor:", self.distributorLE,"distributor name", Qt.Orientation.Vertical, self.distributorLE.setText, self.distributorLE.text, None)
        self.info1Layout.addWidget(self.distributor)
        self.releaseDateLE = QDateEdit()
        self.releaseDate = LabelledWidget("Release date:", self.releaseDateLE,QDate(2000,1,2),Qt.Orientation.Vertical, self.releaseDateLE.setDate, self.releaseDateLE.date, None)
        self.info1Layout.addWidget(self.releaseDate)
        self.licenseLE = QLineEdit() 
        self.license = LabelledWidget("license:", self.licenseLE,"license", Qt.Orientation.Vertical, self.licenseLE.setText, self.licenseLE.text, None)
        self.info1Layout.addWidget(self.license)

        # row 3: genre, run-time
        self.genre = MultiLineEdit("Genre(s):") 
        self.genre.addItem("genre O")
        self.genre.addItem("genre 1")
        self.info2Layout.addWidget(self.genre)
        self.runtimeLE = QLineEdit() 
        self.runtime = LabelledWidget("Run-time (min):", self.runtimeLE,"120:00", Qt.Orientation.Horizontal,  self.runtimeLE.setText, self.runtimeLE.text, None)
        self.info2Layout.addWidget(self.runtime)


        # row 4 : revenue
        self.revenueTotal : QWidget = QWidget()
        self.revenue : QHBoxLayout = QHBoxLayout()

        self.revenueDomesticLE = QLineEdit() 
        self.revenuDomestic = LabelledWidget("Domestic Sales (in $):", self.revenueDomesticLE,"1 000 000", Qt.Orientation.Horizontal,  self.revenueDomesticLE.setText, self.revenueDomesticLE.text, None)
        self.revenuInterLE = QLineEdit() 
        self.revenuInter = LabelledWidget("International Sales (in $):", self.revenuInterLE,"1 000 000", Qt.Orientation.Horizontal,  self.revenuInterLE.setText, self.revenuInterLE.text, None)
        self.revenuWorldLE = QLineEdit() 
        self.revenuWorld = LabelledWidget("World Sales (in $):", self.revenuWorldLE,"1 000 000", Qt.Orientation.Horizontal,  self.revenuWorldLE.setText, self.revenuWorldLE.text, None)        
        
        #self.revenue.addWidget(self.revenuWorld)
        self.revenueTotal.setLayout(self.revenue)
        self.revenue.addWidget(self.revenuDomestic)
        self.revenue.addWidget(self.revenuInter)
        self.revenuLayout.addWidget(self.revenueTotal)
        self.revenuLayout.addWidget(self.revenuWorld)
        #set the size of revenuWorld
        self.revenuWorld.setFixedWidth(300)

        # row 5: descriptif, (image)
        self.descriptif = QTextEdit("descriptif.")
        self.image = WImage()
        self.dataLayout.addWidget(self.descriptif,50)
        self.dataLayout.addWidget(self.image,50)

        # row 6: navigation + message
        self.previousButton : QPushButton = QPushButton('<<')
        self.msg : QLabel = QLabel('0/0')
        self.nextButton : QPushButton = QPushButton('>>')
        self.navMsgLayout.addWidget(self.previousButton)
        self.navMsgLayout.addStretch()
        self.navMsgLayout.addWidget(self.msg)
        self.navMsgLayout.addStretch()
        self.navMsgLayout.addWidget(self.nextButton)


        # all all widgets to top Layout
        self.topLayouyt.addWidget(self.info1Widget)
        self.topLayouyt.addWidget(self.info2Widget)
        self.topLayouyt.addWidget(self.revenuWidget)
        self.topLayouyt.addWidget(self.dataWidget)
        self.topLayouyt.addWidget(self.navMsgWidget)

        # connections
        self.nextButton.clicked.connect(self.cbNext)
        self.previousButton.clicked.connect(self.cbPrevious)

        # show() !
        self.showMaximized()


    # methods

    def update(self,f : film.Film,nb : int,nbFilm : int) :
        self.title.setText(f.title)
        self.distributor.set(f.distributor)
        self.releaseDate.set(f.releaseDate)
        self.license.set(f.license)
        self.runtime.set(str(f.runtime))
        self.descriptif.setText(f.info)
        self.revenuDomestic.set(str(f.domesticSales))
        self.revenuInter.set(str(f.internationalSales))
        self.revenuWorld.set(str(f.worldSales))
        self.image.query(f.title)

        precedent : list[str] = self.msg.text().split("/")
        nbprecedent : int = int(precedent[0])
        if nbprecedent+nb > nbFilm :
            nbActuel = 1
        else : 
            nbActuel = nbprecedent+nb
        self.msg.setText(str(nbActuel)+"/"+str(nbFilm))

        self.genre.clear()
        for g in f.genre:
            self.genre.addItem(g)

    """TEMPORAIRE"""
    # def update(self , record : dict, genres : list[str], distributors : list[str],licenses : list[str]) -> None:
    #     # record = {"title" , "info" , "distributor" , "releaseDate" , "domesticSales" , "internationalSales" , "worldSales" , "genre" , "runtime" , "license" }
    #     self.title.setText(record["title"])
    #     self.distributor.set(distributors[record["distributor"]])
    #     self.releaseDate.set(QDate(int(record["releaseDate"].split('-')[0]),int(record["releaseDate"].split('-')[1]),int(record["releaseDate"].split('-')[2])))
    #     self.license.set(licenses[record["license"]])
    #     self.runtime.set(str(record["runtime"]))
    #     self.descriptif.setText(record["info"])
    #     self.revenuDomestic.set(str(record["domesticSales"]))
    #     self.revenuInter.set(str(record["internationalSales"]))
    #     self.revenuWorld.set(str(record["worldSales"]))
    #     self.image.query(record["title"])

    #     self.genre.clear()
    #     for g in record["genre"]:
    #         self.genre.addItem(genres[g])

    def message(self , msg : str) -> None: self.msg.setText(msg)

    # callbacks
    def cbNext(self) -> None:     self.next.emit()
    def cbPrevious(self) -> None: self.previous.emit()

# --- main: kind of unit test
if __name__ == "__main__" :
    import sys
    from PyQt6.QtWidgets import QApplication
    #import hhgm
    
    app = QApplication(sys.argv)
    #db = hhgm.HHGM()
    #db.loadCSV()
    fv = FilmView({})
    #fv.update(db.db[10],db.genres, db.distributors, db.licences)
    sys.exit(app.exec())




