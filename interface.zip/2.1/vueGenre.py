from PyQt6.QtWidgets import QVBoxLayout,QWidget,QCheckBox,QPushButton,QHBoxLayout,QFormLayout,QGroupBox,QScrollArea
from vueDistributeur import VueDistributor
from PyQt6.QtCore import pyqtSignal
class VueGenre(QWidget):
    # signal
    refreshGenre = pyqtSignal()
    def __init__(self):
        
        super().__init__()

        #récupération de la partie distributeur
        self.toplayout : QHBoxLayout = QHBoxLayout() ;self.setLayout(self.toplayout)
        self.vueDistrib = VueDistributor(); self.toplayout.addWidget(self.vueDistrib)

        #Create a new Widget
        self.select : QWidget = QWidget()
        self.genre : QScrollArea = QScrollArea()
        self.totale : QWidget = QWidget()
        self.filtre : QWidget = QWidget()

        #############TEMPORAIRE###################
        self.listeGenre : list[str]= self.vueDistrib.annuaireJS.getGenre()

        #set the widget size
        self.vueDistrib.setFixedSize(170,700)
        self.select.setFixedSize(100,90)
        self.genre.setFixedSize(120,550)
        self.filtre.setFixedWidth(100)

        #set the layout
        self.total : QVBoxLayout = QVBoxLayout(); self.totale.setLayout(self.total)
        self.layoutSelect : QVBoxLayout = QVBoxLayout(); self.select.setLayout(self.layoutSelect)
        self.layout : QVBoxLayout = QVBoxLayout(); self.genre.setLayout(self.layout)
        self.layoutFiltre : QVBoxLayout = QVBoxLayout() ; self.filtre.setLayout(self.layoutFiltre)

        #add the Widget
        self.total.addWidget(self.select)
        self.total.addWidget(self.genre)
        self.total.addWidget(self.filtre)
        self.toplayout.addWidget(self.totale)

        #Set the matgin to 0 
        self.total.setContentsMargins(0, 0, 0, 0)
        self.toplayout.setContentsMargins(0, 0, 0, 0)
        self.filtre.setContentsMargins(0, 0, 0, 0)



        #pushButton
        self.check_all : QPushButton =QPushButton("select all")
        self.uncheck_all : QPushButton =QPushButton("deselect all")

        #filter
        self.filter : QPushButton = QPushButton("Filter")


        #Add the widget to the layout
        self.layoutSelect.addWidget(self.check_all)
        self.layoutSelect.addWidget(self.uncheck_all)

        #create all the checkbox
        formLayout = QFormLayout()
        self.buttonList=[]
        for index,i in enumerate(self.listeGenre):
            self.buttonList.append(QCheckBox(i))
            formLayout.addRow(self.buttonList[index])
        
        #add all the checkbox
        groupBox = QGroupBox("Genre")
        groupBox.setLayout(formLayout)
        self.genre.setWidget(groupBox)

        self.layoutFiltre.addWidget(self.filter)
        
        #detect click on button 
        self.check_all.clicked.connect(self.checkall)
        self.uncheck_all.clicked.connect(self.uncheckall)
        self.filter.clicked.connect(self.refreshGenres)

        self.checkall()

        #show
        self.showMaximized()

    def checkall(self): 
        """Check all the button """
        for i in range(len(self.buttonList)):
            self.buttonList[i].setChecked(True)
        



    def uncheckall(self):
        """Check all the button """
        for i in range(len(self.buttonList)):
            self.buttonList[i].setChecked(False)
        #show
        self.show()

    def refresh(self) -> list[str]:
        listGenre = []
        for index,i in enumerate(self.buttonList):
            if i.isChecked():
                listGenre.append(self.listeGenre[index])
        print(listGenre)
        return listGenre
    
    #callback
    def refreshGenres(self):
        self.refreshGenre.emit()
        
        


if __name__ == "__main__":
    import sys
    from PyQt6.QtWidgets import QApplication
    app = QApplication(sys.argv)
    vue  =VueGenre()
    sys.exit(app.exec())