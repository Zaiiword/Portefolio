from FilmView import FilmView
from FilmView import FilmView
from PyQt6.QtWidgets import QVBoxLayout,QWidget,QCheckBox,QPushButton,QHBoxLayout

class VueDataViz(QWidget):

    def __init__(self) -> None:
        super().__init__()

        self.toplayout : QHBoxLayout = QHBoxLayout() ;self.setLayout(self.toplayout)
        self.vueFilm = FilmView({}); self.toplayout.addWidget(self.vueFilm)

        #Create new Widget
        self.all : QWidget = QWidget()
        self.ourMovie : QWidget = QWidget()
        self.viz : QWidget = QWidget()

        self.ourMovie.setStyleSheet('background-color: pink;')
        self.viz.setStyleSheet('background-color: orange;')

        #set the size of the widget
        self.vueFilm.setFixedSize(1000,700)
        self.ourMovie.setFixedHeight(300)

        #create the layout
        self.total : QVBoxLayout = QVBoxLayout(); self.all.setLayout(self.total)

        #add the widget
        self.total.addWidget(self.ourMovie)
        self.total.addWidget(self.viz)
        self.toplayout.addWidget(self.all)
        self.toplayout.setContentsMargins(0, 0, 0, 0)
        self.showMaximized()

if __name__ == '__main__':
    import sys
    from PyQt6.QtWidgets import QApplication
    app = QApplication(sys.argv)
    vue  =VueDataViz()
    sys.exit(app.exec())