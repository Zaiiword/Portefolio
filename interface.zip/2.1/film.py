#import 
import datetime
import json
import converter
# ---------------------------------
# --- class Film
# ---------------------------------
class Film:
    #constructor
    def __init__(self,number : int,distributor : str,genre : list[str],license :str,title : str,info : str,
                 releaseDate : datetime.date,domesticSales : int,worldSales: int,
                 internationalSales : int,runtime : int  ) -> None:
        
        self.__number : int = number
        self.__distributor : str = distributor
        self.__genre : list[str] = genre
        self.__license : str = license
        self.__title : str = title
        self.__info : str =info
        self.__releaseDate : datetime.date = releaseDate
        self.__domesticSales : int = domesticSales 
        self.__worldSales : int = worldSales
        self.__internationalSales : int =internationalSales
        self.__runtime : int = runtime
    
    def __repr__(self) -> str:
        res = "" 
        res+= "movie n°"+str(self.__number)   
        res += self.__title +" from "+ self.__distributor
        res += "is a movie of "+ str(self.__genre)
        res += "under the license"+self.__license
        res +="released on"+str(self.__releaseDate)
        res+= "runtime"+str(self.__runtime)
        res+="domestic sales : "+str(self.__domesticSales)+"  world sales : "+str(self.__worldSales)+"  international sales : "+str(self.__internationalSales)
        res+="synopsis :  "+self.__info
        return res

    @property
    def number(self) ->int : return self.__number
    @number.setter
    def number(self,number : int) -> None : self.__number = number

    @property
    def distributor(self) ->str : return self.__distributor
    @distributor.setter
    def distributor(self,distributor : str) -> None : self.__distributor = distributor

    @property
    def genre(self) ->list[str] : return self.__genre
    @genre.setter
    def genre(self,genre : list[str]) -> None : self.__genre = genre

    @property
    def license(self) ->str : return self.__license
    @license.setter
    def license(self,license : str) -> None : self.__license = license

    @property
    def title(self) ->str : return self.__title
    @title.setter
    def title(self,title : str) -> None : self.__title = title

    @property
    def info(self) ->str : return self.__info
    @info.setter
    def info(self,info : str) -> None : self.__info = info

    @property
    def releaseDate(self) ->datetime.date : return self.__releaseDate
    @releaseDate.setter
    def releaseDate(self,date : datetime.date) -> None : self.__releaseDate = date

    @property
    def domesticSales(self) ->int : return self.__domesticSales
    @domesticSales.setter
    def domesticSales(self,domesticSales : int) -> None : self.__domesticSales = domesticSales

    @property
    def worldSales(self) ->int : return self.__worldSales
    @worldSales.setter
    def worldSales(self,worldSales : int) -> None : self.__worldSales = worldSales

    @property
    def internationalSales(self) ->int : return self.__internationalSales
    @internationalSales.setter
    def internationalSales(self,internationalSales : int) -> None : self.__internationalSales = internationalSales

    @property
    def runtime(self) ->int : return self.__runtime
    @runtime.setter
    def runtime(self,runtime : int) -> None : self.__runtime = runtime


    #Json
    def toJSON(self) -> str:
        dictP = {
            ''  : self.__number ,
            'Title' : self.__title,
            'Movie Info'    : self.__info,
            'Distributor' : self.__distributor,
            'Release Date'      : self.__releaseDate,
            'Domestic Sales (in $)'    : self.__domesticSales,
            'International Sales (in $)' : self.__internationalSales,
            'World Sales (in $)' : self.__worldSales,
            'Genre' : str(self.__genre),
            'Movie Runtime' : self.__runtime,
            'License' : self.__license
        }
        return json.dumps(dictP,ensure_ascii=False)
    

    # buildFromJson
    @staticmethod
    def buildFromJSon(d: dict):
        number : int = d['']
        title :str =  d['Title'] 
        info : str =  d['Movie Info'] 
        distributor : str = d['Distributor']
        release : datetime.date = converter.stringToDate(d['Release Date'])
        domesticSales : int = d['Domestic Sales (in $)']
        internationalSales : int = d['International Sales (in $)']
        worldSales : int = d['World Sales (in $)']
        genre : list[str] = converter.stringToGenre(d['Genre'])
        runtime : int = converter.stringToMin(d['Movie Runtime'])   
        license : str = d['License'] 
        return Film(number,distributor,genre,license,title,info,release,domesticSales,
                    worldSales,internationalSales,runtime)

    


