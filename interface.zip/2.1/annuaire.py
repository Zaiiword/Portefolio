import datetime
import json, copy, os
import film
from typing import  Union
class Annuaire:
    #constructeur
    def __init__(self , jsonFile :(Union[str,None]) = None) -> None:
        #attributs
        self.__listFilm : list[film.Film] = []
        self.__current : (Union[int,None]) = None
        self.__listDistributor : list[str] = []
        self.__listGenre : list[str] = []
        self.__listLicense : list[str] = []
        
        if jsonFile: self.open(jsonFile) 
    
    @property
    def current(self) -> Union[int,None] : return self.__current
    @current.setter
    def current(self, index :Union[int,None]) -> None : self.__current = index

    @property
    def listFilm(self) -> list[film.Film] : return self.__listFilm
    @listFilm.setter
    def listFilm(self, index :list[film.Film]) -> None : self.__listFilm = index

    def getNbFilm(self) -> int:
        return len(self.__listFilm)

    def update(self,p: film.Film) -> None:
        film = self.getFilm()
        if film:
            film.number = copy.deepcopy(p.number)
            film.distributor = copy.deepcopy(p.distributor)
            film.genre = copy.deepcopy(p.genre)
            film.license = copy.deepcopy(p.license)
            film.title = copy.deepcopy(p.title)
            film.info = copy.deepcopy(p.info)
            film.releaseDate = copy.deepcopy(p.releaseDate)
            film.domesticSales = copy.deepcopy(p.domesticSales)
            film.worldSales = copy.deepcopy(p.worldSales)
            film.internationalSales = copy.deepcopy(p.internationalSales)
            film.runtime = copy.deepcopy(p.runtime)


    def open(self, jsonFile : str) -> None:
        with open(jsonFile, encoding='utf-8') as file:
            print(f'loading file: {jsonFile}', end='... ')
            js = json.load(file) 
            if  'annuaire' in js.keys():
                listFilm = js['annuaire']
                for p in listFilm:  
                    pp = film.Film.buildFromJSon(p) 
                    self.__listFilm.append(pp)
                print(f'{len(self.__listFilm)} movie found')
                self.__current = 0 if self.__listFilm else None


    def save(self,jsonFile : str) -> None:
        print(f'saving file: {jsonFile}', end='... ')

        if not  os.path.exists(jsonFile): 
            f = open(jsonFile, "x"); f.close()

        with open(jsonFile, "w", encoding='utf-8') as file: 
            d : dict= {} 
            listFilm : list= []
            for p in self.__listFilm :listFilm.append(p.toJSON())
            d['annuaire'] = listFilm
            json.dump(d,file,ensure_ascii=False)
        print(f'done!')

    def getDistributor(self):
        """Return all the distributor of the json"""
        for i in self.__listFilm :
            if i.distributor not in self.__listDistributor:
                self.__listDistributor.append(i.distributor)
        return self.__listDistributor

    def getGenre(self):
        """Return all the genre of the json"""
        for i in self.__listFilm :
            for j in i.genre :
                if j not in self.__listGenre:
                    self.__listGenre.append(j)
        return self.__listGenre

    def getLicense(self):
        """Return all the genre of the json"""
        for i in self.__listFilm :
            if i.license not in self.__listLicense:
                self.__listLicense.append(i.license)
        return self.__listLicense


    def getFilmByDistributor(self, distributor: str) ->  (Union[list[film.Film],None]):
        """Return a List of movie based on a distributor"""
        searchList : list[str] = list(map(lambda x: x.distributor.lower(), self.__listFilm))
        movieList : Union[list[film.Film],None] =[]
        for index,m in enumerate(searchList):
            if m == distributor.lower():
                movieList.append(self.__listFilm[index])        
        return movieList

    def getFilmByGenre(self, genre: str) -> (Union[list[film.Film],None]):
        """Return a List of movie based on a Genre"""
        searchList : list[list[str]] = []
        for i in self.__listFilm :
            searchList.append(i.genre)      
        movieList : Union[list[film.Film],None] =[]
        for index,m in enumerate(searchList):
            if genre in m:
                movieList.append(self.__listFilm[index])        
        return movieList

    def getFilmByLicense(self, license: str) -> (Union[list[film.Film],None]):
        """Return a List of movie based on a License"""
        searchList : list[str] = list(map(lambda x: x.license.lower(), self.__listFilm))
        movieList : Union[list[film.Film],None] =[]
        for index,m in enumerate(searchList):
            if m == license.lower():
                movieList.append(self.__listFilm[index])        
        return movieList

    def getFilmByRuntime(self, runtime: int) -> (Union[list[film.Film],None]):
        """Return a List of movie based on runtime"""
        searchList : list[int] = []
        for i in self.__listFilm :
            searchList.append(i.runtime)
        movieList : Union[list[film.Film],None] =[]
        for index,m in enumerate(searchList):
            if m <= runtime:
                movieList.append(self.__listFilm[index])        
        return movieList


    def next(self) -> None :
        if self.__current != None :
            print(self.__current)
            self.__current = (self.__current +1)% len(self.__listFilm) 
    
    def previous(self) -> None :
        if self.__current != None :
            self.__current = (self.__current - 1)% len(self.__listFilm)

    def getFilm(self) : 
        if self.__current != None: return self.__listFilm[self.__current]  
        else:
            return None

    def addFilm(self, f : film.Film, index : Union[int,None] = None) -> None :
        if not isinstance(index, int) or not isinstance(self.__current, int):
            self.__listFilm.append(f)
            self.current = len(self.__listFilm) -1 if len(self.__listFilm) != 0 else None
        else:
            self.__listFilm.insert(self.__current,f)

if __name__ == "__main__" :
    print('TEST: class Annuaire')
    rc : film.Film= film.Film(0,"Walt Disney Studios Motion Pictures",['Action', 'Adventure', 'Sci-Fi'],"PG-13","Star Wars",
                                "As a new threat to the galaxy rises, Rey, a desert scavenger, and Finn, an ex-stormtrooper, must join Han Solo and Chewbacca to search for the one hope of restoring peace.",
                                datetime.date(2003,9,10),936662225,1132859475,2069521700,158 )
    annuaire : Annuaire = Annuaire()
    annuaire.addFilm(rc)
    #print("\ttesting add,getbyName:", end= ' ')
    #print(annuaire.getFilmByDistributor("Walt Disney Studios Motion Pictures"))    

    print("\ttesting from json:", end= ' ')
    annuaireJS : Annuaire = Annuaire('csvjson.json')
    #listFilms : (Union[list[film.Film],None])= annuaireJS.getFilmByGenre('Action')
    listFilms : (Union[list[film.Film],None])= annuaireJS.getFilmByRuntime(200)
    for i in listFilms:  #type: ignore
        print( i.title,i.runtime,"min")
