from PyQt6.QtWidgets import QVBoxLayout,QWidget,QCheckBox,QPushButton,QHBoxLayout
from vueGenre import VueGenre
from PyQt6.QtCore import pyqtSignal

class VueLicence(QWidget):
    # signal
    refreshLicense = pyqtSignal()
    def __init__(self) -> None:
        super().__init__()

        #récupération de la partie distributeur
        self.toplayout : QHBoxLayout = QHBoxLayout() ;self.setLayout(self.toplayout)
        self.vueGenre = VueGenre(); self.toplayout.addWidget(self.vueGenre)

        #Create new Widgets
        self.select : QWidget = QWidget()
        self.genre : QWidget = QWidget()
        self.totale : QWidget = QWidget()
        self.filtre : QWidget = QWidget()
        self.runtime : QWidget = QWidget()

        #############TEMPORAIRE###################
        self.listeGenre : list[str]= self.vueGenre.vueDistrib.annuaireJS.getGenre()

        self.runtime.setStyleSheet('background-color: yellow;')
        #self.totale.setStyleSheet('background-color: lightgrey;')
        
        #Ajust the size of the widgets
        self.vueGenre.setFixedSize(400,700)
        self.select.setFixedSize(150,90)
        self.genre.setFixedSize(100,400)
        self.filtre.setFixedSize(150,90)
        self.runtime.setFixedSize(150,150)

        #create the layout and set the layout of the widget
        self.total : QVBoxLayout = QVBoxLayout(); self.totale.setLayout(self.total)
        self.layoutSelect : QVBoxLayout = QVBoxLayout(); self.select.setLayout(self.layoutSelect)
        self.layout : QVBoxLayout = QVBoxLayout(); self.genre.setLayout(self.layout)
        self.layoutFiltre : QVBoxLayout = QVBoxLayout() ; self.filtre.setLayout(self.layoutFiltre)

        #Set the margin to 0
        self.toplayout.setContentsMargins(0, 0, 0, 0)
        self.total.setContentsMargins(0, 0, 0, 0)
        self.layoutFiltre.setContentsMargins(0, 36, 0, 0)
        self.layout.setContentsMargins(0, 0, 0, 10)

        #add the Widget
        self.total.addWidget(self.select)
        self.total.addWidget(self.genre)
        self.total.addWidget(self.runtime)
        self.total.addWidget(self.filtre)
        self.toplayout.addWidget(self.totale)

                    #---------------------------Licence and pushButton---------------------------#
        #create the license button
        self.pg13 : QCheckBox = QCheckBox("PG-13")
        self.na : QCheckBox = QCheckBox("NA")
        self.pg : QCheckBox = QCheckBox("PG")
        self.g : QCheckBox = QCheckBox("G")
        self.r : QCheckBox = QCheckBox("R")

        #and the 
        self.check_all : QPushButton =QPushButton("select all")
        self.uncheck_all : QPushButton =QPushButton("deselect all")

        #same for filter
        self.filter : QPushButton = QPushButton("Filter")

                        #---------------------------Runtime---------------------------#

        #Add the widget to the layout
        self.layoutSelect.addWidget(self.check_all)
        self.layoutSelect.addWidget(self.uncheck_all)

        self.layout.addWidget(self.pg13)
        self.layout.addWidget(self.na)
        self.layout.addWidget(self.pg)
        self.layout.addWidget(self.g)
        self.layout.addWidget(self.r)

        self.layoutFiltre.addWidget(self.filter)

        #detect click on button 
        self.check_all.clicked.connect(self.checkall)
        self.uncheck_all.clicked.connect(self.uncheckall)
        self.filter.clicked.connect(self.refreshLicence)

        self.checkall()
        self.show()

    
    def checkall(self): 
        #Check all the check box
        self.pg13.setChecked(True)
        self.na.setChecked(True)
        self.pg.setChecked(True)
        self.g.setChecked(True)
        self.r.setChecked(True)

    def uncheckall(self):
        #Check all the check box
        self.pg13.setChecked(False)
        self.na.setChecked(False)
        self.pg.setChecked(False)
        self.g.setChecked(False)
        self.r.setChecked(False)

    def refresh(self) -> list[str]:
        listLicense = []
        if self.pg13.isChecked(): listLicense.append("PG-13")
        if self.na.isChecked(): listLicense.append("NA")
        if self.pg.isChecked(): listLicense.append("PG")
        if self.g.isChecked(): listLicense.append("G")
        if self.r.isChecked(): listLicense.append("R")
        print(listLicense)
        return listLicense

    #callback
    def refreshLicence(self):
        self.refreshLicense.emit()


if __name__ == '__main__':
    import sys
    from PyQt6.QtWidgets import QApplication
    app = QApplication(sys.argv)
    vue  =VueLicence()
    sys.exit(app.exec())