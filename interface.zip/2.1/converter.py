import datetime

def stringToDate(date: str) -> datetime.date:
        if date == 'NA':
                return datetime.date(1,1,1)
        x = date.split()
        month=x[0]
        datetime_object = datetime.datetime.strptime(month, "%B")
        month_number = datetime_object.month
        year = int(x[2])
        day = int(x[1][0:1])
        return datetime.date(year,month_number,day)

def stringToMin(time: str) -> int:
    x = time.split()
    hour= int(x[0])*60
    if len(x)<3:
            return hour
    min = int(x[2])
    return min+hour

def stringToGenre(genre :str)  :
    x=genre.split("'")
    listGenre : list[str] = []
    for i in range(len(x)):
        if i%2 !=0:
           listGenre.append(x[i])
    return listGenre
    

if __name__ == '__main__':
   print(stringToGenre("['Adventure', 'Animation', 'Drama', 'Family', 'Musical']"))
