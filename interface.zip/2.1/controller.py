import annuaire,film
from vueGenre import VueGenre
from viewDataViz import VueDataViz

class controller :
    def __init__(self) -> None:
        #attributs
        self.modele = annuaire.Annuaire('csvjson.json')
        self.vue = VueDataViz()
        f = self.modele.getFilm()

        if isinstance(f, film.Film): self.vue.vueFilm.update(f,1,self.modele.getNbFilm())
        # slots ie callback
        #A great path
        self.vue.vueFilm.vueLicense.vueGenre.vueDistrib.refreshDistributor.connect(self.refresh)
        self.vue.vueFilm.vueLicense.vueGenre.refreshGenre.connect(self.refresh)
        self.vue.vueFilm.vueLicense.refreshLicense.connect(self.refresh)
        self.vue.vueFilm.next.connect(self.next)
        self.vue.vueFilm.previous.connect(self.previous)
        # self.vue.nextClicked.connect(self.next)
        # self.vue.previousClicked.connect(self.previous)
        # self.vue.newClicked.connect(self.new)
        # self.vue.personneChanged.connect(self.update)
        # self.vue.saveAsClicked.connect(self.saveAs)

    def next(self) -> None:
        self.modele.next()
        self.vue.vueFilm.update(self.modele.getFilm(),1,self.modele.getNbFilm())   # type: ignore
         
    def previous(self) -> None:
        self.modele.previous()
        self.vue.vueFilm.update(self.modele.getFilm(),-1,self.modele.getNbFilm())   # type: ignore

    def refresh(self) :
        distributeur = self.vue.vueFilm.vueLicense.vueGenre.vueDistrib.refresh()
        genre = self.vue.vueFilm.vueLicense.vueGenre.refresh()
        license = self.vue.vueFilm.vueLicense.refresh()

        #All the Films that been produced by the distributors
        listFilmDistrib = []
        for i in distributeur :
            listDistrib = self.modele.getFilmByDistributor(i)
            if listDistrib != None:
                for j in listDistrib:
                    listFilmDistrib.append(j)

        #All the Films that contains these genres
        listFilmGenre = []
        for i in genre :
            listGenre = self.modele.getFilmByGenre(i)
            if listGenre != None:
                for j in listGenre :
                    listFilmGenre.append(j)

        #All the Films that contains these licenses
        listFilmLicense = []
        for i in license :
            listLicense = self.modele.getFilmByLicense(i)
            if listLicense != None:
                for j in listLicense :
                    listFilmLicense.append(j)

        #Add all the film that check all the conditions
        listFilm : list[film.Film] = []
        for i in listFilmDistrib:
            if i in listFilmGenre:
                if i in listFilmLicense:
                    listFilm.append(i)

        self.modele.listFilm=listFilm
        self.vue.vueFilm.update(self.modele.getFilm(),-1,self.modele.getNbFilm())  # type: ignore
        for i in listFilm:
            print(i.title)
        print(len(listFilm))
        #return listFilm

if __name__ == "__main__":
    import sys
    from PyQt6.QtWidgets import QApplication
    app = QApplication(sys.argv)
    vue  = controller()
    sys.exit(app.exec())   