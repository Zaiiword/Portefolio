from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import QVBoxLayout,QWidget,QCheckBox,QPushButton,QScrollArea,QFormLayout,QGroupBox
import annuaire
class VueDistributor(QWidget):
    # signal
    refreshDistributor = pyqtSignal()
    def __init__(self):
        """
        @author Dekeister Clément
        """
        super().__init__()

        #Create a new Widget
        self.select : QWidget = QWidget()
        self.distributor : QScrollArea = QScrollArea()
        self.filtre : QWidget = QWidget()

        #############TEMPORAIRE###################
        self.annuaireJS : annuaire.Annuaire = annuaire.Annuaire('csvjson.json')
        self.listeDistri : list[str]= self.annuaireJS.getDistributor()



        #Set the size of the Widgets
        self.distributor.setWidgetResizable(True)
        self.select.setFixedHeight(90)
        self.select.setFixedWidth(200)
        self.distributor.setFixedHeight(550)
        self.distributor.setFixedWidth(200)
        self.filtre.setFixedHeight(50)
        self.filtre.setFixedWidth(200)
        

        #create the layout
        self.total : QVBoxLayout = QVBoxLayout()
        self.layoutSelect : QVBoxLayout = QVBoxLayout();self.select.setLayout(self.layoutSelect)
        self.layout:QVBoxLayout = QVBoxLayout() ;self.distributor.setLayout(self.layout)
        #self.layout : QScrollBar = QScrollBar() 
        self.layoutFilter : QVBoxLayout = QVBoxLayout();self.filtre.setLayout(self.layoutFilter)

        #add the layout
        self.total.addWidget(self.select)
        self.total.addWidget(self.distributor)
        self.total.addWidget(self.filtre)
        self.setLayout(self.total)
        self.total.setContentsMargins(0, 0, 0, 0)


        #pushButton
        self.check_all : QPushButton =QPushButton("select all")
        self.uncheck_all : QPushButton =QPushButton("deselect all")

        #filter
        self.filter : QPushButton = QPushButton("Filter")

        #add the widget
        self.layoutSelect.addWidget(self.check_all)
        self.layoutSelect.addWidget(self.uncheck_all)

        #create all the checkbox
        formLayout = QFormLayout()
        self.buttonList=[]
        for index,i in enumerate(self.listeDistri):
            self.buttonList.append(QCheckBox(i))
            formLayout.addRow(self.buttonList[index])
        
        #add all the checkbox
        groupBox = QGroupBox("Distributors")
        groupBox.setLayout(formLayout)
        self.distributor.setWidget(groupBox)

        #Check everything
        self.checkall()

        #Filter
        self.layoutFilter.addWidget(self.filter)

        #detect click on button 
        self.check_all.clicked.connect(self.checkall)
        self.uncheck_all.clicked.connect(self.uncheckall)
        self.filter.clicked.connect(self.refreshDistrib)
        #show
        self.show()


    def checkall(self):
        """Check all the button """
        for i in range(len(self.buttonList)):
            self.buttonList[i].setChecked(True)
        #show
        self.show()

    def uncheckall(self):
        """Uncheck all the button"""
        for i in range(len(self.buttonList)):
            self.buttonList[i].setChecked(False)
        #show
        self.show()
    
    def refresh(self) -> list[str]:
        listDistributor = []
        for index,i in enumerate(self.buttonList):
            if i.isChecked():
                listDistributor.append(self.listeDistri[index])
        print(listDistributor)
        return listDistributor
    
    #callback
    def refreshDistrib(self):
        self.refreshDistributor.emit()


if __name__ == "__main__":
    import sys
    from PyQt6.QtWidgets import QApplication
    app = QApplication(sys.argv)
    vue  =VueDistributor()
    sys.exit(app.exec())
