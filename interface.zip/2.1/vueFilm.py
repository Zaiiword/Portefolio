from PyQt6.QtWidgets import QVBoxLayout,QWidget,QCheckBox,QPushButton,QHBoxLayout
from vueLicence import VueLicence

class VueFilm(QWidget):
    def __init__(self) -> None:
        super().__init__()

        self.toplayout : QHBoxLayout = QHBoxLayout() ;self.setLayout(self.toplayout)
        self.vueLicense = VueLicence(); self.toplayout.addWidget(self.vueLicense)

        #Create new Widget
        self.distributor : QWidget = QWidget()
        self.genre : QWidget = QWidget()
        self.money : QWidget = QWidget()
        self.totale : QWidget = QWidget()
        self.infoFilm : QWidget = QWidget()
        self.filtre : QWidget = QWidget()

        self.distributor.setStyleSheet('background-color: red;')
        self.genre.setStyleSheet('background-color: blue;')
        self.money.setStyleSheet('background-color: green;')
        self.infoFilm.setStyleSheet('background-color: darkGrey;')


        #set the size of the widget
        self.vueLicense.setFixedWidth(450)
        self.distributor.setFixedSize(400,80)
        self.genre.setFixedSize(400,100)
        self.money.setFixedSize(400,50)
        self.infoFilm.setFixedSize(400,400)

        

        #create the layout
        self.total : QVBoxLayout = QVBoxLayout(); self.totale.setLayout(self.total)

        #add the Widget
        self.total.addWidget(self.distributor)
        self.total.addWidget(self.genre)
        self.total.addWidget(self.money)
        self.total.addWidget(self.infoFilm)
        self.total.addWidget(self.filtre)
        self.toplayout.addWidget(self.totale)
        self.toplayout.setContentsMargins(0, 0, 0, 0)
        self.showMaximized()

    def updateFilm(self,f):
        pass

if __name__ == '__main__':
    import sys
    from PyQt6.QtWidgets import QApplication
    app = QApplication(sys.argv)
    vue  =VueFilm()
    sys.exit(app.exec())