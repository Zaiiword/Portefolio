from cProfile import label
import imp
from tkinter.tix import Tree
from PyQt6.QtWidgets import QWidget ,QLabel,QFormLayout,QGroupBox,QScrollArea,QPushButton,QHBoxLayout

class test (QWidget):
    def __init__(self) :
        super().__init__()

        
        formLayout = QFormLayout()
        groupBox = QGroupBox("this is group by")

        labelList = []
        buttonList=[]

        for i in range(50):
            labelList.append(QLabel("label"))
            buttonList.append(QPushButton("click"))
            formLayout.addRow(labelList[i],buttonList[i])

        groupBox.setLayout(formLayout)
        scroll = QScrollArea()
        scroll.setWidget(groupBox)
        scroll.setWidgetResizable(True)
        scroll.setFixedHeight(400)

        droite = QScrollArea()
        droite.setWidget(groupBox)
        droite.setWidgetResizable(True)
        droite.setFixedHeight(400)


        layout = QHBoxLayout()
        layout.addWidget(scroll)
        layout.addWidget(droite)

        self.setLayout(layout)

        self.show()

        

if __name__ == "__main__":
    import sys
    from PyQt6.QtWidgets import QApplication
    app = QApplication(sys.argv)
    vue  =test()
    sys.exit(app.exec())