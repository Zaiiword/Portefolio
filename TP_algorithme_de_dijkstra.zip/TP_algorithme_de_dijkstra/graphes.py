from random import randint
from math import inf
############GRAPHE N°1 ##############################

def graphe1():
    n = 5
    # on donne un nom à chaque sommet
    etiquettes = [ k for k in range(n)]
    # listes d'adjacence
    adj = [[1,2] , [0,3] , [0,3,4] ,[1,2,4] ,[2,3]]
    # coordonnées des sommets
    XY = [(0,1), (1,2), (1,0), (2, 2),(2,0)]
    longueur_arete = [ [ 0,1,5,inf,inf] , [1,0,inf,1,inf],[5,inf,0,1,1],[inf,1,1,0,3],[inf,inf,1,3,0]]
    return ( n , etiquettes , adj , XY , longueur_arete)



############GRAPHE N°2 ##############################

def graphe2():
    n = 12
    etiquettes = [ k for k in range(n) ]
    # listes d'adjacence
    adj = [[1, 6], [0, 2, 3], [1, 3, 9], [1, 2, 4], [3, 5], [4, 11],
    [0, 7, 8], [6, 8], [6, 7, 9, 10], [2, 8, 10, 11],
    [8, 9, 11], [5, 9, 10]]
    # coordonnées des sommets
    XY = [(0, 2), (0, 3), (1, 2), (2, 3), (2, 4), (4, 4),
    (0, 1), (1, 0), (2, 0), (3, 2), (4, 1), (4, 3)]
    
    longueur_arete = [[0, 2, inf, inf, inf, inf, 2, inf, inf, inf, inf, inf],
             [2, 0, 10, 10, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, 10, 0, 1, inf, inf, inf, inf, inf, 5, inf, inf],
             [inf, 10, 1, 0, 2, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, 2, 0, 10, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, 10, 0, inf, inf, inf, inf, inf, 1],
             [2, inf, inf, inf, inf, inf, 0, 1, 10, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, 1, 0, 2, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, 10, 2, 0, 5, 5, inf],
             [inf, inf, 5, inf, inf, inf, inf, inf, 5, 0, 2, 5],
             [inf, inf, inf, inf, inf, inf, inf, inf, 5, 2, 0, 2],
             [inf, inf, inf, inf, inf, 1, inf, inf, inf, 5, 2, 0]]
    
    
    return ( n , etiquettes , adj , XY , longueur_arete)


def graphe3():
    c = 6
    n=c*c
    # on donne un nom à chaque sommet
    etiquettes = [ k for k in range(n)]
    # listes d'adjacence
    adj = [  [j for j in ensemble(k,c,n) ]  for k in range(n) ]
    # coordonnées des sommets
    XY = [ ( 1.3*x + 0.2*randint(-2,2) , 1.3*y + 0.2*randint(-2,2))  for x in range(c) for y in range(c) ]
    
    longueur_arete = [[0, 10, inf, inf, inf, inf, 10, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [10, 0, 2, inf, inf, inf, inf, 10, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, 2, 0, 5, inf, inf, inf, inf, 10, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, 5, 0, 2, inf, inf, inf, inf, 5, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, 2, 0, 10, inf, inf, inf, inf, 10, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, 10, 0, inf, inf, inf, inf, inf, 1, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [10, inf, inf, inf, inf, inf, 0, 1, inf, inf, inf, inf, 5, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, 10, inf, inf, inf, inf, 1, 0, 5, inf, inf, inf, inf, 2, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, 10, inf, inf, inf, inf, 5, 0, 1, inf, inf, inf, inf, 5, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, 5, inf, inf, inf, inf, 1, 0, 5, inf, inf, inf, inf, 1, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, 10, inf, inf, inf, inf, 5, 0, 2, inf, inf, inf, inf, 10, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, 1, inf, inf, inf, inf, 2, 0, inf, inf, inf, inf, inf, 10, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, 5, inf, inf, inf, inf, inf, 0, 10, inf, inf, inf, inf, 5, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, 2, inf, inf, inf, inf, 10, 0, 5, inf, inf, inf, inf, 2, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, 5, inf, inf, inf, inf, 5, 0, 10, inf, inf, inf, inf, 1, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, 1, inf, inf, inf, inf, 10, 0, 10, inf, inf, inf, inf, 1, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 10, inf, inf, inf, inf, 10, 0, 2, inf, inf, inf, inf, 10, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 10, inf, inf, inf, inf, 2, 0, inf, inf, inf, inf, inf, 5, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 5, inf, inf, inf, inf, inf, 0, 2, inf, inf, inf, inf, 10, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 2, inf, inf, inf, inf, 2, 0, 2, inf, inf, inf, inf, 1, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 1, inf, inf, inf, inf, 2, 0, 10, inf, inf, inf, inf, 10, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 1, inf, inf, inf, inf, 10, 0, 2, inf, inf, inf, inf, 2, inf, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 10, inf, inf, inf, inf, 2, 0, 10, inf, inf, inf, inf, 2, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 5, inf, inf, inf, inf, 10, 0, inf, inf, inf, inf, inf, 10, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 10, inf, inf, inf, inf, inf, 0, 10, inf, inf, inf, inf, 5, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 1, inf, inf, inf, inf, 10, 0, 1, inf, inf, inf, inf, 1, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 10, inf, inf, inf, inf, 1, 0, 2, inf, inf, inf, inf, 1, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 2, inf, inf, inf, inf, 2, 0, 2, inf, inf, inf, inf, 10, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 2, inf, inf, inf, inf, 2, 0, 2, inf, inf, inf, inf, 10, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 10, inf, inf, inf, inf, 2, 0, inf, inf, inf, inf, inf, 1],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 5, inf, inf, inf, inf, inf, 0, 5, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 1, inf, inf, inf, inf, 5, 0, 10, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 1, inf, inf, inf, inf, 10, 0, 2, inf, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 10, inf, inf, inf, inf, 2, 0, 2, inf],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 10, inf, inf, inf, inf, 2, 0, 2],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 1, inf, inf, inf, inf, 2, 0]]
    
    return ( n , etiquettes , adj , XY,longueur_arete)



def pause():
    programPause = input("Appuyez sur Entrée:")
def ensemble(k,c,n):
    L = []
    if 0 <= k-c:
        L.append(k-c)
    if  k+c < n:
        L.append(k+c)
    if  k+1 < n and (k+1)%c != 0:
        L.append(k+1)
    if  k-1 >=0 and k%c != 0:
        L.append(k-1)
    
    return L

    
