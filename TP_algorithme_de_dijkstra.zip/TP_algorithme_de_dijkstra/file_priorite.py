from math import inf


class File_Priorite:
    def __init__(self):
        """ crée une file de priorité vide """
        self.file = []
        self.table = {}
    def est_vide(self):
        """ renvoie True si la file de priorité est vide et False sinon """
        if len(self.file) == 0 :
            return True
        else:
            return False
    def __str__(self):
        """ renvoie une chaîne de caractère qui décrit la file de priorité ainsi que l'état de la table"""
        ch = '############################ \n'
        ch =ch + " FILE \n"
        ch = ch + "sommet / poids \n" 
        for s in self.file:
            ch = ch + str(s) + ' / '+str( self.table[s] )+'\n'
        
        ch = ch + '\n TABLE \n'
        for sommet,poids in self.table.items():
            ch = ch +  '(' + str(sommet) + ',' + str(poids) + ') '
        ch = ch+'\n############################'
        return ch

    
    def __contains__(self,s):
        """ renvoie True si s est dans la file et False sinon """
        return s in self.file
    
    def ajouter( self ,sommet ):
        """ ajoute un sommet à la file """
        self.file.append( sommet )
    
    def enlever(self,sommet):
        """enlève le sommet de la file """
        self.file.remove(sommet)
    
    def poids(self,sommet):
        """ renvoie le poids du sommet """
        return self.table[sommet]
    
    def modifie_poids(self, sommet , poids):
        """  modifie le poids d'un sommet de la table si le nouveau poids est inférieur au précédent) """
        if sommet not in self.table:
            self.table[sommet] = poids
        elif  poids < self.table[sommet]:
            self.table[sommet] = poids
    
    def sommet_poids_minimal( self ):
        """ Renvoie le sommet de la file de priorité dont le poids est le plus faible  """
        m = inf
        sommet_a_enlever = None
        for sommet in self.file:
            poids = self.table[sommet]
            if poids < m:
                m = poids
                sommet_a_enlever = sommet
             
        return sommet_a_enlever



    




