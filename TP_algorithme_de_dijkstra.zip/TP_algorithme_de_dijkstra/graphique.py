from tkinter import *
from turtle import *
from random import randint


class Dessin:
    def __init__(self, XY , adj , poids , couleurs):
        self.window_height = 700
        self.window_width =  700

        #nc est le nombre de colonnes
        self.nc = 10

        self.canvas = getcanvas()
        
        self.XY = XY
        self.adj = adj
        self.poids = poids
        self.couleurs = couleurs

    def grille(self):
        hauteur = self.window_height
        largeur = self.window_width
        pas_x = largeur/nc
        pas_y = hauteur/nc
        #création des lignes horizontales
        for n in range(-nc//2,nc//2+1):
            self.canvas.create_line(-largeur/2,n*pas_y,largeur/2,n*pas_y)
        #création des lignes verticales
        for n in range(-nc//2,nc//2+1):
            self.canvas.create_line(n*pas_x,-largeur/2,n*pas_x,largeur/2)
     
    def echelle(self,x,y):
        hauteur = self.window_height
        largeur = self.window_width
        nc = self.nc
        pas_x = largeur/nc
        pas_y = hauteur/nc
        
        a=(largeur-pas_x)/(nc-1)
        b= (-largeur*nc+nc*pas_x-largeur+pas_x)/(2*nc-2)
        X = a*x+b
       
        m=(-hauteur+pas_x)/(nc-1)
        p= (hauteur*nc-nc*pas_y+hauteur-pas_y)/(2*nc-2)

        Y = m*y+p
        return (X+50,Y-50)


    def echelle_2(self,X,Y):
        hauteur = self.window_height
        largeur = self.window_width
        nc = self.nc
        pas_x = largeur/nc
        pas_y = hauteur/nc
        
        a=(largeur-pas_x)/(nc-1)
        b= (-largeur*nc+nc*pas_x-largeur+pas_x)/(2*nc-2)
        x=(X-b)/a
       
        m=(-hauteur+pas_x)/(nc-1)
        p= (hauteur*nc-nc*pas_y+hauteur-pas_y)/(2*nc-2)

        y=(Y-p)/m
        return (round(x),round(y))
        


    def cercle(self,x,y,r,couleur="black"):
        hauteur = self.window_height
        largeur = self.window_width
        nc = self.nc
        
        pas_x = largeur/nc
        pas_y = hauteur/nc
        (X,Y)=self.echelle(x,y)
        self.canvas.create_oval(X-r*pas_x/2,Y-r*pas_y/2,X+r*pas_x/2,Y+r*pas_y/2, fill=couleur)
    
    def segment(self,x1,y1,x2,y2,couleur="black"):
        hauteur = self.window_height
        largeur = self.window_width
        nc = self.nc
        
        pas_x = largeur/nc
        pas_y = hauteur/nc
        (X1,Y1)=self.echelle(x1,y1)
        (X2,Y2)=self.echelle(x2,y2)
        self.canvas.create_line(X1,Y1,X2,Y2, fill=couleur)
    
    def texte(self,x1,y1, txt ):
        hauteur = self.window_height
        largeur = self.window_width
        nc = self.nc
        
        pas_x = largeur/nc
        pas_y = hauteur/nc
        (X1,Y1)=self.echelle(x1,y1)
        self.canvas.create_text(X1,Y1, text = txt )
        
    def dessiner_sommets(self):
        self.cacher_tortue()
        k = 0
        for sommet in self.XY:
            self.cercle(sommet[0],sommet[1],0.5,self.couleurs[k])
            self.texte(sommet[0],sommet[1],str(k))
            k = k + 1 
        
        for s in range( len(self.adj) ):
            voisins = self.adj[s]
            for v in voisins:
                coordS = self.XY[s]
                coordV = self.XY[v]
                x_milieu = (self.XY[s][0] +self.XY[v][0])/2
                y_milieu = (self.XY[s][1] +self.XY[v][1])/2
                
                self.segment(coordS[0] , coordS[1],coordV[0] , coordV[1])
                self.texte(x_milieu , y_milieu ,str(self.poids[s][v])[0:4])
        self.cacher_tortue()
        
    def dessiner_chemin(self,t):
        self.cacher_tortue()
        
        for k in t:

            coord = self.XY[k]
            self.cercle(coord[0],coord[1],0.5,"yellow")
            self.texte(coord[0] , coord[1] ,str(k))
     

    def cacher_tortue(self):
        hideturtle()






