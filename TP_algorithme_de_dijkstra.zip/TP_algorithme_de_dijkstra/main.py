from math import inf,sqrt
from graphique import *
from file_priorite import File_Priorite
from time import sleep
from graphes import *
 


#####################################################


def couleurs_initiales( etiquettes ):
    """ colorie tous les sommets en gris """
    couleurs = {}
    for sommet in etiquettes:
        couleurs[ sommet ] = "grey"
    return couleurs



def dijkstra(depart,etiquettes):
    pass
            
    

def test_file_priorite():
    li = File_Priorite()
    print(str( li ) )
    li.ajouter(0)
    li.modifie_poids(0,0)
    print(str( li ) )
    li.ajouter(1)
    li.modifie_poids(1,longueur_arete[0][1])
    li.ajouter(2)
    li.modifie_poids(2,longueur_arete[0][2])
    print(str( li ) )
    li.ajouter(3)
    li.modifie_poids(3, li.poids(1) + longueur_arete[1][3] )
    print(str( li ) )
    #etc...



def test_coloriage_des_sommets():
    couleurs[ 0 ] = "red"
    ######### AFFICHAGE ################
    dessin.dessiner_sommets()
    sleep(TEMPS)
    ####################################
   
    couleurs[ 1 ] = "blue"
    ######### AFFICHAGE ################
    dessin.dessiner_sommets()
    sleep(TEMPS)
    ####################################
    
    couleurs[ 3 ] = "red"
    ######### AFFICHAGE ################
    dessin.dessiner_sommets()
    sleep(TEMPS)
    ####################################
        
TEMPS = 1.5
( n , etiquettes , adj , XY, longueur_arete ) = graphe1()
couleurs = couleurs_initiales( etiquettes )
dessin = Dessin(XY, adj , longueur_arete , couleurs)


depart = 0
dijkstra(depart,etiquettes)











