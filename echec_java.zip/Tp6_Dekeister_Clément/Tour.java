import java.util.ArrayList;

class Tour extends Piece {

    //Constructeur
    public Tour(){
        super('b',new Position());
    }
    public Tour(char couleur,Position pos ){
        super(couleur,pos);
    }

    //GETTER
    public String getType(){
        return "tour" ;
    }

    //renvoie un tableau contenant les positions possible de déplacement de la pièce
    public ArrayList<Position> getDeplacementPossible(Plateau plateau){
        //on récupère la position de la pièce pour éviter de recopier à chaque fois
        Position pos = new Position(this.getPos());
        ArrayList<Position> deplacementPossible = new ArrayList<Position>();

        //booleen vaut true si il a pu se déplacer sur cet axe au tour précédent
        boolean haut= true;
        boolean bas= true;
        boolean gauche= true;
        boolean droite= true;
        //à chaque tour on regarde si la case d'après sur l'axe x et y est disponible
        for(int i=1; i<8 ;i++){

            //----------------pour les cases vers le haut----------------//
            if( plateau.getCase(pos.getX()+i,pos.getY())==null  && haut){
                deplacementPossible.add(new Position(pos.getX()+i,pos.getY()));
            }
            //si il tombe sur une autre pièce
            else if(plateau.getCase(pos.getX()+i,pos.getY()) !=null && haut){
                //vérifie si la case est de la même couleur
                if(plateau.getCase(pos.getX()+i,pos.getY()).getCouleur()==this.getCouleur()){
                    haut=false;
                }
                //Il peut se déplacer sur la case pour la manger mais ne pourras pas aller plus loin
                else{
                deplacementPossible.add(new Position(pos.getX()+i,pos.getY()));
                haut=false;
                }
            }
            else{haut=false;}

            //----------------pour les cases vers le bas----------------//
            if(plateau.getCase(pos.getX()-i,pos.getY())==null && bas){
                deplacementPossible.add(new Position(pos.getX()-i,pos.getY()));
            }
            else if(plateau.getCase(pos.getX()-i,pos.getY()) != null && bas){
                if(plateau.getCase(pos.getX()-i,pos.getY()).getCouleur()==this.getCouleur() ){
                    bas=false;
                }
                else{
                deplacementPossible.add(new Position(pos.getX()-i,pos.getY()));
                bas=false;
                }
            }
            else{bas=false;}

            //----------------pour les cases vers la droite----------------//
            if(plateau.getCase(pos.getX(),pos.getY()+i)==null && droite){
                deplacementPossible.add(new Position(pos.getX(),pos.getY()+i));
            }
            else if(plateau.getCase(pos.getX(),pos.getY()+i)==null && droite){
                if(plateau.getCase(pos.getX(),pos.getY()+i).getCouleur()==this.getCouleur()){
                    droite=false;
                }
                else{
                    deplacementPossible.add(new Position(pos.getX(),pos.getY()+i));
                    droite=false;
                }
            }
            else{droite=false;}

            //----------------pour les cases vers la gauche----------------//
            if(plateau.getCase(pos.getX(),pos.getY()-i)==null && gauche ){
                deplacementPossible.add(new Position(pos.getX(),pos.getY()-i));
            }
            else if(plateau.getCase(pos.getX(),pos.getY()-i)==null && gauche){
                if(plateau.getCase(pos.getX(),pos.getY()-i).getCouleur()==this.getCouleur()){
                    gauche=false;
                }
                deplacementPossible.add(new Position(pos.getX(),pos.getY()-i));
                gauche=false;
            }
            else{gauche=false;}
        }
        return deplacementPossible;
    } 

     
}
