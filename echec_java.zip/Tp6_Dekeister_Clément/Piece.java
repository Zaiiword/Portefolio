import java.util.ArrayList;

public abstract class Piece {
    private char couleur;
    private Position pos;


    //constructeur par défaut
    public Piece(){
        this.couleur='B';
        this.pos= new Position("A2");
    }

    //constructeur par avec nom en paramètre
    public Piece( char couleur, Position pos){
        this.couleur = couleur;
        this.pos = new Position(pos);
    }

    //constructeur par copie
    public Piece(Piece piece){
        this.couleur=piece.couleur;
        this.pos=new Position(piece.pos);
    }

    public Piece(char couleur,int x, int y){
        this.couleur = couleur;
        this.pos = new Position(x,y);
    }

    public Piece(String type, char couleur,String pos){
        this.couleur = couleur;
        this.pos = new Position(pos);
    }

    //getter
    public Position getPos(){
        return this.pos ;
    }

    public abstract String getType();

    public char getCouleur(){
        return this.couleur ;
    }

    //setter
    public void setPos(Position pos){
        this.pos = new Position(pos);
    }

    public void setCouleur(char couleur){
        this.couleur = couleur;
    }

    public String getNomCourt(){
        char ch1 = Character.toUpperCase(this.getType().charAt(0));
        char ch2 = this.getType().charAt(1);
        char ch3 = this.couleur;
        char data[] = {ch1,ch2,ch3};
        String nom = new String(data);
        return nom;        
    }


    public String getNomLong(){
        String nom = this.getType()+"_"+this.getCouleur();
        return(nom);
    }

    //méthode equals
    public boolean equals(Object obj){
        if(obj == this){
            return true ;
        }
        return false;
    }

     //toString
     public String toString(){
        String couleur;
        if (this.couleur=='B'){couleur =" blanc ";}
        else{couleur =" noir ";}
        return(this.getType()+couleur+"en "+this.pos.toString());
    }

    //-------------------Déplacements-------------------//
    public abstract ArrayList<Position> getDeplacementPossible(Plateau plateau);

    

}
