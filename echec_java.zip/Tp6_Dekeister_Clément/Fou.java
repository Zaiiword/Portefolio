import java.util.ArrayList;

class Fou extends Piece{

    //Constructeur
    public Fou(){
        super('b',new Position());
    }
    public Fou(char couleur,Position pos ){
        super(couleur,pos);
    }

    public String getType(){
        return "fou" ;
    }

    public ArrayList<Position> getDeplacementPossible(Plateau plateau){
        //on récupère la position de la pièce pour éviter de recopier à chaque fois
        Position pos = new Position(this.getPos());
        ArrayList<Position> deplacementPossible = new ArrayList<Position>();

        //booleen vaut true si il a pu se déplacer sur cet axe au tour précédent
        boolean haut_gauche= true;
        boolean haut_droite= true;
        boolean bas_gauche= true;
        boolean bas_droite= true;
        //à chaque tour on regarde si la case d'après sur l'axe x et y est disponible
        for(int i=1; i<8 ;i++){

            //----------------pour les cases vers la diagonale haut_gauche----------------//
            if( plateau.getCase(pos.getX()-i,pos.getY()-i)==null  && haut_gauche){
                deplacementPossible.add(new Position(pos.getX()-i,pos.getY()-i));
            }
            //si il tombe sur une autre pièce
            else if(plateau.getCase(pos.getX()-i,pos.getY()-i) !=null && haut_gauche){
                //vérifie si la case est de la même couleur
                if(plateau.getCase(pos.getX()-i,pos.getY()-i).getCouleur()==this.getCouleur()){
                    haut_gauche=false;
                }
                //Il peut se déplacer sur la case pour la manger mais ne pourras pas aller plus loin
                else{
                deplacementPossible.add(new Position(pos.getX()-i,pos.getY()-i));
                haut_gauche=false;
                }
            }
            else{haut_gauche=false;}

            //----------------pour les cases vers la diagonal haut_droite----------------//
            if(plateau.getCase(pos.getX()-i,pos.getY()+i)==null && haut_droite){
                deplacementPossible.add(new Position(pos.getX()-i,pos.getY()+i));
            }
            else if(plateau.getCase(pos.getX()-i,pos.getY()+i) != null && haut_droite){
                if(plateau.getCase(pos.getX()-i,pos.getY()+i).getCouleur()==this.getCouleur() ){
                    haut_droite=false;
                }
                else{
                deplacementPossible.add(new Position(pos.getX()-i,pos.getY()+i));
                haut_droite=false;
                }
            }
            else{haut_droite=false;}

            //----------------pour les cases vers la diagonale bas_droite----------------//
            if(plateau.getCase(pos.getX()+i,pos.getY()+i)==null && bas_droite){
                deplacementPossible.add(new Position(pos.getX()+i,pos.getY()+i));
            }
            else if(plateau.getCase(pos.getX()+i,pos.getY()+i)==null && bas_droite){
                if(plateau.getCase(pos.getX()+i,pos.getY()+i).getCouleur()==this.getCouleur()){
                    bas_droite=false;
                }
                else{
                    deplacementPossible.add(new Position(pos.getX()+i,pos.getY()+i));
                    bas_droite=false;
                }
            }
            else{bas_droite=false;}

            //----------------pour les cases vers la diagonal bah_gauche----------------//
            if(plateau.getCase(pos.getX()+i,pos.getY()-i)==null && bas_gauche ){
                deplacementPossible.add(new Position(pos.getX()+i,pos.getY()-i));
            }
            else if(plateau.getCase(pos.getX()+i,pos.getY()-i)==null && bas_gauche){
                if(plateau.getCase(pos.getX()+i,pos.getY()-i).getCouleur()==this.getCouleur()){
                    bas_gauche=false;
                }
                deplacementPossible.add(new Position(pos.getX()+i,pos.getY()-i));
                bas_gauche=false;
            }
            else{bas_gauche=false;}
        }
        return deplacementPossible;
    } 

    

   
}
