import java.util.ArrayList;

class Roi extends Piece {

    //Constructeur
    public Roi(){
        super('b',new Position());
    }
    public Roi( char couleur,Position pos){
        super(couleur,pos);
    }
    
    public String getType(){
        return "roi" ;
    }

    public ArrayList<Position> getDeplacementPossible(Plateau plateau){
        Position pos = new Position(this.getPos());
        ArrayList<Position> deplacementPossible = new ArrayList<Position>();
        for(int i=-1; i<2 ;i++){
            for(int j=-1; j<2 ;j++){
                if(pos.getX()+i>-1 &&  pos.getX()+i<8 && pos.getY()+j>-1 &&  pos.getY()+j<8 ){
                    if(plateau.getCase(pos.getX()+i,pos.getY()+j) == null ){
                        deplacementPossible.add(new Position(pos.getX()+i,pos.getY()+j));
                    }
                    else if(plateau.getCase(pos.getX()+i,pos.getY()+j).getCouleur() != this.getCouleur() ){
                        deplacementPossible.add(new Position(pos.getX()+i,pos.getY()+j));
                    }
                }   
            }
        }
        return deplacementPossible ;
    }
}
