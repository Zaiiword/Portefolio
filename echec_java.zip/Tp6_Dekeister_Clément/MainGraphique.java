import java.util.ArrayList;
import MG2D . *;
import MG2D.geometrie . *;

public class MainGraphique {

    public static void main ( String[] args ){
        Fenetre f = new Fenetre("échec", 600 , 600 ) ;
        Plateau plateau = new Plateau();
        Souris souris = f.getSouris();
        ArrayList<Position> deplacement_libre = new ArrayList<Position>();
        int nombre_tour = 0;
        boolean joueur;

        //créé le cadrillage
        for(int i=0; i<8 ;i++){
            for(int j=0; j<8 ;j++){  
                f.ajouter(new Carre(Couleur.GRIS_FONCE,new Point((i*150),(j*150)),75,true));
                f.ajouter(new Carre(Couleur.GRIS_FONCE,new Point((i*150)+75,(j*150)+75),75,true));    
            }
        }
        //ajoute les pièce à leur position de départ
        for(int i=0; i<8 ;i++){
            for(int j=0; j<8 ;j++){
                if(plateau.getCase(i,j) != null){
                    f.ajouter(new Texture("./images/"+plateau.getCase(i,j).getNomLong()+".png",new Point((j*75),(i*75)),75,75));
                    f.rafraichir();
                }
            }
        }
        f.rafraichir();
        
        //boucle de la partie
        while(true){

            //détermine quel est le tour
            nombre_tour ++ ;
            if(nombre_tour%2 != 0){
                joueur = true;
            }
            else{
                joueur = false;
            }
            boolean peutDeplacer = true;
            Position pos = new Position();

            while(peutDeplacer){
                while(! souris.getClicGauche()){
                    try{
                        Thread.sleep(1);
                        }
                    catch( Exception e){}
                }
                //detecte sur quelle pièce clic l'utilisateur
                pos = new Position(souris.getPosition().getY()/75,souris.getPosition().getX()/75);
                //regarde s'il peut déplacer cette case
                
                //si c'est le joueur 1
                if(joueur){
                    ArrayList<Piece> emplacementPiece = new ArrayList<Piece>();
                    emplacementPiece = plateau.getPiecesBlanches();
                    for(int i=0;i<emplacementPiece.size();i++){
                        if(emplacementPiece.get(i).getPos().equals(pos)){
                            peutDeplacer=false;
                        }
                    }
                }
                //si c'est le joueur 2
                else{
                    ArrayList<Piece> emplacementPiece = new ArrayList<Piece>();
                    emplacementPiece = plateau.getPiecesNoires();
                    for(int i=0;i<emplacementPiece.size();i++){
                        if(emplacementPiece.get(i).getPos().equals(pos)){
                            peutDeplacer=false;
                        }
                    }
                }
            }
            //regarde sur quelle case la pièce peut ce déplacer
            deplacement_libre =plateau.getCase(pos).getDeplacementPossible(plateau);
            for(int i=0;i<deplacement_libre.size();i++){
                f.ajouter(new Cercle(Couleur.ROUGE,new Point(deplacement_libre.get(i).getY()*75+37,deplacement_libre.get(i).getX()*75+37),30));
            }
            f.rafraichir();

            //on attends qu'il clic sur la case où il souhaite se déplacer 
            while(! souris.getClicGauche()){
                try{
                    Thread.sleep(1);
                    }
                catch( Exception e){}
            }
            Position destination = new Position(souris.getPosition().getY()/75,souris.getPosition().getX()/75);
            //on vérifie que le déplacement est possible
            if(plateau.deplacer(pos, destination)){
                //on déplace la pièce dans le plateau 
            }

            // -----------------------RÉAFFICHAGE DE L'ÉCRAN---------------------//

            //efface le precedent affichage
            f.effacer();
            //créé le cadrillage
            for(int i=0; i<8 ;i++){
                for(int j=0; j<8 ;j++){  
                    f.ajouter(new Carre(Couleur.GRIS_FONCE,new Point((i*150),(j*150)),75,true));
                    f.ajouter(new Carre(Couleur.GRIS_FONCE,new Point((i*150)+75,(j*150)+75),75,true));    
                }
            }

            //on regarde si le roi est en échec
            if(joueur){
                if(plateau.estEchec('B')){
                    int x =plateau.getRoi('B').getPos().getX();
                    int y = plateau.getRoi('B').getPos().getY();
                    f.ajouter(new Carre(Couleur.ROUGE,new Point(x*75,y*75),75,true));
                }
            }
            else{
                if(plateau.estEchec('N')){
                    int x =plateau.getRoi('N').getPos().getX();
                    int y = plateau.getRoi('N').getPos().getY();
                    f.ajouter(new Carre(Couleur.ROUGE,new Point(x*75,y*75),75,true));
                }
            }

            //ajoute les pièces
            for(int i=0; i<8 ;i++){
                for(int j=0; j<8 ;j++){
                    if(plateau.getCase(i,j) != null){
                        f.ajouter(new Texture("./images/"+plateau.getCase(i,j).getNomLong()+".png",new Point((j*75),(i*75)),75,75));
                    }
                }
            }
            f.rafraichir();
        }
    }
}     

// Question substidiaire
//il faudrait rajouter un booleen au niveau du test qui détermine si le roi est en échec
//afin de savoir si l'a déjà été ensuite il faudrait faire de même pour savoir si 
//la fonction de déplacement du roi a déjà était utilisé 
//ensuite il faudrait rajouter une partie supplémentaire dans le déplacement du roi qui 
//si les 2 conditions sont réunis échange les coordonées des 2 pièces.