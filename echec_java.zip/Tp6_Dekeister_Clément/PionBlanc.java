import java.util.ArrayList;

class PionBlanc extends Pion {
    public PionBlanc(){
        super('B',new Position());
    }
    public PionBlanc(Position pos){
        super('B',pos);
    }

    //deplacement//
    public ArrayList<Position> getDeplacementPossible(Plateau plateau){
        Position pos = new Position(this.getPos());
        ArrayList<Position> deplacementPossible = new ArrayList<Position>();
        //System.out.print(plateau.getCase(pos.getX()+1,pos.getY()));
        if(plateau.getCase(pos.getX()+1,pos.getY()) == null ){
            deplacementPossible.add(new Position(pos.getX()+1,pos.getY()));
            //si la première case est libre alors on peut regarder la deuxième 
            //si il est sur la "ligne de départ"
            if(pos.getX()==1 && plateau.getCase(pos.getX()+2,pos.getY()) == null ){
                deplacementPossible.add(new Position(pos.getX()+2,pos.getY()));
            }
        }
        //on regarde si il peut manger une pièce en haut à droite 
        if(plateau.getCase(pos.getX()+1,pos.getY()+1) != null ){
            if(plateau.getCase(pos.getX()+1,pos.getY()+1).getCouleur() != this.getCouleur()){
                deplacementPossible.add(new Position(pos.getX()+1,pos.getY()+1));
            }
        }
        //on regarde si il peut manger une pièce en haut à gauche 
        if(plateau.getCase(pos.getX()+1,pos.getY()-1) != null ){
            if(plateau.getCase(pos.getX()+1,pos.getY()-1).getCouleur() != this.getCouleur()){
                deplacementPossible.add(new Position(pos.getX()+1,pos.getY()-1));
            }
        }
        return deplacementPossible;   
    }
}
