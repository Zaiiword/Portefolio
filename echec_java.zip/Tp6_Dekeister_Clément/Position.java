class Position {
    private int x;
    private int y;

    //constructeur par ddéfaut
    public Position(){
        this.x=0;
        this.y=0;
    }

    //constructeur par copie
    public Position(Position pos){
        this.x=pos.x;
        this.y=pos.y;
    }

    //constructeur avec entier
    public Position(int x, int y){
        this.x=x;
        this.y=y;
    }

    //constructeur avec chaine de caractere
    public Position(String chaine){
        String ligne = new String("ABCDEFGH");
        int y=Integer.parseInt(String.valueOf(chaine.charAt(1)));
        this.x=ligne.indexOf(chaine.charAt(0));
        this.y=y;
    }

    //Getter
    public int getX(){
        return this.x;
    }
    public int getY(){
        return this.y;
    }

    //Setter 
    public void setX(int x){
        this.x=x;
    }
    public void setY(int y){
        this.y=y;
    }

    //méthode equals
    public boolean equals(Position pos){
        if(this.x == pos.getX() && this.y ==pos.getY()){
            return true;
        }
        return false;
    }

    public String toString(){
        String coord = new String("ABCDEFGH")  ;
        return(String.valueOf(coord.charAt(this.x)) +this.y);

    }
}