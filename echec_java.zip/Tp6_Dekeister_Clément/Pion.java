import java.util.ArrayList;

public abstract class Pion extends Piece {

    //Constructeur par défaut
    public Pion(){
        super();
    }

    //constructeur avec arguments
    public Pion(char couleur,Position pos){
        super(couleur,pos);
    }

    public String getType(){
        return "pion" ;
    }


    public abstract ArrayList<Position> getDeplacementPossible(Plateau plateau);
}
