import java.util.ArrayList;

class Dame extends Piece {

    //Constructeur
    public Dame(){
        super('b',new Position());
    }
    public Dame( char couleur,Position pos){
        super(couleur,pos);
    }

    public String getType(){
        return "dame" ;
    }

    public ArrayList<Position> getDeplacementPossible(Plateau plateau){
        ArrayList<Position> deplacementPossible = new ArrayList<Position>();
        ArrayList<Position> deplacementPossible_fou = new ArrayList<Position>();
        ArrayList<Position> deplacementPossible_tour = new ArrayList<Position>();

        deplacementPossible_tour = (new Tour(this.getCouleur(),new Position(this.getPos())).getDeplacementPossible(plateau));
        deplacementPossible_fou = (new Fou(this.getCouleur(),new Position(this.getPos())).getDeplacementPossible(plateau));
        for(int i=0;i<deplacementPossible_tour.size();i++){
            deplacementPossible.add(deplacementPossible_tour.get(i));
        }
        for(int i=0;i<deplacementPossible_fou.size();i++){
            deplacementPossible.add(deplacementPossible_fou.get(i));
        }
        return deplacementPossible;
    }
}
