import java.util.ArrayList;

class Cavalier extends Piece {

    //Constructeur
    public Cavalier(){
        super('b',new Position());
    }
    public Cavalier(char couleur,Position pos ){
        super(couleur,pos);
    }

    public String getType(){
        return "cavalier" ;
    }

    public ArrayList<Position> getDeplacementPossible(Plateau plateau){
        Position pos = new Position(this.getPos());
        ArrayList<Position> deplacementPossible = new ArrayList<Position>();

        for(int i=-2;i<3;i+=4){
            for(int j=-1;j<2;j+=2){
                if(plateau.getCase(pos.getX()+i,pos.getY()+j) == null ||
                   plateau.getCase(pos.getX()+i,pos.getY()+j).getCouleur() != this.getCouleur() ){
                    deplacementPossible.add(new Position(pos.getX()+i,pos.getY()+j));
                }
                if(plateau.getCase(pos.getX()+j,pos.getY()+i) == null || 
                   plateau.getCase(pos.getX()+j,pos.getY()+i).getCouleur() != this.getCouleur() ){
                    deplacementPossible.add(new Position(pos.getX()+j,pos.getY()+i));
                }
            }
        }
        return deplacementPossible;
    }
}
