import java.util.ArrayList;

class PionNoir extends Pion {
    //Constructeur
    public PionNoir(){
        super('N',new Position());
    }
    public PionNoir(Position pos){
        super('N',new Position(pos));
    }

    public ArrayList<Position> getDeplacementPossible(Plateau plateau){
        Position pos = new Position(this.getPos());
        ArrayList<Position> deplacementPossible = new ArrayList<Position>();

        if(plateau.getCase(pos.getX()-1,pos.getY()) == null ){
            deplacementPossible.add(new Position(pos.getX()-1,pos.getY()));
            //si la première case est libre alors on peut regarder la deuxième 
            //si il est sur la "ligne de départ"
            if(pos.getX()==6 && plateau.getCase(pos.getX()-2,pos.getY()) == null ){
                deplacementPossible.add(new Position(pos.getX()-2,pos.getY()));
            }
        }
        //on regarde si il peut manger une pièce en bas à droite 
        if(plateau.getCase(pos.getX()-1,pos.getY()+1) != null ){
            if(plateau.getCase(pos.getX()-1,pos.getY()+1).getCouleur() != this.getCouleur()){
                deplacementPossible.add(new Position(pos.getX()-1,pos.getY()+1));
            }
        }
        //on regarde si il peut manger une pièce en bas à gauche 
        if(plateau.getCase(pos.getX()-1,pos.getY()-1) != null ){
            if(plateau.getCase(pos.getX()-1,pos.getY()-1).getCouleur() != this.getCouleur()){
                deplacementPossible.add(new Position(pos.getX()-1,pos.getY()-1));
            }
        }

        return deplacementPossible;
        
    }
}
