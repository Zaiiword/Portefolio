import java.util.ArrayList;

class Plateau {
    //attributs

    private ArrayList<Piece> tableau = new ArrayList<Piece>();
        
    //constructeur de base
    public Plateau()
    {
        tableau.add(new Tour('B',new Position(0,0)));
        tableau.add(new Cavalier('B',new Position(0,1)));
        tableau.add(new Fou('B',new Position(0,2)));
        tableau.add(new Dame('B',new Position(0,3)));
        tableau.add(new Roi('B',new Position(0,4)));
        tableau.add(new Fou('B',new Position(0,5)));
        tableau.add(new Cavalier('B',new Position(0,6)));
        tableau.add(new Tour('B',new Position(0,7)));
        tableau.add(new Tour('N',new Position(7,0)));
        tableau.add(new Cavalier('N',new Position(7,1)));
        tableau.add(new Fou('N',new Position(7,2)));
        tableau.add(new Dame('N',new Position(7,3)));
        tableau.add(new Roi('N',new Position(7,4)));
        tableau.add(new Fou('N',new Position(7,5)));
        tableau.add(new Cavalier('N',new Position(7,6)));
        tableau.add(new Tour('N',new Position(7,7)));
        for(int i=0; i<8;i++) {
            tableau.add(new PionBlanc(new Position(1,i)));
            tableau.add(new PionNoir(new Position(6,i)));
        }
    }

    //méthodes getCase
    public Piece getCase(int x, int y){
        for(int i=0; i<tableau.size() ;i++){
            if (tableau.get(i).getPos().equals(new Position(x,y))){
                return tableau.get(i);
            }
        }
        //System.out.println("la case est vide");
        return null;
    }

    public Piece getCase(Position pos){
        for(int i=0; i<tableau.size() ;i++){
            if (tableau.get(i).getPos().equals(new Position(pos))){
                return tableau.get(i);
            }
        }
        System.out.println("la case est vide");
        return null;
    }

    public Piece getCase(String pos){
        for(int i=0; i<tableau.size() ;i++){
            if (tableau.get(i).getPos().equals(new Position(pos))){
                return tableau.get(i);
            }
        }
        System.out.println("la case est vide");
        return null;
    }
    
    //méthode toString
    public String toString(){
        boolean case_place= true;
        String finale= new String();
        finale=finale+" |---|---|---|---|---|---|---|---|\n";
        for(int i=0; i<8 ;i++){
            finale=finale+(8-i)+"|";
            for(int j=0; j<8 ;j++){
                //on parcours le tableau pour chaque case du plateau
                for(int h=0; h<tableau.size() ;h++){
                    if(tableau.get(h).getPos().equals(new Position(i,j))){
                        finale=finale+tableau.get(h).getNomCourt()+"|";
                        case_place=false;
                        }     
                    }
                if(case_place){
                    finale=finale+"   |";
                }
                case_place=true;
            }
            finale=finale+(8-i)+"\n";
            finale=finale+" |---|---|---|---|---|---|---|---|\n";    
        }
        finale=finale+"   A   B   C   D   E   F   G   H";
        return finale;
    }

    public ArrayList<Piece> getPiecesBlanches(){
        ArrayList<Piece> pieces_blanche = new ArrayList<Piece>();
        for(int i=0; i<tableau.size() ;i++){
            if(tableau.get(i).getCouleur() == 'B' ){
                pieces_blanche.add(tableau.get(i));    
            }
        }
        return pieces_blanche ;
    }

    public ArrayList<Piece> getPiecesNoires(){
        ArrayList<Piece> pieces_noire = new ArrayList<Piece>();
        for(int i=0; i<tableau.size() ;i++){
            if(tableau.get(i).getCouleur() == 'N' ){
                pieces_noire.add(tableau.get(i));    
            }
        }
        return pieces_noire ;
    }

    public boolean deplacer(Position from, Position to){
        ArrayList<Position> liste_positions = new ArrayList<Position>();
        //on demande toute les cases ou la pièce peut se deplacer
        liste_positions = this.getCase(from).getDeplacementPossible(this);
        //si la destination en fait partie alors on renvoie true
        for(int i=0;i<liste_positions.size();i++){
            if(to.equals(liste_positions.get(i)) ){
                for(int j=0; j<tableau.size() ;j++){
                    //on supprime la piece sur lequel il va ce déplacer
                    if(tableau.get(j).getPos().equals(to)){
                        tableau.remove(j);
                    }
                    //et on change la position de la piece
                    if(tableau.get(j).getPos().equals(from)){
                        tableau.get(j).setPos(to);   
                    }
                }
                return true;
            }
        }
        //autrement false
        return false;
    }

    public Piece getRoi(char couleur){
        //on parcourt le tableau
        String nomLong = new String("roi_"+couleur);
        for(int i=0;i<tableau.size();i++){
            //quand on tombe sur le roi on le renvoie
            if(tableau.get(i).getNomLong().equals(nomLong)){
                return tableau.get(i);
            }
        }
        //normalement n'arrive jamais ici mais vscode n'aime pas les
        //return dans un if
        return new Tour();
    } 

    public boolean estEchec(char couleur){
        Piece roi = getRoi(couleur);
        ArrayList<Piece> liste_Pieces = new ArrayList<Piece>();
        if(couleur == 'B'){
            liste_Pieces = getPiecesNoires();
        }
        else{
            liste_Pieces = getPiecesBlanches();
        }
        for(int i=0;i<liste_Pieces.size();i++){
            ArrayList<Position> liste_positions = new ArrayList<Position>();
            liste_positions = liste_Pieces.get(i).getDeplacementPossible(this);
            for(int j=0;j<liste_positions.size();j++){
                if(roi.getPos().equals(liste_positions.get(j))){
                    return true;
                }
            }
        }
        return false;
    }
}