# MonopoLille

## Tout pour la thune

- Decobecq Noé
- Dekeister Clément
- Kozan Jade
- Bouton Sacha
- Lasselin Lucas
- François Antonin
