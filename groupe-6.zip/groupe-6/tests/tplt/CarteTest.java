package tplt;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;


public class CarteTest {
	Joueur j1 = new Joueur(1000,"joueur",'j');
	Carte c1 = new Carte("chance","gagner 200 balles",200,1);
	Carte c2 = new Carte("piège","perdre 200 balles",200,2);
	Carte c3 = new Carte("piège","prison",16,3);
	Carte c5 = new Carte("chance","avancer",3,5);
	Carte c6 = new Carte("piège","perdre 400 balles",400,2);
	
	@Test
	public void testCarteGainArgent() {
		c1.effetGainArgent(j1);
		assertEquals(1200,j1.getArgent());
	}
	
	@Test
	public void testEffetPerteArgent() {
		c2.effetPerteArgent(j1);
		assertEquals(800,j1.getArgent());
	}
	
	@Test
	public void testEffetPrisonParc() {
		c3.effetPrisonParc(j1);
		assertTrue(j1.estPrisonnier());
	}
	
	@Test
	public void testEffetAvancer() {
		int positionAnt = j1.getPosition();
		c5.effetAvancer(j1);
		assertNotEquals(positionAnt,j1.getPosition());
	}
	
	
}
