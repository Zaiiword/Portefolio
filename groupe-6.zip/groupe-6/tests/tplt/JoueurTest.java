package tplt;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;


class JoueurTest {
	
	@Test
	void testSetPosition(){
		Joueur j1 = new Joueur(12000, "noé", 'a');
		j1.setPosition(81);
		assertEquals(j1.getPosition(), 81%36);
		assertEquals(j1.getTours(), 1);
	}
	@Test
	public void testAddProp() {
		Joueur j1 = new Joueur(12000, "noe",'a');
		Joueur j2 = new Joueur(12000, "lucas",'l');
		Propriete prop1 = new Propriete("Lille","",12000);
		assertTrue(j1.addProp(prop1));
		j1.addProp(prop1);
		assertFalse(j2.addProp(prop1));
	}
	@Test
	public void testFaillite() {
		Joueur j1 = new Joueur(12000, "lucas",'l');
		Propriete prop1 = new Propriete("Lille","",12000);
		Joueur j2 = new Joueur(12000, "lucas",'l');
		Propriete prop2 = new Propriete("Lille","",12000);
		assertFalse(j1.faillite(prop1));
		assertTrue(j2.faillite(prop2));
	}
	@Test
	public void testPerdu() {
		Joueur j1 = new Joueur(12000, "lucas",'l');
		Propriete prop1 = new Propriete("Lille","",12000);
		Propriete prop2 = new Propriete("Lille","",12000);
		Propriete prop3 = new Propriete("Lille","",120);
		Propriete prop4 = new Propriete("Lille","",120);
		Joueur j2 = new Joueur(-12000,"noé",'l');
		j2.addProp(prop3);
		j2.addProp(prop4);
		j1.addProp(prop1);
		j1.addProp(prop2);
		assertFalse(j1.perdu());
		assertTrue(j2.perdu());
	}
	@Test
	public void testEchange() {
		Joueur j1 = new Joueur(12000, "lucas",'l');
		Propriete prop1 = new Propriete("Lille","",12000);
		Propriete prop2 = new Propriete("Lille","",12000);
		Propriete prop3 = new Propriete("Lille","",120);
		Propriete prop4 = new Propriete("Lille","",120);
		Joueur j2 = new Joueur(12000,"noé",'l');
		j2.addProp(prop3);
		j2.addProp(prop4);
		j1.addProp(prop1);
		j1.addProp(prop2);
		j1.echange(j2, prop1, prop3);
		//assertEquals(j2.getArgent(),14000);
		assertTrue(j2.getAchat().contains(prop1));
		assertTrue(j1.getAchat().contains(prop3));
		//assertEquals(j1.getArgent(),10000);
	}
}
