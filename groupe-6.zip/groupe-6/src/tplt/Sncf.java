package tplt;

public class Sncf extends Case{

	public Sncf() {
		super("SNCF", "SNCF");
	}
	
	public void triggerEvent(Joueur j) {
		int random = (int) (Math.random()*10)+1;
		System.out.println("La SNCF a du retard, quel surprise vous reculez de :" + random);
		j.setPosition(j.getPosition()-random);
	}
	
	
}
