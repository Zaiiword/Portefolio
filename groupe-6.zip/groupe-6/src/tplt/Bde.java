package tplt;

import java.util.Scanner;

public class Bde extends Case{

	private int positionCase;
	
	public Bde() {
		super("BDE","BDE");
	}
	
	public void triggerEvent(Joueur j, Plateau p) {
		Scanner sc = new Scanner(System.in);
		int i = 0;
		while(i < 0 || i > p.getNbCases() && p.getCase(i).getClass() != new Propriete(null,null,0).getClass()) {
			System.out.println("Un bde cherche un bar pour se poser, choisissez un batiment qui accueillera toutes ces personnes (valorisation de l'immobilier) exemple 1 2 3..");
			i = sc.nextInt();
		}
		Bde.this.setPositionCase(j.getPosition());
		((Propriete) p.getCase(i)).setLoyer((int)(((Propriete) p.getCase(i)).getLoyer()*2));
		sc.close();
	}

	public int getPositionCase() {
		return positionCase;
	}

	public void setPositionCase(int positionCase) {
		this.positionCase = positionCase;
	}
	
	

}
