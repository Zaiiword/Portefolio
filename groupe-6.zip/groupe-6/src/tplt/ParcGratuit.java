package tplt;

public class ParcGratuit extends Case{
	private int solde;
	
	
	public ParcGratuit() {
		super("Parc Gratuit", "Parc");
		this.solde = 0;
	}
	
	public int getSolde() {
		return solde;
	}
	public void setSolde(int argent) {
		this.solde = argent;
	}
	public void ajouteSolde(int argent) {
		this.solde=this.getSolde()+argent;
	}
	public int videSolde() {
		int stockage=this.getSolde();
		this.setSolde(0);
		return stockage;
	}
		
	public String getNom() {
		return super.getNom();
	}
	
}
