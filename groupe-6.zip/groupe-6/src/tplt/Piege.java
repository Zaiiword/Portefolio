package tplt;

public class Piege extends Case {

	public Piege() {
		super("Piège", "Piège");
	}
	
	public void pieger(Case c) {
		c.setEstPiegee(true);
	}
}
