package tplt;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Use {
	public static void main(String[] args) {
		int save = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println(
				"                                                                                               \n"
						+ " _|      _|                                                    _|        _|  _|  _|            \n"
						+ " _|_|  _|_|    _|_|    _|_|_|      _|_|    _|_|_|      _|_|    _|            _|  _|    _|_|    \n"
						+ " _|  _|  _|  _|    _|  _|    _|  _|    _|  _|    _|  _|    _|  _|        _|  _|  _|  _|_|_|_|  \n"
						+ " _|      _|  _|    _|  _|    _|  _|    _|  _|    _|  _|    _|  _|        _|  _|  _|  _|        \n"
						+ " _|      _|    _|_|    _|    _|    _|_|    _|_|_|      _|_|    _|_|_|_|  _|  _|  _|    _|_|_|  \n"
						+ "                                           _|                                                  \n"
						+ "                                           _|                                                  ");
		System.out.println("             _   _   _   _     _   _   _   _     _   _     _   _   _   _   _  \n"
				+ "            / \\ / \\ / \\ / \\   / \\ / \\ / \\ / \\   / \\ / \\   / \\ / \\ / \\ / \\ / \\ \n"
				+ "           ( T | o | u | t ) ( P | o | u | r ) ( l | a ) ( T | h | u | n | e )\n"
				+ "            \\_/ \\_/ \\_/ \\_/   \\_/ \\_/ \\_/ \\_/   \\_/ \\_/   \\_/ \\_/ \\_/ \\_/ \\_/ \n\n");
		System.out.println("\n\n Bienvenue dans MonopoLille: Un jeu qui consiste à ACHETER, à LOUER ou à VENDRE \n"
				+ "  diverses propriétés de façon si profitable que l’on puisse devenir \n"
				+ "  le plus riche des joueurs et éventuellement, le GAGNANT");
		System.out.println("\n Entrez 1 pour Jouer.\n");
		while (save == 0) {
			save = sc.nextInt();
		}
		if (save == 1) {
			int tours = 0;
			int thune = 0;
			int joueurs = 0;
//			System.out.println(
//					"Bienvenue dans le Menu de MonopoLille:\n\nDans ce menu vous pouvez choisir le nombre de tours de la partie,\nla Thune par joueur et le nombre de joueurs.\n");
			while (tours <= 0) {
				System.out.println("Choisissez le nombre de tours\n");
				tours = sc.nextInt();
			}
			while (thune < 200  || thune >10000) {
				System.out.println("Choisissez combien de thune les joueurs auront au démarrage de la partie\n");
				thune = sc.nextInt();
			}
			while (joueurs <= 0 || joueurs > 4) {
				System.out.println("Choisissez le nombre de joueurs (max 4)");
				joueurs = sc.nextInt();
			}

//			Parametre partie = new Parametre(thune, tours, 1); // Ca sert à quoi ?

			System.out.println();
			System.out.println();
			System.out.println();

			Plateau p = new Plateau(joueurs, thune);
			Des des = new Des();
			Case caseactuelle;
			p.afficherTableau();
			boolean finished = false;
			sc.nextLine();

			while (finished == false) {
				for (int i = 0; i < joueurs; i++) {
					caseactuelle = p.getCase(p.getJoueur(i).getPosition());
					if (p.getJoueur(i).estPrisonnier()) {
						((Prison) caseactuelle).triggerEvent(p.getJoueur(i), sc); // MARCHE PAS
					} else {

						System.out.println("Joueur " + (i + 1) + ", Appuyez sur Entrée pour lancer les dés");
						sc.nextLine();
						des.lancerDe();
						p.getJoueur(i).setPosition(p.getJoueur(i).getPosition() + des.desTotal());
						System.out.println("Vous avez fait " + des.desTotal());
						caseactuelle = p.getCase(p.getJoueur(i).getPosition());

						p.afficherTableau();

						if (caseactuelle.estPiegee()) {
							System.out.println("Vous êtes tombé sur la case piégée !\n");
							p.getJoueur(i).setEstPrisonnier(true);
							caseactuelle.setEstPiegee(false);
						} else {

							if (caseactuelle.getClass().equals(new Aeroport().getClass())) {
								((Aeroport) caseactuelle).triggerEvent(p.getJoueur(i), sc, p);
								caseactuelle = p.getCase(p.getJoueur(i).getPosition());
							}
							if (caseactuelle.getClass().equals(new Carte().getClass())) {
								List<List<String>> texte = new ArrayList<>();
								List<Carte> cartes = new ArrayList<>();
								texte = Carte.lecture();
								cartes = Carte.creerCarte(texte);
								Carte.applicationEffets(p.getJoueur(i), cartes);
							}
							if (caseactuelle.getClass().equals(new Prison().getClass())) {
								((Prison) caseactuelle).triggerEvent(p.getJoueur(i), sc);
							}
							if (caseactuelle.getClass().equals(new ParcGratuit().getClass())) {
								System.out.println(
										"Parc Gratuit ! Vous obtenez " + ((ParcGratuit) caseactuelle).getSolde());
								p.getJoueur(i).setArgent(
										p.getJoueur(i).getArgent() + ((ParcGratuit) caseactuelle).videSolde());
							}
							if (caseactuelle.getClass().equals(new Piege().getClass())) {
								System.out.println("Choisissez la case que vous voulez piéger.");
								try {
									((Piege) caseactuelle).pieger(p.getCase(sc.nextInt()));
								} catch (Exception e) {
								}
							}
							if (caseactuelle.getClass().equals(new Gitan().getClass())) {
								((Gitan) caseactuelle).baisserLoyer(p.getJoueur(i), p, sc);
							}
							if (caseactuelle.getClass().equals(new Sncf().getClass())) {
								((Sncf) caseactuelle).triggerEvent(p.getJoueur(i));
							}
							if (caseactuelle.getClass().equals(new AllezEnPrison().getClass())) {
								((AllezEnPrison) caseactuelle).envoyerEnPrison(p.getJoueur(i));
							}
							if (caseactuelle.getClass().equals(new Propriete(null, null, 0).getClass())) {
								((Propriete) caseactuelle).triggerEvent(p.getJoueur(i), p.getJoueurs());
							}
						}

						if (p.getJoueur(i).getTours() >= tours || p.getJoueur(i).perdu()) {
							finished = true;
						}
					}
				}
			}
			sc.close();

			System.out.println();
			System.out.println();
			System.out.println();

			System.out.println("Fin de la partie !");
		}
	}
}