package tplt;

import java.util.Scanner;

public class Aeroport extends Case {

	public Aeroport() {
		super("Aeroport", "Aer.");
	}

	// permet de savoir si le joueur peut aller en avion sur une case et lui
	// rajoute de l'argent s'il passe par la case départ
	public void triggerEvent(Joueur j, Scanner sc, Plateau p) {
		if (j.getArgent() < 200) {
			System.out.println("Vous n'avez pas assez d'argent pour prendre l'avion.");
		} else {
			System.out.print("Voulez-vous utiliser l'avion pour 100$? (1=oui 2=non) ");
			int reponse = sc.nextInt();
			if (reponse == 1) {
				System.out.print("Sur quelle case souhaitez-vous aller?");
				int rep = sc.nextInt();
				while (rep == 27) {
					System.out.print("Vous ne pouvez pas aller là, choisissez une autre case.");
					rep = sc.nextInt();
				}
				Case c=p.getCase(18);
				if (rep > j.getPosition()) {
					j.setArgent(j.getArgent() - 100);
					((ParcGratuit) c).ajouteSolde(100);
				} else {
					j.setArgent(j.getArgent() + 100);
					j.setTours(j.getTours() + 1);
					((ParcGratuit) c).ajouteSolde(100);
				}
				j.setPosition(rep);
			}
		}
	}
}
