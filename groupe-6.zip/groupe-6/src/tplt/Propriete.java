package tplt;

import java.util.List;
import java.util.Scanner;

public class Propriete extends Case{
	private int prix;
	private int loyer;
	private boolean occupe;
	private int salePrice;
	
	public Propriete (String n, String grp, int p){
		super(n, grp);
		this.prix=p;
		this.loyer=p/6;
		this.occupe=false;
		this.salePrice = (int)(p*0.8);
	}

	public int getSalePrice() {
		return salePrice;
	}

	public void setSalePrice(int salePrice) {
		this.salePrice = salePrice;
	}

	public int getPrix() {
		return prix;
	}

	public void setPrix(int prix) {
		this.prix = prix;
	}

	public int getLoyer() {
		return loyer;
	}

	public void setLoyer(int loyer) {
		this.loyer = loyer;
	}

	public boolean isOccupe() {
		return occupe;
	}

	public void setOccupe(boolean occupe) {
		this.occupe = occupe;
	}
	public String remplir(int length) {
		String res = "";
		for(int i=0 ; i<length;i++) {
			res = res + " ";
		}
		return res;
	}
	public boolean afficherAchat(Joueur joueur){
		boolean res = false;
		int resInt = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
		System.out.println("┃                                                                        ┃");
		System.out.println("┃       Bonjour " + joueur.getNom()+ ","+ remplir(72-16-joueur.getNom().length())+ "┃");
		System.out.println("┃    Voulez vous acheter " + this.getNom() + remplir(72-24-this.getNom().length()) + "┃");
		System.out.println("┃    pour " + this.prix + "."+ remplir(72-10-String.valueOf(this.prix).length())+"┃");
		System.out.println("┃                                                                        ┃");
		System.out.println("┃" + "     1.Acheter" + remplir(72-14)+ "┃");
		System.out.println("┃" + "     2.Ne pas acheter" + remplir(72-21)+ "┃");
		System.out.println("┃                                                                        ┃");
		System.out.println("┃                                                                        ┃");
		System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
		while(resInt<=0) {
			resInt = sc.nextInt();
			while(resInt >2) {
				resInt = sc.nextInt();
			}
		}
		if(resInt == 1) {
			res = true;
		}
		if(res) {
			joueur.addProp(this);
		}
		return res;
	}
	public void triggerEvent(Joueur j, List<Joueur> joueurs) {
		if (this.isOccupe()) {
			Joueur proprio=new Joueur(0, null, '0');
			for (int i=0; i<joueurs.size();i++) {
				if (joueurs.get(i).getAchat().contains(this)){
					proprio=joueurs.get(i);
				}
			}
			if (j.equals(proprio)) {
				System.out.println("Vous êtes sur votre propriété.");
			}
			else {
				j.setArgent(j.getArgent()-this.loyer);
				proprio.setArgent(proprio.getArgent()+this.loyer);
				System.out.println("Vous avez donné " + this.getLoyer() + " au joueur "+proprio.getNom()+".");
			}
		} else {
			if (j.getArgent() >= this.getPrix()) {
				if (afficherAchat(j)) {
					this.setOccupe(true);
					System.out.println("Vous avez acheté " + this.getNom() + " du groupe " + this.getAbr());
				}
			} else {
				System.out.println("Vous n'avez pas assez d'argent pour acheter " + this.getNom());
			}
		}
	}
	
	
	public void afficherEchange(Joueur joueur, Plateau plateau) {
		int res = 0;
		Scanner sc = new Scanner(System.in);
		String pseudo = "";
		String ville1 = "";
		Propriete prop1 = null;
		String ville2 = "";
		Propriete prop2 = null;
		System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
		System.out.println("┃                                                                        ┃");
		System.out.println("┃       Bonjour " + (joueur.getNom()+ 1 )+ ","+ remplir(72-16-joueur.getNom().length())+ "┃");
		System.out.println("┃     Bienvenue dans le menu d'échange :"+ remplir(72-39) + "┃");
		System.out.println("┃     Avec qui voulez vous échanger, "+ remplir(72-36) + "┃");
		System.out.println("┃     voici la liste des joueurs avec leurs propriétées : "+ remplir(72-57) + "┃");
		System.out.println("┃                                                                        ┃");
		for(int i=0 ; i< plateau.getJoueurs().size() ; i++) {
			if(!plateau.getJoueur(i).equals(joueur)) {
				System.out.println("┃       " + plateau.getJoueurs().get(i).getNom() + " :" + remplir(72-9-plateau.getJoueur(i).getNom().length()) + "┃");
				for(int j=0 ; j <plateau.getJoueur(i).getAchat().size() ; j++) {
					System.out.println("┃         " + plateau.getJoueur(i).getAchat().get(j).getNom() + remplir(72-9-plateau.getJoueur(i).getAchat().get(j).getNom().length())+ "┃");
				}
			}
		}
		System.out.println("┃                                                                        ┃");
		System.out.println("┃     Voici la liste des Propriété que vous pouvez échanger :"+ remplir(74-62) + "┃");
		for(int i=0 ; i< joueur.getAchat().size() ; i++) {
			System.out.println("┃          "+ (i+1) + "." + joueur.getAchat().get(i).getNom() + remplir(72-12-joueur.getAchat().get(i).getNom().length()) + "┃");
		}
		System.out.println("┃                                                                        ┃");
		System.out.println("┃                                                                        ┃");
		System.out.println("┃     " + "Entrez le nom du Joueur avec qui vous voulez échanger" + "              ┃");
		System.out.println("┃                                                                        ┃");
		System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
		while(pseudo.equals("")) {
			pseudo = sc.nextLine();
			while(!plateau.getJoueurs().toString().contains(pseudo)) {
				pseudo = sc.nextLine();
			}
		}
		if(plateau.getJoueurs().toString().contains(pseudo)) {
			System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
			System.out.println("┃                                                                        ┃");
			System.out.println("┃     Vous avez choisi "+ pseudo + "." + remplir(72-23-pseudo.length()) +"┃");
			System.out.println("┃     Je vous remet ci dessous la liste de vos propriétées:              ┃");
			System.out.println("┃                                                                        ┃");
			System.out.println("┃         "+ pseudo + " :" + remplir(72-11-pseudo.length())+  "┃");
			for(int i=0 ; i<plateau.getJoueurs().get(Integer.parseInt(pseudo)).getAchat().size() ; i++){
				System.out.println("┃            "+ plateau.getJoueur(Integer.parseInt(pseudo)).getAchat().get(i).getNom() + remplir(72-12-plateau.getJoueur(Integer.parseInt(pseudo)).getAchat().get(i).getNom().length()) + "┃");
			}
			System.out.println("┃                                                                        ┃");
			System.out.println("┃         " + joueur.getNom() + " :" + remplir(72-11-joueur.getNom().length()) + "┃");
			for(int i=0 ; i<joueur.getAchat().size() ; i++) {
				System.out.println("┃            "+ joueur.getAchat().get(i).getNom() + remplir(72-12-joueur.getAchat().get(i).getNom().length()) + "┃");
			}
			System.out.println("┃                                                                        ┃");
			System.out.println("┃   Entrez le nom de la ville de l'autre joueur que vous voulez échanger" + " ┃");
			System.out.println("┃                                                                        ┃");
			System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
			while(ville1.equals("")) {
				ville1 = sc.nextLine();
				while(!plateau.getJoueur(Integer.parseInt(pseudo)).toStringAchat().contains(ville1)) {
					ville1 = sc.nextLine();
				}
			}
			if(plateau.getJoueur(Integer.parseInt(pseudo)).toStringAchat().contains(ville1)) {
				prop1 = findProp(findJoueur(plateau, pseudo), ville1);
				System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
				System.out.println("┃                                                                        ┃");
				System.out.println("┃     Vous avez choisi "+ ville1 + remplir(72-22- ville1.length()) +"┃");
				System.out.println("┃     choisissez votre ville à échanger :                                ┃");
				for(int i=0 ; i<joueur.getAchat().size() ; i++) {
					System.out.println("┃            "+ joueur.getAchat().get(i).getNom() + remplir(72-12-joueur.getAchat().get(i).getNom().length()) + "┃");
				}
				System.out.println("┃                                                                        ┃");
				System.out.println("┃   Entrez le nom de votre ville que vous voulez échanger                ┃");
				System.out.println("┃                                                                        ┃");
				System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
				while(ville2.equals("")) {
					ville2 = sc.nextLine();
					while(!joueur.toStringAchat().contains(ville2)) {
						ville2 = sc.nextLine();
					}
				}
				if(joueur.toStringAchat().contains(ville2)) {
					prop2 = findProp(joueur, ville2);
					System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
					System.out.println("┃                                                                        ┃");
					System.out.println("┃          Voici un récapitulatif de l'échange :                         ┃");
					System.out.println("┃     " + findJoueur(plateau, pseudo).getNom() + " propose " + prop1.getNom() + remplir(72-findJoueur(plateau, pseudo).getNom().length()-prop1.getNom().length()-14) + "┃");
					System.out.println("┃     contre " + prop2.getNom() + " pour " + joueur.getNom() + remplir(72 - prop2.getNom().length()-joueur.getNom().length()-18) + "┃");
					System.out.println("┃                                                                        ┃");
					System.out.println("┃     1.Accepter                                                         ┃");
					System.out.println("┃     2.Refuser                                                          ┃");
					System.out.println("┃                                                                        ┃");
					System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
					while(res <=0) {
						res = sc.nextInt();
						while(res > 2) {
							res = sc.nextInt();
						}
					}
					if(res == 1) {
						joueur.echange(findJoueur(plateau, pseudo), prop2, prop1);
					}
				}
			}
		}
	}
	public Propriete findProp(Joueur joueur, String nom) {
		Propriete res = null;
		if(joueur.toStringAchat().contains(nom)) {
			for(int i=0 ; i<joueur.getAchat().size(); i++) {
				if(joueur.getAchat().get(i).getNom().equals(nom)) {
					res = joueur.getAchat().get(i);
				}
			}
		}
		return res;
	}
	public Joueur findJoueur(Plateau plateau,String nom) {
		Joueur res = null;
		if(plateau.toStringJoueur().contains(nom)) {
			for(int i=0 ; i<plateau.getJoueurs().size(); i++) {
				if(plateau.getJoueurs().get(i).getNom().equals(nom)) {
					res = plateau.getJoueurs().get(i);
				}
			}
		}
		return res;
	}

	@Override
	public String toString() {
		return this.getNom();
	}
//	public static void main(String[] args) {
//		Propriete prop = new Propriete("Tourcoing", "", 12000, 0);
//		Propriete prop2 = new Propriete("Lille", "", 0, 0);
//		Propriete prop3 = new Propriete("Bordeaux", "", 0, 0);
//		Propriete prop4 = new Propriete("Toulouse", "", 0, 0);
//		Propriete prop5 = new Propriete("Roubaix", "", 0, 0);
//		Plateau plateau = new Plateau(4, 12000);
//		plateau.getJoueur(0).addProp(prop);
//		plateau.getJoueur(0).addProp(prop2);
//		plateau.getJoueur(1).addProp(prop3);
//		plateau.getJoueur(2).addProp(prop4);
//		plateau.getJoueur(3).addProp(prop5);
//		prop.afficherEchange(plateau.getJoueur(0),plateau);
//		
//		//prop.afficherAchat(j1);
//	}
}
