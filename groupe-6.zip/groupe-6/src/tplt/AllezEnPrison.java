package tplt;

public class AllezEnPrison extends Case {

	public AllezEnPrison() {
		super("Allez En Prison", "->Pri.");
	}

	public void envoyerEnPrison(Joueur j) {
		j.setEstPrisonnier(true);
	}
}
