package tplt;

public abstract class Case {
	private String nom;
	private String abr_grp; // GRAND MAX 6 CARACTERES
	private int indice;
	private boolean estPiegee;

	public Case(String nom, String abr_grp) {
		this.nom = nom;
		this.abr_grp = abr_grp;
		this.estPiegee = false;
	}

	public String getAbr() {
		return abr_grp;
	}

	public void setAbr(String abr) {
		this.abr_grp = abr;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getIndice() {
		return this.indice;
	}

	public void setIndice(int indice) {
		this.indice = indice;
	}

	public boolean estPiegee() {
		return estPiegee;
	}

	public void setEstPiegee(boolean estPiegee) {
		this.estPiegee = estPiegee;
	}
}
