package tplt;
public class Des {

    private int de1;
    private int de2;
    private int desTotal;
    private int nbDouble;


    //Constructeur par défaut
    public Des(){
        this.de1=0;
        this.de2=0;
        this.nbDouble=0;
    }
    
    public void lancerDe(){
        this.de1 = (int)(1 + Math.random() * 6);
        this.de2 = (int)(1 + Math.random() * 6);
        if( this.de1 == this.de2){
            this.nbDouble +=1;
        }
        else{
            this.nbDouble = 0;
        }
        this.desTotal = this.de1+this.de2;  
    }

    public boolean estDouble(){
        if( this.de1 == this.de2){
            return true;
        }
        else{
            return false;
        }
    }

    //GETTER
    public int de1(){
        return this.de1 ;}

    public int de2(){
        return this.de2 ;}

    public int nbDouble(){
        return this.nbDouble ;}

    public int desTotal(){
        return this.desTotal ;}


    //SETTER
    public int setde1(int de1){
        return this.de1 = de1;}

    public int de2(int de2){
        return this.de2 = de2;}

    public int nbDouble(int nbDouble){
        return this.nbDouble = nbDouble ;}

    public int desTotal(int desTotal){
        return this.desTotal = desTotal ;}
}
