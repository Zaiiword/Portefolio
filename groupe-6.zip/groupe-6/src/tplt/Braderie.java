package tplt;

public class Braderie extends Case{
	
	private int tourJoueur;
	private String NomJoueur;
	private int oldSalePrice;

	public Braderie() {
		super("Braderie", "Bra");
		this.NomJoueur = "";
		this.tourJoueur = 0;
	}
	
	public void TriggerEvent(Plateau p, Joueur j) { 
		System.out.println("La braderie commence : toutes les habitations sont maintenant à prix réduits !");
		Braderie.this.setNomJoueur(j.getNom());
		Braderie.this.setTourJoueur(j.getTours());
		for(int i = 0 ;  i < p.getNbCases();i++) {
			if(p.getCase(i).getClass().equals(new Propriete(null, null, 0).getClass())) {
				((Propriete) p.getCase(i)).setSalePrice((int)(((Propriete) p.getCase(i)).getSalePrice()*0.75)); 
				Braderie.this.setOldSalePrice((int)(((Propriete) p.getCase(i)).getSalePrice()));
			}
		}
	}
	
	public int getOldSalePrice() {
		return oldSalePrice;
	}

	public void setOldSalePrice(int oldSalePrice) {
		this.oldSalePrice = oldSalePrice;
	}

	public String getNomJoueur() {
		return NomJoueur;
	}

	public void setNomJoueur(String nomJoueur) {
		NomJoueur = nomJoueur;
	}

	public int getTourJoueur() {
		return tourJoueur;
	}

	public void setTourJoueur(int tourJoueur) {
		this.tourJoueur = tourJoueur;
	}
	
	

}