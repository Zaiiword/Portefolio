package tplt;

public enum Batiment {
	APPARTEMENT(1.5),MAISON(2),HOTEL(3);
	
	private double multiplicateur;
	
	 Batiment(double multiplicateur) {
		this.multiplicateur = multiplicateur;
	}

	public double getMultiplicateur() {
		return multiplicateur;
	}
	 
	 
}
