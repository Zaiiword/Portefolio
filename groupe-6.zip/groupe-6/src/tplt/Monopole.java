package tplt;


public class Monopole {
    
    //Attribut
    private int multiplicateur;
    private int groupe;

    public Monopole(int groupe){
        this.multiplicateur = 2;
        this.groupe = groupe;
    }

    public boolean estMonopole(Plateau p,Joueur j){
        int nombreCaseMono = 0;
        int nombreCaseJoueur = 0;
        //on regarde il y a combien de case dans le monopole
        for(int i=0;i<p.getTableau().size();i++){
            if(p.getCase(i).getAbr() == p.getCase(groupe).getAbr()){
                nombreCaseMono ++ ;
            }
        }
        //et on regarde si le joueur à le même nombre de case
        for(int u=0;u<j.getAchat().size();u++){
            if (j.getAchat().get(u).getAbr() == p.getCase(groupe).getAbr()){
                nombreCaseJoueur ++;
            }
        }
        if(nombreCaseJoueur == nombreCaseMono){
            return true;
        }
        else{
            return false;
        }
    }


    //GETTER
    public double getMultiplicateur(){
        return this.multiplicateur;
    }
    public int getGroupe(){
        return this.groupe;
    }
}
