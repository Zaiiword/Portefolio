package tplt;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Plateau {
	private final int NBCASES;
	private final int NBJOUEURS;
	private List<Case> cases; // Plateau réel
	private List<Joueur> joueurs;
	private List<List<List<String>>> printableMap;

	public Plateau(int nbJoueurs, int thune) {
		NBCASES = 36;
		this.cases = new ArrayList<Case>(NBCASES);
		this.joueurs = new ArrayList<Joueur>();
		for (int i = 0; i < nbJoueurs; i++) {
			joueurs.add(new Joueur(thune, "" + i, (char) (i + '1')));
		}
		NBJOUEURS = nbJoueurs;
		this.initialiserCases();
	}

	private List<List<List<String>>> initialiserPlateau() {
		List<List<List<String>>> printableMap = new ArrayList<List<List<String>>>();

//		List<String> printableCase = new ArrayList<String>(Arrays.asList("┌─────┐", "│     │", "│     │", "└─────┘"));

		List<String> emptyCase = new ArrayList<String>(Arrays.asList("       ", "       ", "       ", "       "));

		for (int i = 0; i < 10; i++) {
			printableMap.add(new ArrayList<List<String>>());
			for (int j = 0; j < 10; j++) {

				printableMap.get(i).add(emptyCase);
			}
		}

		for (int i = 0; i < 10; i++) {
			printableMap.get(0).set(i, new ArrayList<String>(Arrays.asList(i + "─────┐", "│     │", "│     │",
					"└─────┘".substring(0, 7 - this.getCase(i).getAbr().length()) + this.getCase(i).getAbr())));
		}
		printableMap.get(0).set(0, new ArrayList<String>(Arrays.asList("0─────┐", "│     │", "│     │", "└Départ")));
		printableMap.get(0).set(9, new ArrayList<String>(Arrays.asList("9─────┐", "│     │", "│     │", "└Prison")));
		for (int i = 1; i < 9; i++) {
			printableMap.get(i).set(0,
					new ArrayList<String>(Arrays.asList((36 - i) % 36 + "────┐", "│     │", "│     │",
							"└─────┘".substring(0, 7 - this.getCase((36 - i) % 36).getAbr().length())
									+ this.getCase((36 - i) % 36).getAbr())));
			printableMap.get(i).set(9,
					new ArrayList<String>(Arrays.asList(i + 9 + "────┐", "│     │", "│     │",
							"└─────┘".substring(0, 7 - this.getCase(i + 9).getAbr().length())
									+ this.getCase(i + 9).getAbr())));
		}
		for (int i = 0; i < 10; i++) {
			printableMap.get(9).set(i, new ArrayList<String>(Arrays.asList(27 - i + "────┐", "│     │", "│     │",
					"└─────┘".substring(0, 7 - this.getCase(27 - i).getAbr().length()) + this.getCase(27 - i).getAbr())));
		}

		return printableMap;
	}

	private void initialiserCases() {

		// A MODIFIER
		Case caseVide = new Case("", "") {};

		// Départ
		Case c0 = new Case("Départ", "Départ") {};

		// Groupe 1
		Case c1 = new Propriete("Rue Nationale", "Mauve", 70);
		Case c2 = new Propriete("Rue Saint André", "Mauve", 80);

		// ?
		Case c3 = new Piege();
		Case c4 = new Carte();
		Case c5 = caseVide;

		// Groupe 2
		Case c6 = new Propriete("Boulevard des Cités Unies", "Cyan", 100);
		Case c7 = new Propriete("Place Rihour", "Cyan", 100);
		Case c8 = new Propriete("Rue Masséna", "Cyan", 120);

		// Prison
		Case c9 = new Prison();

		// Groupe 3
		Case c10 = new Propriete("Avenue du Peuple Belge", "Violet", 140);
		Case c11 = new Propriete("Rue Léon Gambetta", "Violet", 150);
		Case c12 = new Propriete("Place Déliot", "Violet", 160);

		// ?
		Case c13 = new Carte();
		Case c14 = caseVide;

		// Groupe 4
		Case c15 = new Propriete("Rue de la Monnaie", "Orange", 170);
		Case c16 = new Propriete("Rue Esquermoise", "Orange", 190);
		Case c17 = new Propriete("Rue de Wazemmes", "Orange", 200);

		// Parc Gratuit
		Case c18 = new ParcGratuit();

		// Groupe 5
		Case c19 = new Propriete("Place du Général De Gaulle", "Rouge", 200);
		Case c20 = new Propriete("Nouveau Siècle", "Rouge", 220);
		Case c21 = new Propriete("Rue de la Grande Chaussée", "Rouge", 220);

		// ?
		Case c22 = new Carte();
		Case c23 = new Gitan();

		// Groupe 6
		Case c24 = new Propriete("Vieille bourse", "Jaune", 240);
		Case c25 = new Propriete("Rue Degand", "Jaune", 280);
		Case c26 = new Propriete("Boulevard de la Liberté", "Jaune", 280);

		// Aéroport
		Case c27 = new Aeroport();

		// Groupe 7
		Case c28 = new Propriete("Rue Faidherbe", "Vert", 300);
		Case c29 = new Propriete("Place Louise De Bettignes", "Vert", 350);
		Case c30 = new Propriete("Place Sébastopol", "Vert", 360);

		// ?
		Case c31 = new Carte();
		Case c32 = new Sncf();
		Case c33 = new AllezEnPrison();

		// Groupe 8
		Case c34 = new Propriete("Boulevard Vauban", "Bleu", 500);
		Case c35 = new Propriete("Boulevard Jean-Baptiste Lebas", "Bleu", 550);

		this.cases.addAll(Arrays.asList(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14, c15, c16, c17,
				c18, c19, c20, c21, c22, c23, c24, c25, c26, c27, c28, c29, c30, c31, c32, c33, c34, c35));
	}

	public List<Case> getTableau() {
		return this.cases;
	}

	public void afficherTableau() {
		// ─│┌┐└┘├┤┬┴┼ = caractères utilisables pour la map
		this.printableMap = initialiserPlateau();
		int posJoueur;
		String tmpstr;
		for (int i = 0; i < NBJOUEURS; i++) {
			posJoueur = this.joueurs.get(i).getPosition();
			if (posJoueur < 10) {
				tmpstr = printableMap.get(0).get(posJoueur).get(1).substring(0, i + 1) + "" + (char) (i + '1')
						+ printableMap.get(0).get(posJoueur).get(1).substring(i + 2, 7);
				printableMap.get(0).get(posJoueur).set(1, tmpstr);
			} else if (posJoueur < 18) {
				tmpstr = printableMap.get(posJoueur % 9).get(9).get(1).substring(0, i + 1) + "" + (char) (i + '1')
						+ printableMap.get(posJoueur % 9).get(9).get(1).substring(i + 2, 7);
				printableMap.get(posJoueur % 9).get(9).set(1, tmpstr);
			} else if (posJoueur < 28) {
				tmpstr = printableMap.get(9).get(10 - (posJoueur - 17)).get(1).substring(0, i + 1) + ""
						+ (char) (i + '1') + printableMap.get(9).get(10 - (posJoueur - 17)).get(1).substring(i + 2, 7);
				printableMap.get(9).get(10 - (posJoueur - 17)).set(1, tmpstr);
			} else {
				tmpstr = printableMap.get(9 - posJoueur % 9).get(0).get(1).substring(0, i + 1) + "" + (char) (i + '1')
						+ printableMap.get(9 - posJoueur % 9).get(0).get(1).substring(i + 2, 7);
				printableMap.get(9 - posJoueur % 9).get(0).set(1, tmpstr);
			}
		}

		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 4; j++) {
				for (int k = 0; k < 10; k++) {
					System.out.print(printableMap.get(i).get(k).get(j));
				}
				if (i < NBJOUEURS && j == 1) {
					System.out.print("     Joueur " + (i+1) +" : " + this.getJoueur(i).getArgent() + "$");
				}
				System.out.println();
			}
		}
	}

	public Joueur getJoueur(int j) {
		return joueurs.get(j);
	}

	public void setJoueur(int indice, Joueur j) {
		this.joueurs.set(indice, j);
	}

	public Case getCase(int i) {
		return this.cases.get(i);
	}

	public List<Joueur> getJoueurs() {
		return joueurs;
	}

	public void setJoueurs(List<Joueur> joueurs) {
		this.joueurs = joueurs;
	}
	public void addJoueur(Joueur joueur) {
		this.joueurs.add(joueur);
	}

	public String toStringJoueur() {
		String res = "";
		for(int i=0 ; i<this.joueurs.size() ; i++) {
			res = res + " " + this.joueurs.get(i);
		}
		return res;
	}

	public int getNbCases() {
		// TODO Auto-generated method stub
		return NBCASES;
	}
}
