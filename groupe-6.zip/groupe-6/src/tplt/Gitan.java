package tplt;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Gitan extends Case {

	public Gitan() {
		super("Gitans", "Gitan");
	}

	public List<Propriete> getPropOccupe(Joueur joueur, Plateau plateau) {
		List<Propriete> res = new ArrayList<Propriete>();
		for (int i = 0; i < plateau.getJoueurs().size(); i++) {
			if (!plateau.getJoueur(i).equals(joueur)) {
				for (int j = 0; j < plateau.getJoueur(i).getAchat().size(); j++) {
					if (plateau.getJoueur(i).getAchat().get(j).isOccupe()) {
						res.add(plateau.getJoueur(i).getAchat().get(j));
					}
				}
			}
		}
		return res;
	}

	public void baisserLoyer(Joueur j1, Plateau p, Scanner sc) {
		if (getPropOccupe(j1, p).size() == 0) {
			System.out
					.println("Il n'y a pas de propriété achetée et vous ne pouvez donc pas encore envoyer les gitans.");
		} else {
			for (int i = 0; i < getPropOccupe(j1, p).size(); i++) {
				System.out.println("\t" + i + " : " + getPropOccupe(j1, p).get(i));
			}
			System.out.println("Entrez l'indice correspondant à la propriété où vous voulez envoyer les gitans.");
			int reponse;
			do {
				reponse = sc.nextInt();
			} while (reponse < 0 || reponse > getPropOccupe(j1, p).size());

			getPropOccupe(j1, p).get(reponse).setLoyer(getPropOccupe(j1, p).get(reponse).getLoyer()/2);

			System.out.println("Le loyer de " + getPropOccupe(j1, p).get(reponse) + " est maintenant divisé par 2 !");

		}
	}

}
