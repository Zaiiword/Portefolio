package tplt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Joueur{
	private int argent;
	private String nom;
	private char pion;
	private ArrayList<Propriete> achat;
	private int tours;
	private int position;
	private boolean prisonnier;
	
	public Joueur(int argent, String nom, char pion) {
		this.argent = argent;
		this.nom = nom;
		this.pion = pion;
		this.tours =0;
		this.achat = new ArrayList<Propriete>();
		this.position=0;
		this.prisonnier = false;
	}

	public boolean estPrisonnier() {
		return prisonnier;
	}

	public void setEstPrisonnier(boolean estPrisonnier) {
		this.prisonnier = estPrisonnier;
		this.setPosition(9);
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		if (position > 35) {
			this.tours++;
			this.argent+=200;
		}
		this.position = position % 36;
	}

	public int getArgent() {
		return argent;
	}

	public void setArgent(int argent) {
		this.argent = argent;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public char getPion() {
		return pion;
	}

	public void setPion(char pion) {
		this.pion = pion;
	}

	public ArrayList<Propriete> getAchat() {
		return achat;
	}

	public void setAchat(ArrayList<Propriete> achat) {
		this.achat = achat;
	}

	public int getTours() {
		return tours;
	}

	public void setTours(int tours) {
		this.tours = tours;
	}
	public boolean faillite(Propriete prop) {
		boolean res = false;
		if((this.argent - prop.getLoyer())<0) {
			res = true;
		}
		return res;
	}
	public boolean addProp(Propriete propriete) {
		boolean res = false;
		if(propriete.isOccupe() == false) {
			this.argent = this.argent - propriete.getPrix();
			this.achat.add(0,propriete);
			propriete.setOccupe(true);
			res = true;
		}
		return res;
	}
	public void vendre() {
		int vente = 0;
		Scanner sc = new Scanner(System.in);
		while(vente >-1) {
			System.out.println("voici la liste de vos propriétées avec leur prix de ventes.\n");
			for(int i=0 ; i<this.achat.size() ; i++) {
				System.out.println(i+1 + "."+this.achat.get(i).getNom()+ " = " + this.achat.get(i).getSalePrice()+ "\n");
			}
			System.out.println("entrez le numéro de la propriété que vous voulez vendre ou entrez -1 si vous ne voulez plus vendre.\n");
			vente = sc.nextInt();
			this.argent = this.argent + this.achat.get(vente-1).getSalePrice();
			this.achat.get(vente-1).setOccupe(false);
			this.achat.remove(vente-1);
		}
	}
	public boolean perdu() {
		boolean res = false;
		int valeurImmo = 0;
		for(int i=0 ; i<this.achat.size() ; i++) {
			valeurImmo = valeurImmo + this.achat.get(i).getSalePrice();
		}
		if((this.argent + valeurImmo)<0) {
			res = true;
		}
		return res;
	}
	public String toStringAchat() {
		String res = "";
		for(int i=0 ; i<this.achat.size() ; i++) {
			res = res +" " + this.achat.get(i).getNom();
		}
		return res;
	}

	//il faut que la propriété à échanger appartienne au joueur choisi
	public void echange(Joueur joueur, Propriete pDemandeur , Propriete pReceveur) {
		Propriete save1 = null;
		Propriete save2 = null;
		if(joueur.achat.contains(pReceveur)) {
			save1 = pReceveur;
			save2 = pDemandeur;
			/*joueur.argent = joueur.argent + montant;
			this.argent = this.argent - montant;*/
			joueur.achat.remove(pReceveur);
			joueur.achat.add(save2);
			this.achat.remove(pDemandeur);
			this.achat.add(save1);
		}
	}
	public void carteGainArgent(Carte c) {
		this.argent = this.argent + c.getEffet();
	}

	public boolean estSurCase(Case c) {
		return this.position == c.getIndice();
	}
	
//	public static void main(String[] args) {
//		Joueur j1 = new Joueur(12000, "noe",'a');
//		Propriete prop1 = new Propriete("Lille", "Lille", 12000, 120);
//		Propriete p2 =  new Propriete("Strasbourg", "Strasbourg", 11000, 110);
//		j1.addProp(prop1);
//		j1.addProp(p2);
//		j1.vendre();
//	}
}
