package tplt;

import java.util.Scanner;

public class Prison extends Case {

	// Constructeur
	public Prison() {
		super("Prison", "Prison");
	}

	public boolean faireSortir(Joueur joueur, Scanner scanner) {
		if (joueur.getArgent() >= 200) {

			System.out.print("Voulez-vous payer 200$ pour sortir de prison? (1=oui 2=non) \n");
			int rep = scanner.nextInt();

			if (rep == 1) {
				joueur.setArgent(joueur.getArgent() - 200);
				joueur.setEstPrisonnier(false);
				return true;
			}
		} else {
			System.out.println("Vous n'avez pas assez d'argent pour payer la sortie de prison.\n");
		}
		System.out.println("Il vous faut faire un double pour sortir de prison.\nLancez les dés.");
		scanner.nextLine();
		Des des = new Des();
		des.lancerDe();
		System.out.println("Vous avez fait " + des.de1() + " et " + des.de2() + ".");
		if (des.estDouble()) {
			System.out.println("Vous pouvez donc sortir de la prison.");
			joueur.setEstPrisonnier(false);
			return true;
		}
		System.out.println("Vous ne pouvez donc pas sortir de la prison.");
		return false;
	}
	
	public void triggerEvent(Joueur j, Scanner sc) {
		if (j.estPrisonnier()) {
			faireSortir(j, sc);
		} else {
			System.out.println("Vous êtes en visite de la prison.\n");
		}
	}

//	public static void main(String[] args) {
//		Prison p = new Prison();
//		Joueur j = new Joueur(20, "clement", 'h');
//		Des d = new Des();
//		d.lancerDe();
//		p.faireSortir(j);
//	}

}
