package tplt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Carte extends Case {
	private String type;
	private String phrase;
	private int effet;
	private int ref;
	
	public Carte(String type, String phrase, int effet, int ref) {
		super(type, "Chance");
		this.type = type;
		this.phrase = phrase;
		this.effet = effet;
		this.ref = ref;
		
	}

	public Carte() {
		this("type", "phrase", 0, 0);
//		this.type = "type";
//		this.phrase = "phrase";
//		this.effet = 0;
//		this.ref = 0;
		
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPhrase() {
		return phrase;
	}

	public void setPhrase(String phrase) {
		this.phrase = phrase;
	}

	public int getEffet() {
		return effet;
	}

	public void setEffet(int effet) {
		this.effet = effet;
	}
	
	public int getRef() {
		return ref;
	}

	public void setRef(int ref) {
		this.ref = ref;
	}
	
	
	public void effetGainArgent(Joueur j) {
		j.setArgent((j.getArgent() + this.effet));
	}

	public void effetPerteArgent(Joueur j) {
		j.setArgent((j.getArgent() - this.effet));
	}
	
	
	public void effetAvancer(Joueur j) {
		j.setPosition(j.getPosition() + this.getEffet());
	}
	
	public void effetPrisonParc(Joueur j){
		j.setPosition(this.getEffet());
		j.setEstPrisonnier(true);
	}
	
	

	public static Carte tirage(List<Carte> listCarte) {
		int rand = (int)(Math.random()*17)+1;
		System.out.println(listCarte.get(rand).phrase);
		return listCarte.get(rand);
	}
	
	public static void applicationEffets(Joueur j,List<Carte> listCarte) {
		Carte c = tirage(listCarte);
		if(c.getRef() == 1) {
		c.effetGainArgent(j);
		}else if(c.getRef() == 2) {
			c.effetPerteArgent(j);
		}else if(c.getRef() == 3 || c.getRef() == 4) {
			c.effetPrisonParc(j);
		}else {
			c.effetAvancer(j);
		}
	}
	
	
	public static List<List<String>> lecture(){
	
	List<List<String>> texte = new ArrayList<>();
	String fileS = System.getProperty("user.dir") + "/csv/tplt/Carte.csv";
	//File f = new File(Carte.class.getClass().getResource("Carte.csv").toExternalForm());
	File f = new File(fileS);
	try (BufferedReader br = new BufferedReader(new FileReader(f))){
		String ligne;
		
		while((ligne = br.readLine()) != null) {
			String [] valeurs = ligne.split(",");
			texte.add(Arrays.asList(valeurs));
		}
	}catch(IOException ex) {
		ex.printStackTrace();
	}
	
	return texte;
	}
	
	public static List<Carte> cartes = new ArrayList<>();
	
	
	public static List<Carte> creerCarte(List<List<String>> texte){
		for(int i = 0;i<texte.size(); i++) {
			
			Carte c = new Carte(texte.get(i).get(0),texte.get(i).get(1),Integer.valueOf(texte.get(i).get(2)),Integer.valueOf(texte.get(i).get(3)));
			cartes.add(c);		
		}
		return cartes;
	}
	
	@Override
	public String toString() {
		return "Carte [type=" + type + ", phrase=" + phrase + ", effet=" + effet + ", ref=" + ref + "]";
	}
	
//	public static void main(String[] args) {
//		List<List<String>> texte = lecture();
//		List<Carte> cartes = creerCarte(texte);
//		
//		for(int i=0;i<cartes.size();i++) {
//			System.out.println(cartes.get(i));
//		}
//	}

	

}
