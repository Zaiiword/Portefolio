package tplt;

import java.util.Scanner;

public class Parametre {
	private int thune;
	private int nbTours;
	private int nbJoueurs;
	
	public Parametre(int thune, int nbTours, int nbJoueurs) {
		this.thune = thune;
		this.nbTours = nbTours;
		this.nbJoueurs = nbJoueurs;
	}
	public int getNbJoueurs() {
		return nbJoueurs;
	}
	public void setNbJoueurs(int nbJoueurs) {
		this.nbJoueurs = nbJoueurs;
	}
	public int getThune() {
		return thune;
	}

	public void setThune(int thune) {
		this.thune = thune;
	}

	public int getNbTours() {
		return nbTours;
	}

	public void setNbTours(int nbTours) {
		this.nbTours = nbTours;
	}
}
