import annuaire,personne
import VueAnnuaire as vueAnnuaire
import VuePersonne


class Controller:
    # constructor
    def __init__(self) -> None:
        # attributs
        self.modele = annuaire.Annuaire('annuaire.json')
        self.vue = vueAnnuaire.VueAnnuaire()
        p = self.modele.getPersonne()


        if isinstance(p, personne.Personne): self.vue.updatePersonne(p)
        # slots ie callback
        self.vue.nextClicked.connect(self.next)
        self.vue.previousClicked.connect(self.previous)
        self.vue.openFileClicked.connect(self.openFile)
        self.vue.newClicked.connect(self.new)
        self.vue.personneChanged.connect(self.update)
        self.vue.saveAsClicked.connect(self.saveAs)



    def update(self) -> None :
        self.modele.update(self.modele.getPersonne())  # type: ignore
        
    def next(self) -> None:
        self.modele.next()
        self.vue.updatePersonne(self.modele.getPersonne())  # type: ignore
         
    def previous(self) -> None:
        self.modele.previous()
        self.vue.updatePersonne(self.modele.getPersonne())   # type: ignore

    def new(self) -> None:
        self.modele.previous()
    def openFile(self, fname : str) -> None:
        self.modele.open(fname)
    def saveAs(self, fname: str) -> None:
        self.modele.save(fname)
        

if __name__ == "__main__":
    import sys
    from PyQt6.QtWidgets import QApplication
    def cbPrint(d): print(d)
    print("hello")
    app = QApplication(sys.argv)
    vue  = Controller()
    vue.vue.personneChanged.connect(cbPrint)
    sys.exit(app.exec())    
