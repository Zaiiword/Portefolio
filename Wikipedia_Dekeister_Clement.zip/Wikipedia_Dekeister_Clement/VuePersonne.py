import datetime, genre as g
from this import d
from PyQt6.QtWidgets import QWidget, QLabel, QLineEdit,QDateEdit,QComboBox,QTextEdit,QVBoxLayout,QHBoxLayout
from PyQt6.QtCore import QDate
from PyQt6.QtCore import pyqtSignal
from typing import Union

from personne import Personne


class VuePersonne(QWidget):
    # signal
    personneChanged : pyqtSignal = pyqtSignal(dict)
    # constructor

    def __init__(self):
        super().__init__()
        
        self.topLayout : QVBoxLayout = QVBoxLayout()
        self.middleLayout : QHBoxLayout = QHBoxLayout()
        self.leftLayout : QHBoxLayout = QHBoxLayout()

        #---- containeur 
        self.leftWidget : QWidget = QWidget()
        self.middleWidget : QWidget = QWidget()

        #associé le layout à la fenetre
        self.setLayout(self.topLayout)

        self.topLayout.addWidget(self.leftWidget, 25)
        self.topLayout.addWidget(self.middleWidget, 25)

        self.leftWidget.setLayout(self.leftLayout)
        self.middleWidget.setLayout(self.middleLayout)

        self.genre : QComboBox = QComboBox()
        self.genre.addItems(["M. ", "Mme ", "_ "])
        self.prenom : QLineEdit = QLineEdit("Prénom")
        self.nom : QLineEdit = QLineEdit("Nom")
        self.dateNaissance : QDateEdit = QDateEdit()
        self.dateNaiss : QLabel = QLabel("Né le:")
        self.dateNaissance.setDateRange(QDate(1,1,1),QDate.currentDate())
        self.dateMort : QDateEdit = QDateEdit() 
        self.mort : QLabel = QLabel("Mort le:")
        self.dateMort.setDateRange(QDate(1,1,1),QDate.currentDate())
        self.bio : QTextEdit = QTextEdit('"biographie"')

        #on ajoute les widgets sur leur layout
        self.leftLayout.addWidget(self.genre)
        self.leftLayout.addWidget(self.prenom)
        self.leftLayout.addWidget(self.nom)
        self.middleLayout.addWidget(self.dateNaiss)
        self.middleLayout.addWidget(self.dateNaissance,5)
        self.middleLayout.addWidget(self.mort)
        self.middleLayout.addWidget(self.dateMort,5)
        self.topLayout.addWidget(self.bio)

        self.show()
        
        self.genre.currentIndexChanged.connect(self.changeGenre)
        self.prenom.editingFinished.connect(self.changePrenom)
        self.nom.editingFinished.connect(self.changeNom)
        self.bio.textChanged.connect(self.changeBiographie)
        self.dateNaissance.dateChanged.connect(self.changeNaissance)
        self.dateMort.dateChanged.connect(self.changeMort)

    def updatePersonne(self, p:Personne) -> None:
        self.prenom.setText(p.prenom    )
        self.nom.setText(p.nom)
        self.genre.setCurrentIndex(p.genre.value-1) 
        self.dateNaissance.setDate(p.naissance)
        if p.mort:
            self.dateMort.setDate(p.mort)
        print(p.bio)
        self.bio.setPlainText(p.bio)
        
    # callback

    def changeGenre(self) -> None :
        self.personneChanged.emit(self.getAllInfo())
    def changePrenom(self) -> None : 
        self.personneChanged.emit(self.getAllInfo())
    def changeNom(self) -> None : 
        self.personneChanged.emit(self.getAllInfo())
    def changeNaissance(self) -> None : 
        self.personneChanged.emit(self.getAllInfo())
    def changeMort(self) -> None :
        self.personneChanged.emit(self.getAllInfo())
    def changeBiographie(self) -> None :
        self.personneChanged.emit(self.getAllInfo())
    def getAllInfo(self) -> dict: 
        d={}
        d['genre'] = str(g.Genre(1+self.genre.currentIndex()).name)
        d['prenom']=self.prenom.text()
        d['nom']=self.nom.text()
        d['naissance']=str(self.dateNaissance.date().toPyDate())
        d['mort']=str(self.dateMort.date().toPyDate())
        d['biographie']=self.bio.toPlainText()
        print(self.bio.toPlainText())
        return d


if __name__ == "__main__":
    import sys
    from PyQt6.QtWidgets import QApplication
    def cbPrint(d): print(d)
    print("hello")
    app = QApplication(sys.argv)
    vue  =VuePersonne()
    vue.personneChanged.connect(cbPrint)
    sys.exit(app.exec())    
