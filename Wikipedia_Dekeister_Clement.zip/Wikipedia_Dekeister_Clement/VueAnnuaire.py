from PyQt6.QtWidgets import QWidget, QLabel, QLineEdit,QDateEdit,QComboBox,QTextEdit,QVBoxLayout,QHBoxLayout
from PyQt6.QtCore import pyqtSignal
from typing import Dict, Union
from PyQt6.QtWidgets import QPushButton
from PyQt6.QtWidgets import QFileDialog

from VuePersonne import VuePersonne
from personne import Personne

class VueAnnuaire(QWidget):
    # signal
    nextClicked = pyqtSignal()
    previousClicked = pyqtSignal()
    openFileClicked = pyqtSignal(str)
    newClicked = pyqtSignal()
    personneChanged = pyqtSignal(dict)
    saveAsClicked =pyqtSignal(str)

    def __init__(self):
        super().__init__()

        self.topLayout : QVBoxLayout = QVBoxLayout() ; self.setLayout(self.topLayout)
        self.vuePersonne : VuePersonne = VuePersonne(); self.topLayout.addWidget(self.vuePersonne)

        self.cNav : QWidget = QWidget()
        self.lNav : QHBoxLayout = QHBoxLayout() ; self.cNav.setLayout(self.lNav)
        self.topLayout.addWidget(self.cNav)

        #création des boutons
        self.previous : QPushButton = QPushButton('<< précedent')   
        self.load : QPushButton = QPushButton('load')
        self.new : QPushButton = QPushButton('new ')     
        self.save_as : QPushButton = QPushButton('save as')
        self.next : QPushButton = QPushButton('suivant >>')   
        
        #ajout des boutons  sur le layout
        self.lNav.addWidget(self.previous)
        self.lNav.addWidget(self.load)
        self.lNav.addWidget(self.new)
        self.lNav.addWidget(self.save_as)
        self.lNav.addWidget(self.next)

        self.show()

        #dit ce qu'il faut faire quand un bouton est cliqué 
        self.next.clicked.connect(self.cbNext)
        self.load.clicked.connect(self.cbLoad)
        self.new.clicked.connect(self.cbNew)
        self.save_as.clicked.connect(self.cbSaveAs)
        self.vuePersonne.personneChanged.connect(self.personnechanged)
        self.previous.clicked.connect(self.cbPrevious)
        

    def cbNext(self):
        print('-- next')
        self.nextClicked.emit()

    def cbLoad(self):
        print('-- load')
        filename = QFileDialog().getOpenFileName(filter="*.json")[0]
        print(filename)
        self.openFileClicked.emit(filename)

    def cbNew(self):
        print('-- new')
        self.newClicked.emit()
    
    def cbSaveAs(self):
        print('-- save as')
        filename = QFileDialog().getSaveFileName(filter="*.json")[0]
        print(filename)
        self.saveAsClicked.emit(filename)

    def cbPrevious(self):
        print('-- previous')
        self.previousClicked.emit()

    def personnechanged(self):
        print(self.vuePersonne.getAllInfo())
        self.personneChanged.emit(self.vuePersonne.getAllInfo())

    def updatePersonne(self,p:Personne) ->None :
        self.vuePersonne.updatePersonne(p)

if __name__ == "__main__":
    import sys
    from PyQt6.QtWidgets import QApplication

    app : QApplication = QApplication(sys.argv)

    test : VueAnnuaire = VueAnnuaire()

    sys.exit(app.exec())
