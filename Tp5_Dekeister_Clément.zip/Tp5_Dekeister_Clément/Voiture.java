class Voiture{
    // Une voiture est ici décrite par 2 attributs :
    // - sa marque sous forme d'une chaine de caractères (classe String).
    // - son kilometrage (un entier).
    private String marque;
    private int kilometrage;


    // Constrcuteur par défaut qui crée une Renault neuve (avec 0km).
    public Voiture(){
	this.marque = new String("Renault");
	this.kilometrage = 0;
    }


    // Constructeur permettant de personnalisé totalement la voiture.
    public Voiture(String marque, int kilometrage){
	this.marque = new String(marque);
	this.kilometrage = kilometrage;
    }


    // Accesseur au nombre de kilomètre de la voiture.
    public int getKilometrage(){
	return this.kilometrage;
    }


    // Pour afficher une description de la voiture.
    public String toString(){
	return new String("Voiture "+ this.marque + " de " + this.kilometrage + "km");
    }

    //méthode pour comparer les voiture
    public boolean equals(Object obj) {
        Object objet = new Object(obj);
        if (objet == this) return true;
        return false;
    }
}
