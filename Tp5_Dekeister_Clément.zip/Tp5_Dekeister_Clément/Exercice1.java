import java.util.Random;

class Exercice1 {
    public static void main(String[] args) {
        int k= 20;
        int tab [] =new int[k]  ;
        for (int i=0; i<20;i++) {
            Random random = new Random();
            int nb ;
            nb = random.nextInt(10);
            tab[i]=nb;
            System.out.print(tab[i]+"|");
            
        }
        
    }
    
}
