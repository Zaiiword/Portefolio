import java.util.Random;
class Exercice2 {
    public static void main(String[] args) {
        int k= 20;
        int tab [] =new int[k]  ;
        for (int i=0; i<20;i++) {
            Random random = new Random();
            int nb ;
            nb = random.nextInt(10);
            tab[i]=nb;
        }
        int compteur= 0;
        int temporaire;
        while(compteur<20){
            for (int i=0; i<19;i++) {
                if(tab[i]>tab[i+1]){
                    temporaire= tab[i];
                    tab[i]=tab[i+1];
                    tab[i+1]=temporaire;
                }
            }
            compteur ++ ;
        }
        for (int i=0; i<19;i++) {
        System.out.print(tab[i]+"|");
        }

    }
}
