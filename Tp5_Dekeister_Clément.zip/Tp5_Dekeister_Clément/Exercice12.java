import java.util.ArrayList;
class Exercice12 {
    public static void main(String[] args) {
        ArrayList<Voiture> cars = new ArrayList<Voiture>();
        for (int i=1; i<11;i++) {
            int nb=i*100;
            Voiture voiture = new Voiture("Renault",nb);
            cars.add(voiture);
        }
        System.out.println(cars);
        cars.add(new Voiture("Renault",250));
        //Collection.sort(cars);
        int compteur= 0;
        while(compteur<10){
            for (int i=0; i<10;i++) {
                if(cars.get(i).getKilometrage()>cars.get(i+1).getKilometrage()){
                    Voiture v = cars.get(i);
                    cars.set(i,cars.get(i+1));
                    cars.set(i+1,v);
                }
            }
            compteur ++ ;
        }
        Voiture voiture = new Voiture("Renault",500);
        for (int i=0; i<11;i++) {
            Voiture test =cars.get(i);
            if(test.equals(voiture)){
                System.out.println("///////////////////////////////////");
                cars.remove(i);
            }
        }
        for (int i=0; i<11;i++) {
            System.out.println(cars.get(i));
        }
    }
}
