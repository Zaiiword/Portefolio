import java.util.Random;
import java.util.Scanner;
class Exercice4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int k= 20;
        int j=1;
        int tab [] =new int[k]  ;
        int tab2 [] =new int[k]  ;
        for (int i=0; i<20;i++) {
            Random random = new Random();
            int nb ;
            nb = random.nextInt(10);
            tab[i]=nb;
            System.out.print(tab[i]+"|");     
        }
        System.out.println("Quel Chiffre souhaitez-vous supprimer ?");
        int nombre = scanner.nextInt();
        for (int i=20; i>-1;i--) {
            if(tab[i]==nombre){
                //on change la valeur comme ça on ne la resupprime plus
                nombre=12;
                j=0;
            }
            else{
                tab2[i-j]=tab[i];
            }
        }
        for (int i=0; i<19;i++) {
            System.out.print(tab2[i]+"|");     

        }

    }
}
