Créateur: Dekeister Clément
TD1 / TDA

Bonjour et bienvenue dans mon programme,
alors pour commencer voici tout les programmes que j'ai fais :

-toute la partie obligatoire
-3.1:format_affichage
-3.2:calcul_jour
-3.3:calcul_veille_lendemain
-3.4:ajoute_n_jour
     retranche_n_jour
-3.5:ecart_jour

-4.1:ajoute_fetes
-4.2:ajoute_calendrier
-4.3:trouve_evenement
- PAS la 4.4

-5.1:affiche_mensuel
-PAS la 5.2 (elle me fait trop peur )
-5.3:doom

alors les difficultés que j ai recontré :
pas de difficulté particulière dans la partie obligatoire a part quand je passe 1/2h a chercher 
le probleme alors que j ai juste inversé > et <

pour format affichage j ai galéré parce que je connaissais pas la fonction global
et aussi parce que quand il passé pas le valide_complet dans affiche_calendrier du coup 
j ai adapté la fonction pour que ça passe (le else à la fin)

pour calcul jour le destin a fait que j'avais déjà fait une fonction similaire dans ma licence
avant que je me réoriente donc j y ai passé 5 min

ensuite pour les fonction suivante je me suis dis qu'il serait plus simple d avoir un chiffrer plutôt que
un jour et un mois donc j ai créé la fonction nieme_jour pour cela et inverse_nieme_jour qui fait l inverse
pour reconvertir le chiffre en date une fois le calcul effectué

grace à ces 2 fonctions précèdente les 3 suivant de la partie 3 n'ont pas étaient si compliqué j ai juste
dut ajuster avec les > et < (je sais je suis un boulet avec ça ^^)
	
pour la partie 4 il y a ajoute_fetes qui etait assez simple j ai préférer utiliser des tuple poour gagner de la place
pour trouve_evenement c est juste une boucle qui parcour toute la liste et si les dates correspondent ça renvoie l'évènement

et enfin la partie 5, j'ai juste fais la dernière ou comme un con j essayais de déchiffrer la question comme si c était une 
énigme alors que je savais juste pas que c'était les niveaux de difficultés de DOOM (il faut que je revoie mes classique en
jeu vidéo :)  )

Voilà c'est tout bon courage pour la correction en esperant que ça aille vite parce que tout est bon ^^
