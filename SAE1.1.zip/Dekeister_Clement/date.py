#implémentation des dates et calendriers
# Implémentation des tests (voir main en fin de fichier)

from typing import Dict, List, Tuple, NoReturn



# =============================================================================
def est_bissextile(annee: int) -> bool :
    """
    retourne vrai si l'année est bissextile

    >>> est_bissextile(2020)
    True
    >>> est_bissextile(2021)
    False
    >>> est_bissextile(2022)
    False
    >>> est_bissextile(1900)
    False
    >>> est_bissextile(2000)
    True
    """ 
    #calcul pour savoir si une année est bissextile ou non
    if (annee%4 == 0 and annee%100 != 0) or annee%400 == 0 :
        return True 
    else:
        return False


    
# =============================================================================
def cree_date(j: int, m: int, a: int) -> Dict :
    """
    Crée une date à partir des entiers la décrivant.
    Si l'un des paramètres n'est pas un entier, la fonction retournera None

    >>> cree_date(15,12,2020)
    {'jour': 15, 'mois': 12, 'annee': 2020}
    >>> cree_date(1.5,12,2020)

    """
    #si c est un entier
    if j%1==0 and m%1==0 and a%1 == 0 :
        #on créé un dictionnaire avec la date
        date= {'jour':j,'mois':m,'annee':a}
        return date 

    
# =============================================================================
def formataffichage(affichage:str) -> NoReturn :
    """
    Permet de modifier le format d'affichage en alternant entre le format anglais et le format français (le normal)
    """ 
    #il fonctionne plus 2 min avant de rendre donc pas eus le temps de corriger 
    # on met date en global comme elle n'est pas en paramètre
    global date
    #on detecte si on veut passer en date gb
    if affichage == 'gb':
        #on inverse jour et mois en gardant les clés à leur place parce qu'autrement
        # les autres programmes remette en mode fr automatiquement
        date={'jour':date['mois'],'mois':date['jour'],'annee':date['annee']}
    else:
        #on change rien mais je voulais mettre quelque chose
        date=date


# =============================================================================
def copie_date(date: Dict) -> Dict :
    """
    copie la date passée en paramètre

    >>> copie_date(date={'jour': 15, 'mois': 12, 'annee': 2020})
    {'jour': 15, 'mois': 12, 'annee': 2020}
    """

    date2={'jour':date['jour'] ,'mois':date['mois'] ,'annee':date['annee']}
    #si j'avais return date le résultat serait le même mais j'aime rajouter des 
    #calculs
    return date2

    
# =============================================================================
def compare(d1: Dict, d2: Dict) -> int :
    """
    Permet de classer deux dates.
    Retourne
    -1 si la date d1 < d2
    +1 si la date d1 > d2
    0 si les dates sont identiques
    on considère que les dates sont croissantes 
    dans l'ordre chronologique

    >>> date1 = cree_date(25,12,2021)
    >>> date2 = cree_date(31,12,2021)
    >>> compare(date1,date2)
    -1
    >>> compare(date2,date1)
    1
    >>> compare(date1,date1)
    0

    >>> date1 = cree_date(15,11,2021)
    >>> date2 = cree_date(10,12,2021)
    >>> compare(date1,date2)
    -1
    >>> compare(date2,date1)
    1
    >>> compare(date1,date1)
    0
    """
    #même principe tout le long
    #si annee 1> annee 2 
    #sinon etc
    if d1['annee'] > d2['annee'] :
        return 1
    elif d1['annee'] < d2['annee'] :
        return -1
    else:
        if d1['mois'] > d2['mois'] :
            return 1
        elif d1['mois'] < d2['mois'] :
            return -1
        else:
            if d1['jour'] > d2['jour'] :
                return 1
            elif d1['jour'] < d2['jour'] :
                return -1
            else :
                return 0


# =============================================================================
def valide_simple(d: Dict) -> bool :
    """   
    retourne vrai si la date est valide.
    on supposera que la date est valide si :
    - si le premier (le jour) est un entier compris entre 1 et 31
    - si le second (le mois) est un entier compris entre 1 et 12

    >>> date = cree_date(1, 2, 0)
    >>> valide_simple(date)
    True
    >>> date = cree_date(1.5, 5, 6)
    >>> valide_simple(date)
    False
    >>> date = cree_date(0, 5, 6)
    >>> valide_simple(date)
    False
    >>> date = cree_date(20, 8, 2021)
    >>> valide_simple(date)
    True
    """
    #si d est vide
    if d == None :
        return False
    #si les jours sont compris entre 1 et 31
    if d['jour']>=1 and d['jour']<=31 :
        #et si les mois sont compris entre 1 et 12
        if d['mois']>=1 and d['mois']<=12 :
            #alors c'est vrai
            return True
    else:
        #sinon c'est faux
        return False
    

# =============================================================================
def valide_complet(d: Dict) -> bool :
    """ 
    retourne vrai si la date est valide.
    on supposera que la date est valide si :
    - la validation simple est vraie
    - si la date représente une date réelle 

    >>> date = cree_date(15, 1, 2022)
    >>> valide_complet(date)
    True
    >>> date = cree_date(32, 1, 2022)
    >>> valide_complet(date)
    False
    >>> date = cree_date(-1, 1, 2022)
    >>> valide_complet(date)
    False
    >>> date = cree_date(31, 6, 2022)
    >>> valide_complet(date)
    False
    >>> date = cree_date(29, 2, 2020)
    >>> valide_complet(date)
    True
    >>> date = cree_date(29, 2, 2022)
    >>> valide_complet(date)
    False
    """
    mois_31_jours=(1,3,5,7,8,10,12)
    mois_30_jours=(4,6,9,11)
    if valide_simple(d) :
        # si c est un mois de 31 jours
        if d['mois'] in mois_31_jours :
            if d['jour'] < 32 :
                return True
        #si c est un mois de 30 jours
        elif d['mois'] in mois_30_jours :
            if d['jour'] < 31 :
                return True
        #si c 'est février
        else:
            #et qu'il est bissextile 
            if est_bissextile(d['annee']):
                if d['jour'] < 30:
                    return True
            #sinon
            elif d['jour'] < 29 :
                return True
    #pour tout les autres cas
    return False
        


# =============================================================================
def ajoute_calendrier(calendrier: List, date: Dict, description: str ) -> NoReturn :
    """
    ajoute un élément à la liste du calendrier.
    """
    if valide_complet(date):  
        evenement={'date':date,'évènement':description}
        #placement des évènement selon l ordre des dates
        if calendrier == []:
                calendrier.append(evenement)
        #si il y a déjà des dates
        else:
            #si c est la première date on fait comme ça parce que le insert fonctionne pas pour integrer un valeur en n°1
            if compare(calendrier[-1]['date'],date) == -1 or compare(calendrier[-1]['date'],date)==0 :
                    print("t")
                    calendrier.append(evenement)
            #on fait donc le insert si ce n'est pas la première date
            else:
                for i in range(len(calendrier)):
                    print(compare(calendrier[i]['date'],date),compare(calendrier[i]['date'],date))
                    if compare(calendrier[i]['date'],date) == -1 or compare(calendrier[i]['date'],date)==0 :
                        calendrier.insert(i,evenement)
                        break
    else:
        #parce qu autrement la date en anglais passe pas la valide_complete
        if 0<date['jour']<13 and 0<date['mois']<32 :
            evenement={'date':date,'évènement':description}
            calendrier.append(evenement)


# =============================================================================
def affiche_calendrier(calendrier: List) -> NoReturn :
    """
    affiche le calendrier sous forme de liste.
    """
    for i in range(len(calendrier)) :
        #on recupère ce qu il y a dans la date qu on transforme en string
        jour=str(calendrier[i-1]['date']['jour'])
        mois=str(calendrier[i-1]['date']['mois'])
        annee=str(calendrier[i-1]['date']['annee'])
        #on concatene
        date2=jour+'/'+mois+'/'+annee
        print('Le',date2,' : ',calendrier[i-1]['évènement'])
    
# =============================================================================
def calcul_jour(date: Dict) -> str :
    """
    Renvoie le jour correspondant à la date rentrée
    on suppose que la date a déjà été vérifié

    Tests:
    
    >>> date = cree_date(7,12, 2021)
    >>> calcul_jour(date)
    'Mardi'

    >>> date = cree_date(29, 2, 2022)
    >>> calcul_jour(date)
    'Mardi'
    """
    annee=date['annee']
    mois=date['mois']
    jour=date['jour']
    #la partie en dessous fait un calcul pour obtenir un chiffre entre 0 et 7 à partir de la date
    c=(14-mois)//12
    a1=annee//4
    ab=annee//100
    k=ab//4
    q=(31*(mois+12*c-2))//12
    chiffre=(jour+annee-c+a1-ab+k+q)%7
    #maintenant ce chiffre correspond à un jour alors on cherche le jour correspondant
    dico_jour=['Dimanche','Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi','Dimanche']
    return dico_jour[chiffre]

# =============================================================================
def nieme_jour(date: Dict ) -> int :
    """
    reçois une date et revoit cette date sous la forme nième jour de l'année

    TEST:

    >>> nieme_jour({'jour': 11, 'mois': 11, 'annee': 2041})
    315

    >>> nieme_jour({'jour': 11, 'mois': 11, 'annee': 2020})
    316
    """
    if est_bissextile(date['annee']):
        #liste des mois quand l'année est bissextile
        jour_mois=[0,31,60,91,121,152,182,213,244,274,305,335,366]
        mois=date['mois']-1
        #on soustrait
        numero_jour=jour_mois[mois]+date['jour']  
      
    else:
        #liste des mois quand l'année est normale
        jour_mois=[0,31,59,90,120,151,181,212,243,273,304,334,365]
        mois=date['mois']-1
        numero_jour=jour_mois[mois]+date['jour']
    return numero_jour
        
# =============================================================================
def inverse_nieme_jour(numero_jour :int,annee :int) -> Dict:
    """
    fais l'inverse de la fonction nième jour recoit le nième jour et l'année et revoit la date 
    dans un dictionnaire

    TEST:

    >>> inverse_nieme_jour(315,2041)
    {'jour': 11, 'mois': 11, 'annee': 2041}

    >>> inverse_nieme_jour(316,2020)
    {'jour': 11, 'mois': 11, 'annee': 2020}
    """
    if est_bissextile(annee):
        jour_mois=[0,31,60,91,121,152,182,213,244,274,305,335,366]
        #on regarde jusqu' a ce que l on dépasse le mois et après
        #on soustrait
        for m in range(12):
            if jour_mois[m]>=numero_jour:
                jour=numero_jour-jour_mois[m-1]
                date={'jour':jour,'mois':m,'annee':annee}
                return date
    else:
        jour_mois=[0,31,59,90,120,151,181,212,243,273,304,334,365]
        for m in range(12):
            if jour_mois[m]>=numero_jour:
                jour=numero_jour-jour_mois[m-1]
                date={'jour':jour,'mois':m,'annee':annee}
                return date

# =============================================================================
def calcul_veille_lendemain(date: Dict) -> Tuple[Dict, Dict]:
    """
    Calcul la date de la veille et du lendemain 

    Test:

    >>> date = cree_date(1, 1, 2041)
    >>> calcul_veille_lendemain(date)
    ({'jour': 31, 'mois': 12, 'annee': 2040}, {'jour': 2, 'mois': 1, 'annee': 2041})

    >>> date = cree_date(29, 2, 2020)
    >>> calcul_veille_lendemain(date)
    ({'jour': 28, 'mois': 2, 'annee': 2020}, {'jour': 1, 'mois': 3, 'annee': 2020})
    """ 
    #on vérifie d'abord les 2 cas exeptionels qui sont le 1er janvier et 31 déccembre
    if date['mois']==12 and date['jour']==31:
        dico_veille={'jour':30,'mois':12,'annee':date['annee']}
        dico_lendemain={'jour':1,'mois':1,'annee':date['annee']+1}
    elif date['mois']==1 and date['jour']==1:
        dico_veille={'jour':31,'mois':12,'annee':date['annee']-1}
        dico_lendemain={'jour':2,'mois':1,'annee':date['annee']}
    #on utilise les fonction nieme_jour et son inverse afin de pourvoir changer de jours plus 
    #facilement sans penser au jour a 28/29/30/31 jours
    else:
        numero_jour=nieme_jour(date)
        #on reconverti le jour en date avec -1 pour la veille et +1 pour le lendemain
        dico_veille=inverse_nieme_jour(numero_jour-1,date['annee'])
        dico_lendemain=inverse_nieme_jour(numero_jour+1,date['annee'])
        
    #on met le tout dans un tuple
    return (dico_veille,dico_lendemain)

def affiche_mensuel(calendrier : List, mois : int ,annee : int) -> NoReturn :
    """
    affiche le mois avec une interface respectable
    """
    #le programme est étrange mais il fonctionne
    liste_mois=('','Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre')
    mois_31_jours=(1,3,5,7,8,10,12)
    mois_lettre=liste_mois[mois]
    #pour savoir le mois à quelle
    if mois_lettre == 'Février':
        if est_bissextile(annee):
            mois_nombre=29
        else:
            mois_nombre=28
    elif mois in mois_31_jours :
        mois_nombre=31
    else:
        mois_nombre=30
    #on affiche le mois et l'année
    print("** ",mois_lettre,"",annee," **")
    #une boucle pour print chaque jour du mois
    for i in range(mois_nombre):
        jour_1={'jour':i+1,'mois':mois,'annee':annee}
        nom_jour=calcul_jour(jour_1)
        #pour mettre les 0 devant les chiffre
        if i+1<10 :
            numero="0"+str(i+1)
        else:
            numero=str(i+1)
        for j in range(len(calendrier)):
            #on regarde si il y a un évènement à cette date
            if jour_1 == calendrier[j]['date'] :
                evenement=calendrier[j]['évènement']
            #évènement est vide
            else:
                evenement=""
            espace=""
            #pr aligner les jours
            for g in range(10-len(nom_jour)):
                espace=espace+" "
                    
        print(espace,nom_jour," ",numero," : ",evenement)

# =============================================================================
def ecart_jour(date1: Dict, date2:Dict ) -> int :
    """
    renvoie le nombre de jours séparant 2 dates

    Test :
    >>> date = cree_date(12, 11, 2021)
    >>> date2= cree_date(13, 11, 2022)
    >>> ecart_jour(date,date2)
    366

    >>> date = cree_date(14, 11, 2022)
    >>> date2= cree_date(12, 11, 2021)
    >>> ecart_jour(date,date2)
    367

    >>> date = cree_date(12, 11, 2021)
    >>> date2= cree_date(22, 11, 2021)
    >>> ecart_jour(date,date2)
    10
    """
    #je réutilise la technique pour convertir les jours en nième jour
    jour_1=nieme_jour(date1)
    jour_2=nieme_jour(date2)
    #1ère possibilité , la plus simple c est la meme année
    if date1['annee'] == date2['annee'] :
        # il faut savoir quelle date elle la plus vielle pour ne pas avoir 
        #jour négatif quand on soustrait
        x=compare(date1,date2)
        if x > 0 :
            numero_jour=jour_1-jour_2
        else:
            numero_jour=jour_2-jour_1
    #2ème possibilité (plus chiante) ce n'est pas la même année :année1>année2
    elif date1['annee'] > date2['annee'] :
        #le but faire redescendre date1 à la même année que date 2
        surplus_jour=0
        annee1=date1['annee']
        while annee1 != date2['annee'] :
            if est_bissextile(annee1-1) :
                surplus_jour=surplus_jour+366
            else:
                surplus_jour=surplus_jour+365
            annee1=annee1-1
        numero_jour=jour_1-jour_2+surplus_jour
    #3ème possibilité comme au dessus mais année2>année1
    else:
        surplus_jour=0
        annee2=date2['annee']
        while date1['annee'] != annee2 :
            if est_bissextile(annee2-1) :
                surplus_jour=surplus_jour+366
            else:
                surplus_jour=surplus_jour+365
            annee2=annee2-1
        numero_jour=jour_2-jour_1+surplus_jour
    return numero_jour

# =============================================================================
def ajoute_n_jour ( date : Dict , n: int ) -> Dict :
    """
    Renvoie la date rentrée avec le nombre de jour en plus demandé

    Tests:

    >>> date = cree_date(12, 11, 2021)
    >>> ajoute_n_jour(date,3)
    {'jour': 15, 'mois': 11, 'annee': 2021}

    >>> date = cree_date(12, 11, 2020)
    >>> ajoute_n_jour(date,3000)
    {'jour': 29, 'mois': 1, 'annee': 2029}
    """
    #toujours la technique de transformer le jour en chiffre qu'est ce que je ferais sans ?
    annee = date['annee']
    numero_jour = nieme_jour(date)
    #le but et de faire en sorte qu on puisse faire inverse_nieme_jour mais pour ça il faut
    # un nombre plus petit que 366 
    if n >366 :
        while n>366 :
            if est_bissextile( annee+1):
                n=n-366
            else:
                n=n-365
            annee=annee+1
    #maintenant au pire il ne faut augmenter que d'une annee
    if est_bissextile(annee) and (numero_jour+n) > 366 :
        annee=annee+1
        nombre_jour=numero_jour+n-366
    #annee normal séparé des bissextiles
    elif numero_jour+n > 365 :
        annee=annee+1
        nombre_jour=numero_jour+n-365
    #si il n'y a pas d'année à changer
    else:
        nombre_jour=numero_jour+n
    date_retour=inverse_nieme_jour(nombre_jour,annee)
    return date_retour

# =============================================================================
def retranche_n_jour ( date : Dict , n: int ) -> Dict :
    """
    basiquement pareil que ajoute_n_jour mais fais l'inverse
    c'est à dire enlever n jour à la date donné

    Tests:
    >>> date = cree_date(12, 11, 2021)
    >>> retranche_n_jour(date,3)
    {'jour': 9, 'mois': 11, 'annee': 2021}

    >>> date = cree_date(12, 11, 2020)
    >>> retranche_n_jour(date,3000)
    {'jour': 26, 'mois': 8, 'annee': 2012}
    """
    annee = date['annee']
    numero_jour = nieme_jour(date)
    #le but et de faire en sorte qu on puisse faire inverse_nieme_jour mais pour ça il faut
    # un nombre plus petit que 366 
    if n >366 :
        while n>366 :
            if est_bissextile( annee-1):
                n=n-366
            else:
                n=n-365
            annee=annee-1
    #cette fois ci on a pas besoin de séparé bissextile est les autres
    #comme on veut juste savoir si c est positif
    if numero_jour-n <0 :
        annee=annee+1
        nombre_jour=numero_jour-n+365
    #si il n'y a pas d'année à changer
    else:
        nombre_jour=numero_jour-n
    date_retour=inverse_nieme_jour(nombre_jour,annee)
    return date_retour

# =============================================================================
def ajoute_fetes(calendrier: List , annee: int ) -> NoReturn :
    """
    Ajoute toutes les date fixe des fête fixe (Il ne faudrait pas aller travailler un jour férié ^^)

    les jours fériés sont :
    -jour de l'an
    -fête du travail
    -fin 2nd guerre mondiale
    -fête national
    -assomption
    -la toussaint
    -armistice 1ère guerre mondiale
    -noël
    """
    #liste de toute les fêtes avec leur jour et leur mois
    liste_jour=(25,11,1,15,14,8,1,1)
    liste_mois=(12,11,11,8,7,5,5,1)
    liste_evenement=('Noël','Armistice 1918','Fête de la toussaint','Assomption','Fête national','Fin seconde GM','Fête du travail','Jour de l\'an' )
    #on assemble le tout
    for i in range(len(liste_jour)):
        dict_date={'jour':liste_jour[i-7],'mois':liste_mois[i-7],'annee':annee}
        date={'date':dict_date,'évènement':liste_evenement[i-7]}
        calendrier.append(date)
        
# =============================================================================
def trouve_evenement(calendrier: List, date: Dict) -> str :
    """
    reçoit une date et renvoie l'évènement qui y correspond

    Tests:
    >>> date=cree_date(25,12,2020)
    >>> calendrier=[]
    >>> ajoute_fetes(calendrier,2020)
    >>> trouve_evenement(calendrier,date)
    'Noël'

    """
    #on parcourt tout le tableau à la recherche de la date
    for i in range(len(calendrier)):
        if calendrier[i]['date'] == date :
            return calendrier[i]['évènement']

# =============================================================================
def doom(calendrier: list) -> NoReturn :
    #compliqué cette saé ^^
    #par contre si je me suis trompé j ai l'air d'un con ^^
    date=cree_date(10,12,1993),
    ajoute_calendrier(date,"sortie du premier jeu doom")
         


# =============================================================================    
if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)  
    