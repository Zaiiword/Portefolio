import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;

import org.junit.Test;

public class CouleurTest {

    @Test
    public void trivialTest(){
        assertTrue(true);
        Couleur c = new Couleur();
        assertEquals(c.getR(), 0);
    }

    @Test
    public void couleurCopie() throws IOException {
        Couleur clr = new Couleur(0,0,0);
	    Couleur copie = new Couleur(clr);
	    Couleur reference = new Couleur(0,0,0);
	    assertEquals(copie, reference);
    }

    @Test
    public void estNoir() throws IOException {
        Couleur clr = new Couleur(0,0,0);
        assertTrue(clr.estNoir());
    }

    @Test
    public void estBlanc() throws IOException {
        Couleur clr = new Couleur(255,255,255);
        assertTrue(clr.estBlanc());
    }

    @Test
    public void difference() throws IOException {
        Couleur clr = new Couleur(255,255,255);
        Couleur clr1 = new Couleur(255,255,255);
        Couleur clrNoire = new Couleur(0,0,0);
        clr.difference(clr1);
        assertEquals(clrNoire, clr);
    }

    @Test
    public void negatif() throws IOException {
        Couleur clr = new Couleur(255,255,255);
        Couleur clrNegatif = new Couleur(0,0,0);
        clr.negatif();
        assertEquals(clr, clrNegatif);
    }

    @Test
    public void niveauGris() throws IOException {
        Couleur clr = new Couleur(255,0,0);
        Couleur clrGris = new Couleur(85,85,85);
        clr.niveauGris();
        assertEquals(clr, clrGris);
    }
    
}
